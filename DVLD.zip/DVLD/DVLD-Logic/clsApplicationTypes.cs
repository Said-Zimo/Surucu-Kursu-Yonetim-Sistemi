﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsApplicationTypes
    {


        public int AppTypeID { get; set; }

        public string AppTypeTitle { get; set; }

        public decimal AppTypeFees { get; set; }

        public static DataTable GetAllAppTypes()
        {
            return clsApplicationTypesData.GetAllAppTypesData();
        }

        clsApplicationTypes(int appTypeID, string appTypeTitle, decimal appTypeFees)
        {
            AppTypeID = appTypeID;
            AppTypeTitle = appTypeTitle;
            AppTypeFees = appTypeFees;
        }

        public static clsApplicationTypes FindApplicationType(int AppTypeID)
        {
            string title = "";
            decimal fees = -1;
            if(clsApplicationTypesData.FindApplicationType(AppTypeID ,ref title ,ref fees))
            {
                return new clsApplicationTypes(AppTypeID, title, fees);
            }
            else
            {
                return null;
            }
        }

        public bool Save()
        {
            return clsApplicationTypesData.UpdateAppTypeDetails(this.AppTypeID ,this.AppTypeTitle , this.AppTypeFees);
        }



    }
}
