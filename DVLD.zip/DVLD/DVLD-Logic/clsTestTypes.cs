﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsTestTypes
    {

        public int TestTypeID { get; set; }

        public string TestTypeTitle { get; set; }

        public string TestDescription { get; set; }

        public decimal TestTypeFees { get; set; }

        public static DataTable GetAllTestTypes()
        {
            return clsTestTypesData.GetAllTestTypesData();
        }

        clsTestTypes(int testTypesID, string testTypeTitle, string testTypeDescription, decimal testTypeFees)
        {
            TestTypeID = testTypesID;
            TestTypeTitle = testTypeTitle;
            TestDescription = testTypeDescription;
            TestTypeFees = testTypeFees;
        }

        public static clsTestTypes FindTestType(int TestTypeID)
        {
            string title = "" , description = "";
            decimal fees = -1;
            if (clsTestTypesData.FindTestType(TestTypeID, ref title, ref description, ref fees))
            {
                return new clsTestTypes(TestTypeID, title,description , fees);
            }
            else
            {
                return null;
            }
        }


        public bool Save()
        {
            return clsTestTypesData.UpdateTestTypeDetails(this.TestTypeID, this.TestTypeTitle, this.TestDescription , this.TestTypeFees);
        }







    }
}
