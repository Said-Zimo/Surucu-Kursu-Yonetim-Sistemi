﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsPeople
    {
        private enum _Mode { AddNew = 1 , Update =  2 }
        _Mode mode = _Mode.AddNew;

        public int PersonID { get; set; }

        public string NationalNo { get; set; }

        public string FirstName { get; set; }

        public string SecondName { get; set; }

        public string ThirdName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public DateTime DateOfBirth {  get; set; }

        public string Address { get; set; }

        public int CountryID   { get; set; }

        public string CountryName { get; set; }

        public string Gendor {  get; set; }

        public string FullName { get { return FirstName + " " + SecondName + " " + ThirdName + " " + LastName; } }

        public clsPeople()
        {
            PersonID = -1;
            NationalNo = "";
            FirstName = "";
            SecondName = "";
            ThirdName = "";
            LastName = "";
            Gendor = "";
            Email = "";
            Address = "";
            Phone = "";
            DateOfBirth = DateTime.Now;
            CountryID = -1;
            CountryName = "";

            mode = _Mode.AddNew;
        }

        private clsPeople(int personID, string nationalNo, string firstName, string secondName, string thirdName,
            string lastName, string gendor , string email,  string address, string phone, DateTime dateOfBirth, int countryID , string CountryName)
        {
            this.PersonID = personID;
            this.NationalNo = nationalNo;
            this.FirstName = firstName;
            this.SecondName = secondName;
            this.ThirdName = thirdName;
            this.LastName = lastName;
            this.Email = email;
            this.Phone = phone;
            this.DateOfBirth = dateOfBirth;
            this.Address = address;
            this.CountryID = countryID;
            this.Gendor = gendor;
            this.CountryName = CountryName;

            mode = _Mode.Update;
        }

        public static bool DeletePerson(int personID)
        {
            return clsPeopleData.DeletePerson(personID);

        }

        


        public static DataTable GetAllData()
        { 

            return clsPeopleData.GetAllPeopleData();
        }

        private bool _AddNewPeople()
        {
            byte gendor = 3;
            if (Gendor == "Male")
            {
                gendor = 0;
            }
            else
            {
                gendor = 1;
            }

           this.PersonID = clsPeopleData.AddPeopleData( NationalNo, FirstName, SecondName, ThirdName, LastName, gendor, Email, Phone, Address, DateOfBirth , CountryID  );

            return (PersonID != -1);
        }

        private bool _UpdatePeopleInfo()
        {
            byte gendor = 3;
            if (Gendor == "Male")
            {
                gendor = 0;
            }
            else
            {
                gendor = 1;
            }

            return clsPeopleData.UpdatePersonInfo(PersonID, NationalNo, FirstName, SecondName, ThirdName, LastName, gendor, Email, Phone, Address, DateOfBirth, CountryID);

        }

        public bool Save()
        {
            switch (mode) {
                case _Mode.AddNew:
                    if (_AddNewPeople())
                    {
                        mode = _Mode.Update;
                        return true;
                    }
                    break;
                    case _Mode.Update:
                    if (_UpdatePeopleInfo())
                    {
                        mode = _Mode.AddNew;
                        return true;
                    }
                    break;
            }
            return false;
        }

        public static clsPeople FindPeople(int PersonID)
        {

            string nationalNo = "", firstName = "", secondName = "", thirdName = "", lastName = "", email = "", address = "", phone = "" , gendor = "" , countryName =""; 
            DateTime dateOfBirth = DateTime.Now;
            int country = -1;

            if (clsPeopleData.FindPeople(PersonID , ref nationalNo, ref firstName, ref secondName, ref thirdName, ref lastName,
               ref gendor, ref email, ref address , ref phone , ref dateOfBirth , ref country , ref countryName))
            {
                return new clsPeople(PersonID, nationalNo,  firstName,  secondName, thirdName, lastName,
               gendor, email, address, phone, dateOfBirth, country , countryName);
            }
            else
            {
                return null;
            }
        }


        public static clsPeople FindPeople(string NationalNo)
        {
            int personID = -1 , countryID = -1;
            string firstName = "", secondName = "", thirdName = "", lastName = "", email = "", address = "", phone = "", gendor = "" , countryName= "";
            DateTime dateOfBirth = DateTime.Now;


            if (clsPeopleData.FindPeople(ref personID,  NationalNo, ref firstName, ref secondName, ref thirdName, ref lastName,
               ref gendor, ref email, ref address, ref phone, ref dateOfBirth, ref countryID , ref countryName))
            {
                return new clsPeople(personID, NationalNo, firstName, secondName, thirdName, lastName,
               gendor, email, address, phone, dateOfBirth, countryID , countryName);
            }
            else
            {
                return null;
            }

        }

    }
}
