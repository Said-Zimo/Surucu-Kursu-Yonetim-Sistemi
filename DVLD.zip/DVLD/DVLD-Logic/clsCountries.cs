﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsCountries
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; }


        private clsCountries(int ID , string countryName) 
        {
            this.CountryID = ID;
            this.CountryName = countryName;
        }

       
        public static clsCountries Find(string CountryName)
        {

            int ID = -1;

            if(clsCountriesData.FindCountry(ref ID ,CountryName))
            {
                return new clsCountries(ID , CountryName);
            }
            else
            {
                return null;
            }
         

        }


        public static DataTable GetAllCountries()
        {
            return clsCountriesData.GetAllCountriesData();
        }

        


    }
}
