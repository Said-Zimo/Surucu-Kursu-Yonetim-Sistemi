﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DVLD_Logic
{
    public class clsDetainLicense
    {
        enum enMode { Detain = 1 ,Release = 2 }
        private enMode _Mode = enMode.Detain;


        public int DetainID {  get; set; }

        public int LicenseID { get; set; }

        public DateTime DetainDate { get; set; }

        public decimal DetainFees { get; set; }

        public int CreatedByUser { get; set; }

        public bool IsReleased { get; set; }

        public DateTime ReleaseDate { get; set; }

        public int ReleasedByUserID { get; set; }

        public int ReleasedApplicationID { get; set; }


        public clsDetainLicense()
        {
            this.DetainID = -1;
            this.LicenseID = -1;
            this.DetainDate = DateTime.Now;
            this.DetainFees = -1;
            this.CreatedByUser = -1;
            this.IsReleased = false;
            this.ReleaseDate = DateTime.Now;
            this.ReleasedByUserID = -1;
            this.ReleasedApplicationID = -1;
            _Mode = enMode.Detain;
        }

        private clsDetainLicense(int detainID, int licenseID, DateTime detainDate, decimal detainFees, int createdByUser, bool isReleased, 
            DateTime releaseDate, int releasedByUserID, int releasedApplicationID)
        {
            
            this.DetainID = detainID;
            this.LicenseID = licenseID;
            this.DetainDate = detainDate;
            this.DetainFees = detainFees;
            this.CreatedByUser = createdByUser;
            this.IsReleased = isReleased;
            this.ReleaseDate = releaseDate;
            this.ReleasedByUserID = releasedByUserID;
            this.ReleasedApplicationID = releasedApplicationID;
            _Mode = enMode.Release;
        }

        public static bool isDetained(int LicenseID)
        {
            return clsDetainLicenseData.isDetained(LicenseID);
        }

        public static DataTable GetAllDetainLicenseList()
        {
            return clsDetainLicenseData.GetAllDetainLicenseList();
        }

        private bool _AddNewDetain()
        {
            this.DetainID = clsDetainLicenseData.AddNewDetain(this.LicenseID , this.DetainDate , this.DetainFees , this.CreatedByUser , this.IsReleased);
            return (this.DetainID != -1);
        }

        private bool _ReleaseDetainLicense()
        {
            return clsDetainLicenseData.ReleaseDetainLicense(this.LicenseID, this.DetainDate, this.DetainFees, this.CreatedByUser, this.IsReleased , this.ReleaseDate , this.ReleasedByUserID , this.ReleasedApplicationID);
        }

        public static clsDetainLicense FindDetainLicenseByLicenseID(int licenseID)
        {
            int detainID = -1,  createdByUser = -1, releasedByUserID = -1, releasedApplicationID = -1;
            DateTime detainDate = DateTime.Now, releaseDate = DateTime.Now;
            decimal detainFees = -1;
            bool isReleased = false;

            if (clsDetainLicenseData.FindDetainLicenseByLicenseID(ref detainID , licenseID , ref detainDate , ref detainFees , ref createdByUser , ref isReleased, ref releaseDate , ref releasedByUserID , ref releasedApplicationID))
            {
                return new clsDetainLicense(detainID, licenseID, detainDate, detainFees, createdByUser, isReleased, releaseDate, releasedByUserID, releasedApplicationID);
            }
            else
            {
                return null;
            }

        }

        public bool Save()
        {
            switch (_Mode)
            {
                case enMode.Detain:
                    if (_AddNewDetain())
                    {
                        return true;
                    }
                    break;

                case enMode.Release:
                    if (_ReleaseDetainLicense())
                    {
                        return true;
                    }
                    break;
            }

            return false;
        }


    }
}
