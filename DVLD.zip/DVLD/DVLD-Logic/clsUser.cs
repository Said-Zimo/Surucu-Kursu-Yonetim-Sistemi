﻿using DVLD_DataAccess;
using System;
using System.Data;
using System.Net;
using System.Security.Policy;

namespace DVLD_Logic
{
    public class clsUser
    {

        private enum enMode { AddNew = 1, Update = 2 }
        enMode Mode = enMode.AddNew;

        public int UserID { get; set; }
        public int PersonID { get; set; }
        public string PersonFullName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool isActive {get; set;}



        public clsUser()
        {
            UserID = -1;
            PersonID = -1;
            PersonFullName = "";
            UserName = "";
            Password = "";
            isActive = false;
            Mode = enMode.AddNew;
        }

        private clsUser(int UserID, int PersonID, string PersonName, string UserName ,string Password, bool isActive)
        {
            this.UserID = UserID;
            this.PersonID = PersonID;
            this.PersonFullName = PersonName;
            this.UserName = UserName;
            this.Password = Password;
            this.isActive = isActive;
            Mode = enMode.Update;
        }

        public static clsUser FindUser(int UserID)
        {
            int  PersonID = -1;
            bool isActive = false;
            string Password = "", personFullName = "" , UserName = "";

            if (clsUserData.FindUser(UserID, ref UserName, ref PersonID, ref personFullName, ref Password, ref isActive))
            {
                return new clsUser(UserID, PersonID, personFullName, UserName, Password, isActive);
            }
            else
            {
                return null;
            }


        }

        public static bool DeleteUser(int UserID)
        {
            return clsUserData.DeleteUser(UserID);
        }

        public static clsUser FindUser(string UserName)
        {
            int UserID = -1 , PersonID = -1;
            bool isActive = false;
            string Password = "" , personFullName = "";

            if (clsUserData.FindUser(UserName,ref UserID, ref PersonID, ref personFullName ,ref Password, ref isActive))
            {
                return new clsUser( UserID,  PersonID, personFullName, UserName,  Password,  isActive);
            }
            else
            {
                return null;
            }
            

        }

        public static bool UserExist(int PersonID)
        {
            return clsUserData.UserExist(PersonID);
        }

        public static DataTable GetAllUsers()
        {
            return clsUserData.GetAllUsersData();
        }

        private bool _AddNewUser() 
        {
            this.UserID = clsUserData.AddNewUser(this.PersonID , this.UserName , this.Password , this.isActive);

            return (this.UserID != -1);
        }

        private bool _UpdateUser()
        {
            return clsUserData.UpdateUser(this.UserID , this.PersonID, this.UserName, this.Password, this.isActive);
        }

        public bool Save()
        {

            if (Mode == enMode.AddNew)
            {
                
                Mode = enMode.Update;
                return _AddNewUser();
            }
            else
            {
                Mode = enMode.AddNew;
                return _UpdateUser() ;
            }

        }


    }
}
