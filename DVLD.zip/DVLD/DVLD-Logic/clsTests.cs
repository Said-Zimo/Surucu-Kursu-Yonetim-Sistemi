﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsTests
    {

        public int TestID { get; set; }
        public int TestAppointmentID { get; set; }
        public bool TestResult { get; set; }
        public string TestNotes { get; set; }
        public int CreatedByUserID { get; set; }


        public static short PassedTestCount(int LDLappID)
        {
            return clsTestsData.PassedTestCount(LDLappID);
        }

        public static short FailedTestCount(int LDLappID ,int TestTypeID)
        {
            return clsTestsData.FailedTestCount(LDLappID , TestTypeID);
        }

        public static bool FindPassedTest(int LDLAppID , int TestTypeID)
        {
            return clsTestsData.FindPassedTest(LDLAppID , TestTypeID);
        }

        public static int FindRetakeTestAppointmentID(int LDLAppID, int TestTypeID)
        {
            return clsTestsData.FindRetakeTestAppointment(LDLAppID, TestTypeID);
        }

        public bool Save()
        {
            return clsTestsData.SaveTestInfo(this.TestAppointmentID , this.TestResult ,this.TestNotes , this.CreatedByUserID);
        }

    }
}
