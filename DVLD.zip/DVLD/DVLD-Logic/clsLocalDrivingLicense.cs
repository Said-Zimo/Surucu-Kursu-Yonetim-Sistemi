﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsLocalDrivingLicense
    {

        public int LocalLicenseApplicationsID {  get; set; }
        public int ApplicationID { get; set; }
        public int LicenseClassID { get; set; }
        public string LicenseClassName {  get; set; }
        public string NationalNo { get; set; }
        public string FullName { get; set; }
        public DateTime ApplicationDate { get; set; }
        public int PassedTest { get; set; }
        public string Status { get; set; }

        public clsLocalDrivingLicense()
        {
            this.LocalLicenseApplicationsID = -1;
            this.ApplicationID = -1;
            this.LicenseClassID = -1;
            this.LicenseClassName = "";
            this.NationalNo = "";
            this.FullName = "";
            this.ApplicationDate = DateTime.Now;
            this.PassedTest = 0;
            this.Status = "";


        }

        
        private clsLocalDrivingLicense (int localLicenseApplicationsID ,int applicationID ,int licenseClassID,  string licenseClassName ,
            string nationalNo , string fullName ,DateTime applicationDate , int passedTest ,string status)
        {
            this.LocalLicenseApplicationsID = localLicenseApplicationsID ;
            this.ApplicationID = applicationID ;
            this.LicenseClassID = licenseClassID ;
            this.LicenseClassName = licenseClassName;
            this.NationalNo = nationalNo ;
            this.FullName = fullName ;
            this.ApplicationDate = applicationDate ;
            this.PassedTest = passedTest ;
            this.Status = status ;
                
        }


        public static bool DeleteLocalLicenseApplication(int LDLAppID)
        {
            if(clsLocalDrivingLicensesData.DeleteLocalLicenseApplication(LDLAppID))
            {
                return clsApplications.DeleteApplication(clsLocalDrivingLicense.FindLocalLicenseApplication(LDLAppID).ApplicationID);
            }
            else
            {
                return false;
            }
        }

        public static DataTable GetAllLocalLicenseApplications()
        {
            return clsLocalDrivingLicensesData.GetAllLocalLicenseApplications();
        }

        public static string GetLocalLicenseAppStatus(int LDLAppID)
        {
            return clsLocalDrivingLicensesData.GetLocalLicenseAppStatus(LDLAppID);
        }

        public static int FindUnderReviewApplication(string NationalNo , string ClassName)
        {
            return clsLocalDrivingLicensesData.FindUnderReviewApplication(NationalNo , ClassName);

        }

        private bool _AddNewLocalLicense()
        {
            LocalLicenseApplicationsID =  clsLocalDrivingLicensesData.AddNewLocalLicense( ApplicationID , LicenseClassID);

            return (LocalLicenseApplicationsID != -1);
        }

        public bool Save()
        {
            return _AddNewLocalLicense();
        }

        public static clsLocalDrivingLicense FindLocalLicenseApplication(int LDLAppID)
        {
            int applicationID = -1 , passedTest = -1 , licenseClassID = -1;
            string licenseClassName = "" , nationalNo = "" , fullName = "" , status = "";
            DateTime applicationDate = DateTime.Now ;

            if(clsLocalDrivingLicensesData.FindLocalLicenseApplication(LDLAppID ,ref applicationID ,ref licenseClassID, ref licenseClassName , ref nationalNo , ref fullName, ref applicationDate , ref passedTest, ref status ))
            {
                return new clsLocalDrivingLicense(LDLAppID, applicationID, licenseClassID , licenseClassName, nationalNo, fullName, applicationDate, passedTest, status);
            }
            else
            {
                return null;
            }
        }


        

    }
}
