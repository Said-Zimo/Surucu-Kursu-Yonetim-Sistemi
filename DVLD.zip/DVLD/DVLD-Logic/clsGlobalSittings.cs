﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsGlobalSittings
    {
        public static clsUser CurrentUserInfo { get; set; }

        public static bool isLogined { get; set; }
    }
}
