﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsLicenseClasses
    {

        public int LicenseClassID {  get; set; }

        public string LicenseClassTitle { get; set; }

        public string LicenseClassDescription { get; set; }

        public byte MinimumAllowedAge {  get; set; }

        public byte DefaultValidityLength {  get; set; }

        public decimal ClassFees { get; set; }

        public clsLicenseClasses()
        {
            LicenseClassID = -1;
            LicenseClassTitle = "";
            LicenseClassDescription = "";
            MinimumAllowedAge = 0;
            DefaultValidityLength = 0;
            ClassFees = -1;
        }

        private clsLicenseClasses(int licenseID , string licenseClassTitle , string licenseClassDescription , byte minimumAllowedAge , byte defaultValidityLength , decimal classFees) 
        {
            this.LicenseClassID = licenseID;
            this.LicenseClassTitle = licenseClassTitle;
            this.LicenseClassDescription = licenseClassDescription;
            this.MinimumAllowedAge = minimumAllowedAge;
            this.DefaultValidityLength = defaultValidityLength;
            this.ClassFees = classFees;
        }

        public static clsLicenseClasses Find(int licenseClassID)
        {

            string title = "" , licenseClassDescription = "";
            byte minimumAllowedAge = 0, defaultValidityLength = 0;
            decimal classFees = -1;

            if (clsLicenseClassesData.Find(licenseClassID, ref title, ref licenseClassDescription, ref minimumAllowedAge, ref defaultValidityLength, ref classFees))
            {
                return new clsLicenseClasses(licenseClassID, title, licenseClassDescription, minimumAllowedAge, defaultValidityLength, classFees);
            }
            else
            {
                return null;
            }


        }

        public static clsLicenseClasses Find(string Title)
        {
            int licenseClassID = -1;
            string licenseClassDescription = "";
            byte minimumAllowedAge = 0 , defaultValidityLength = 0;
            decimal classFees = -1;

            if (clsLicenseClassesData.Find(ref licenseClassID , Title , ref licenseClassDescription , ref minimumAllowedAge , ref defaultValidityLength , ref classFees))
            {
                return new clsLicenseClasses(licenseClassID, Title, licenseClassDescription, minimumAllowedAge, defaultValidityLength, classFees);
            }
            else
            {
                return null;
            }


        }



        public static DataTable GetAllLicenseClasses()
        {
            return clsLicenseClassesData.GetAllLicenseClasses();
        }


    }
}
