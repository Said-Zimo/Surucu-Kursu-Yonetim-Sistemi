﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD_Logic
{
    public class clsInternationalLicense
    {
        enum enMode { AddNew = 1 , Update =  2 }
        private enMode _Mode = enMode.AddNew;


        public int InternationalLicenseID { get; set; }

        public int ApplicationID { get; set; }

        public int DriverID { get; set; }

        public int LocalLicenseID { get; set; }

        public DateTime IssueDate { get; set; }

        public DateTime ExpirationDate { get; set; }

        public bool IsActive { get; set; }

        public int CreatedByUserID { get; set; }

        public clsInternationalLicense()
        {
            this.InternationalLicenseID = -1;
            this.ApplicationID = -1;
            this.DriverID = -1;
            this.LocalLicenseID = -1;
            this.IssueDate = DateTime.Now;
            this.ExpirationDate = DateTime.Now;
            this.IsActive = false;
            this.CreatedByUserID = -1;
            _Mode = enMode.AddNew;
        }

        private clsInternationalLicense(int internationalLicenseID, int applicationID, int driverID, 
            int localLicenseID, DateTime issueDate, DateTime expirationDate, bool isActive, int createdByUserID)
        {
            
            this.InternationalLicenseID = internationalLicenseID;
            this.ApplicationID = applicationID;
            this.DriverID = driverID;
            this.LocalLicenseID = localLicenseID;
            this.IssueDate = issueDate;
            this.ExpirationDate = expirationDate;
            this.IsActive = isActive;
            this.CreatedByUserID = createdByUserID;
            _Mode  = enMode.Update ;
        }

        public static DataTable GetAllInternationalLicenses()
        {
            return clsInternationalLicenseData.GetAllInternationalLicenses();
        }

        public static clsInternationalLicense FindInternationalLicense(int internationalLicenseID)
        {
            int localLicenseID = -1, applicationID = -1, driverID = -1, createdByUserID = -1;
            DateTime issueDate = DateTime.Now, expirationDate = DateTime.Now;
            bool isActive = false;
            

            if (clsInternationalLicenseData.FindInternationalLicense(internationalLicenseID, ref applicationID, ref localLicenseID , ref driverID, ref issueDate, 
                ref expirationDate, ref isActive , ref createdByUserID))
            {
                return new clsInternationalLicense(internationalLicenseID, applicationID, driverID, localLicenseID, issueDate, 
                    expirationDate, isActive,  createdByUserID);
            }
            else
            {
                return null;
            }
        }

        public static int isExistActiveInternationalLicense(int LocalLicenseID)
        {
            return clsInternationalLicenseData.isExistActiveInternationalLicense(LocalLicenseID);
        }

        private bool _AddNewInternationalLicense()
        {
            this.InternationalLicenseID = clsInternationalLicenseData._AddNewInternationalLicense(this.ApplicationID , this.DriverID , this.LocalLicenseID 
                , this.IssueDate , this.ExpirationDate , this.IsActive , this.CreatedByUserID);

            return (this.InternationalLicenseID != -1);
        }

        public bool Save()
        {
            switch (_Mode)
            {
                case enMode.AddNew:
                    if (_AddNewInternationalLicense())
                    {
                        return true;
                    }
                    break;
            }

            return false;
        }

    }
}
