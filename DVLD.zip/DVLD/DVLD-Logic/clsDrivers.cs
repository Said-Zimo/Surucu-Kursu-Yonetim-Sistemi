﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsDrivers
    {
        public int DriverID { get; set; }
        public int PersonID { get; set; }
        public int CreatedByUserID { get; set; }
        public DateTime CreatedDate  { get; set; }

        public clsDrivers()
        {
            DriverID = -1;
            PersonID = -1;
            CreatedByUserID = -1;
            CreatedDate = DateTime.Now;
        }

        public static DataTable GetAllDriversData()
        {
            return clsDriversData.GetAllDriversData();
        }

        private bool _AddNewDriver()
        {
            this.DriverID = clsDriversData.AddNewDriver(this.PersonID , this.CreatedByUserID , this.CreatedDate); 

            return (this.DriverID != -1);
        }

        public bool Save()
        {
            return _AddNewDriver();
        }

        public static int DriverExist(int PersonID)
        {
            return clsDriversData.DriverExist(PersonID);
        }



    }
}
