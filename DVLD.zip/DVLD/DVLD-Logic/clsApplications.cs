﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsApplications
    {
        enum enMode { AddNew = 1 , Update = 2}
        private enMode _Mode = enMode.AddNew;

        public int ApplicationID { get; set; }
        public int AppPersonID {  get; set; }
        public DateTime ApplicationDate { get; set; }
        public int ApplicationTypeID { get; set; }
        public byte ApplicationStatus { get; set; }
        public DateTime LastStateDate { get; set; }
        public decimal PaidFees { get; set; }
        public int CreatedByUser { get; set; }


        public clsApplications()
        {
            ApplicationID = -1;
            AppPersonID = -1;
            ApplicationStatus = 0;
            ApplicationDate = DateTime.Now;
            ApplicationTypeID = -1;
            LastStateDate = DateTime.Now;
            PaidFees = -1;
            CreatedByUser = -1;
            _Mode = enMode.AddNew;
        }

        private clsApplications(int applicationID ,int appPersonID, DateTime applicationDate, int applicationTypeID, byte applicationStatus,
                DateTime lastStateDate, decimal paidFees, int createdByUserID)
        {
            this.ApplicationID = applicationID;
            this.AppPersonID = appPersonID;
            this.ApplicationDate = applicationDate;
            this.ApplicationTypeID = applicationTypeID;
            this.LastStateDate = lastStateDate;
            this.ApplicationStatus = applicationStatus;
            this.PaidFees = paidFees;
            this.CreatedByUser = createdByUserID;
            _Mode = enMode.Update;
        }

        private bool _AddNewApplication()
        {
            
            this.ApplicationID =  clsApplicationsData.AddNewApplication( this.AppPersonID, this.ApplicationDate , 
                this.ApplicationTypeID , this.ApplicationStatus, this.LastStateDate , this.PaidFees , this.CreatedByUser);

            return (ApplicationID != -1);
        }

        public static clsApplications FindApplication(int ApplicationID)
        {
            int personID = -1, applicationTypeID = -1, createdByUserID = -1;
            DateTime applicationDate = DateTime.Now , lastStatusUpdateDate = DateTime.Now;
            byte applicationStatus = 0;
            decimal paidFees = -1;

            if (clsApplicationsData.FindApplication(ApplicationID , ref personID , ref applicationDate ,ref applicationTypeID , ref applicationStatus , ref lastStatusUpdateDate ,ref paidFees , ref createdByUserID))
            {
                return new clsApplications(ApplicationID,  personID,  applicationDate,  applicationTypeID,  applicationStatus,  lastStatusUpdateDate,  paidFees,  createdByUserID);
            }
            else
            {
                return null;
            }
        }

        private bool _UpdateApplication()
        {
            return clsApplicationsData.UpdateApplication(this.ApplicationID, this.AppPersonID, this.ApplicationDate, this.ApplicationTypeID, this.ApplicationStatus, this.LastStateDate, this.PaidFees, this.CreatedByUser);
        }

        public bool Save()
        {
            switch (_Mode)
            {
                case enMode.AddNew:
                    if (_AddNewApplication())
                    {
                        return true;
                    }
                    break;
                case enMode.Update:
                    if (_UpdateApplication())
                    {
                        return true;
                    }
                    break;
            }
            return false;
        }
        
        public static bool DeleteApplication(int ApplicationID)
        {
            return  clsApplicationsData.DeleteApplication(ApplicationID);
        }

    }
}
