﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsLicense
    {
        enum enMode { AddNew =1 , Update =2}
        private enMode _Mode = enMode.AddNew;

        public int LicenseID { get; set; }
        public int ApplicationID { get; set; }
        public int DriverID { get; set; }
        public int LicenseClassID { get; set; }
        public DateTime IssuedDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string Notes { get; set; }
        public decimal PaidFees { get; set; }
        public bool IsActive { get; set; }
        public byte IssueReason { get; set; }
        public int CreatedByUserID { get; set; }

        public string IssueReasonString { get; set; }

        public static bool isLicenseIssued(int ApplicationID)
        {
            return clsLicenseData.isLicenseIssued(ApplicationID);
        }

        public clsLicense()
        {
            this.LicenseID = -1;
            this.ApplicationID = -1;
            this.DriverID = -1;
            this.LicenseClassID = -1;
            this.IssuedDate = DateTime.Now;
            this.ExpirationDate = DateTime.Now;
            this.Notes = "";
            this.PaidFees = -1;
            this.IsActive = false;
            this.IssueReason = 0;
            this.CreatedByUserID = -1;

            _Mode = enMode.AddNew;
        }

        private clsLicense(int LicenseID , int ApplicationID , int DriverID , int LicenseClassID , DateTime isIssueDate , DateTime ExpirationDate ,
            string Notes , decimal PaidFees , bool isActive , byte IssueReason ,string issueReasonString, int CreatedByUserID)
        {
            this.LicenseID = LicenseID;
            this.ApplicationID = ApplicationID;
            this.DriverID = DriverID;
            this.LicenseClassID = LicenseClassID;
            this.IssuedDate = isIssueDate;
            this.ExpirationDate = ExpirationDate;
            this.Notes = Notes;
            this.PaidFees = PaidFees;
            this.IsActive = isActive;
            this.IssueReason = IssueReason;
            this.IssueReasonString = issueReasonString;
            this.CreatedByUserID = CreatedByUserID;

            _Mode = enMode.Update;
        }


        private bool _AddNewLicense()
        {
            this.LicenseID = clsLicenseData.AddNewLicense(this.ApplicationID , this.DriverID , this.LicenseClassID , this.IssuedDate
               , this.ExpirationDate , this.Notes , this.PaidFees , this.IsActive , this.IssueReason , this.CreatedByUserID);

            return (LicenseID != -1);
        }

        private bool _UpdateLicense()
        {
            return clsLicenseData.UpdateLicense(this.LicenseID ,this.ApplicationID, this.DriverID, this.LicenseClassID, this.IssuedDate
               , this.ExpirationDate, this.Notes, this.PaidFees, this.IsActive, this.IssueReason, this.CreatedByUserID);
        }

        public bool Save()
        {
            switch (_Mode)
            {
                case enMode.AddNew:
                    if (_AddNewLicense())
                    {
                        return true;
                    }
                    break;

                case enMode.Update:
                    if (_UpdateLicense())
                    {
                        return true;
                    }
                    break;
            }

            return false;
        }

        public static bool isActiveLocalLicenseFromClass3(int licenseID)
        {
            return clsLicenseData.isActiveLocalLicenseFromClass3(licenseID);
        }

        public static clsLicense FindLicense(int licenseID)
        {
            int  applicationID = -1 , driverID = -1 ,  licenseClassID = -1 , createdByUserID = -1;
            DateTime issueDate = DateTime.Now , expirationDate = DateTime.Now;
            string notes = "" , issueReasonString = "";
            decimal paidFees = -1;
            bool isActive = false;
            byte issueReason = 0;

            if (clsLicenseData.FindLicense( licenseID, ref applicationID, ref driverID, ref licenseClassID, ref issueDate, ref expirationDate,
                                      ref notes, ref paidFees, ref isActive, ref issueReason,ref issueReasonString, ref createdByUserID))
            {
                return new clsLicense(licenseID, applicationID, driverID, licenseClassID, issueDate, expirationDate,
                                       notes, paidFees, isActive, issueReason, issueReasonString, createdByUserID);
            }
            else
            {
                return null;
            }

        }

        public static int FindLicenseIdByApplicationID(int applicationID)
        {
            return clsLicenseData.FindLicenseIdByApplicationID(applicationID);
        }

        public static bool isHasActiveLicenseWithPersonIDAndLicenseClass(int PersonID ,  int LicenseClassID)
        {
            return clsLicenseData.isHasActiveLicenseWithPersonIDAndLicenseClass(PersonID , LicenseClassID);
        }

        public static DataTable GetAllLocalLicense(int PersonID)
        {

            return clsLicenseData.GetAllLocalLicense(PersonID);

        }

        public static DataTable GetAllInternationalLicense(int PersonID)
        {

            return clsLicenseData.GetAllInternationalLicense(PersonID);

        }

    }
}
