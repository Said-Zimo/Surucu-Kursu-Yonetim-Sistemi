﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Logic
{
    public class clsAppointment
    {
        enum enMode { AddNew = 1 , Update =  2 }
        private enMode _Mode = enMode.AddNew;


        public int TestAppointmentID { get; set; }
        public int TestTypeID { get; set; }
        public int LDLAppID { get; set; }
        public DateTime AppointmentDate { get; set; }
        public decimal PaidFees { get; set; }
        public int CreatedByUserID { get; set; }
        public bool isLocked { get; set; }

        public clsAppointment()
        {
            this.TestAppointmentID = -1;
            this.TestTypeID = -1;
            this.LDLAppID = -1;
            this.AppointmentDate = DateTime.Now;
            this.PaidFees = -1;
            this.CreatedByUserID = -1;
            this.isLocked = true;
            _Mode = enMode.AddNew;
        }

        private clsAppointment(int TestAppointmentID, int TestTypeID, int LDLAppID, DateTime AppointmentDate, decimal PaidFees, int CreatedByUserID, bool isLocked)
        {
            this.TestAppointmentID = TestAppointmentID;
            this.TestTypeID = TestTypeID;
            this.LDLAppID = LDLAppID;
            this.AppointmentDate = AppointmentDate;
            this.PaidFees = PaidFees;
            this.CreatedByUserID = CreatedByUserID;
            this.isLocked = isLocked;
            _Mode = enMode.Update;
        }

        public static clsAppointment FindAppointment(int TestAppointmentID)
        {
            int testTypeID = -1, createdByUserID = -1 , lDLAppID = -1;
            DateTime appointmentDate = DateTime.Now ;
            decimal paidFees = -1;
            bool IsLocked = true;

            if (clsAppointmentData.FindAppointmentData(TestAppointmentID, ref testTypeID , ref lDLAppID, ref appointmentDate, ref paidFees, ref createdByUserID, ref IsLocked))
            {
                return new clsAppointment(TestAppointmentID,testTypeID,  lDLAppID,  appointmentDate,  paidFees,  createdByUserID,  IsLocked);
            }
            else
            {
                return null;
            }
        }

        public static DataTable GetAllAppointmentDetails(int LDLAppID , int TestTypeID)
        {
            return clsAppointmentData.GetAllAppointmentDetails(LDLAppID, TestTypeID);
        }

        public static bool isActiveAppointment(int LDLAppID , int TestTypeID)
        {
            return clsAppointmentData.isActiveAppointment(LDLAppID, TestTypeID);
        }

        public static bool isActiveAppointment(int AppointmentID)
        {
            return clsAppointmentData.isActiveAppointment(AppointmentID);
        }

        private bool _AddNewAppointment()
        {
            this.TestAppointmentID = clsAppointmentData.AddNewAppointment(this.TestTypeID , this.LDLAppID , this.AppointmentDate ,this.PaidFees , this.CreatedByUserID , this.isLocked);

            return (TestAppointmentID != -1);
        }

        private bool _UpdateAppointment()
        {
            return clsAppointmentData.UpdateAppointment(this.TestAppointmentID ,this.TestTypeID, this.LDLAppID, this.AppointmentDate, this.PaidFees, this.CreatedByUserID, this.isLocked);
        }

        public bool Save()
        {
            switch (_Mode)
            {
                case enMode.AddNew:
                    if (_AddNewAppointment())
                    {
                        _Mode = enMode.Update;
                        return true;
                    }
                break;

                case enMode.Update:
                {
                    if (_UpdateAppointment())
                    {
                        _Mode = enMode.Update;
                        return true;
                    }
                 break;
                }
            }
            return false;
        }
    }
}
