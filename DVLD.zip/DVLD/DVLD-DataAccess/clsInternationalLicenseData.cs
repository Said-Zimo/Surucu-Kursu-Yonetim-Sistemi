﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD_DataAccess
{
    public static class clsInternationalLicenseData
    {

        public static DataTable GetAllInternationalLicenses()
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT InternationalLicenseID, ApplicationID, DriverID, IssuedUsingLocalLicenseID as LocalLicenseID, IssueDate, ExpirationDate, IsActive
                               FROM     InternationalLicenses";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();

            }
            catch
            {
                dt = null;
            }
            finally
            {
                connection.Close();
            }


            return dt;
        }

        public static int isExistActiveInternationalLicense(int LocalLicenseID)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT InternationalLicenseID, ApplicationID, IssuedUsingLocalLicenseID AS LocalLicenseID, IssueDate, ExpirationDate, IsActive
                                 FROM     InternationalLicenses
                                     WHERE IssuedUsingLocalLicenseID = @LocalLicenseID and  (IsActive = 1)";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LocalLicenseID", LocalLicenseID);


            try
            {
                connection.Open();
                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int Result))
                {
                    ID = Result;
                }

            }
            catch
            {
                ID = -1;
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }

        public static int _AddNewInternationalLicense(int ApplicationID , int DriverID , int LocalLicenseID
                , DateTime IssueDate , DateTime ExpirationDate , bool isActive , int CreatedByUserID)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO InternationalLicenses
                                    ([ApplicationID] ,[DriverID] ,[IssuedUsingLocalLicenseID] ,[IssueDate] ,[ExpirationDate] ,[IsActive] ,[CreatedByUserID])
                              VALUES
                                    (@ApplicationID ,@DriverID, @IssuedUsingLocalLicenseID ,@IssueDate ,@ExpirationDate,@IsActive,@CreatedByUserID);
                      SELECT SCOPE_IDENTITY()";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            command.Parameters.AddWithValue("@DriverID", DriverID);
            command.Parameters.AddWithValue("@IssuedUsingLocalLicenseID", LocalLicenseID);
            command.Parameters.AddWithValue("@IssueDate", IssueDate);
            command.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);
            command.Parameters.AddWithValue("@IsActive", isActive);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);


            try
            {
                connection.Open();
                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int Result))
                {
                    ID = Result;
                }

            }
            catch
            {
                ID = -1;
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }

        public static bool FindInternationalLicense(int InternationalLicenseID, ref int ApplicationID,ref int LocalLicenseID, ref int DriverID,  ref DateTime IssueDate, ref DateTime ExpirationDate,
          ref bool isActive,  ref int CreatedByUserID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"Select * from InternationalLicenses where InternationalLicenseID = @InternationalLicenseID";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@InternationalLicenseID", InternationalLicenseID);


            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    
                    ApplicationID = (int)reader["ApplicationID"];
                    DriverID = (int)reader["DriverID"];
                    LocalLicenseID = (int)reader["IssuedUsingLocalLicenseID"];
                    IssueDate = (DateTime)reader["IssueDate"];
                    ExpirationDate = (DateTime)reader["ExpirationDate"];
                    isActive = (bool)reader["isActive"];
                    CreatedByUserID = (int)reader["CreatedByUserID"];
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }


            return isFound;
        }


    }
}
