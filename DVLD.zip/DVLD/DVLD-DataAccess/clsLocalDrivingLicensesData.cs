﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD_DataAccess
{
    public static class clsLocalDrivingLicensesData
    {

        public static bool DeleteLocalLicenseApplication(int LDLAppID)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"DELETE FROM LocalDrivingLicenseApplications
                                      WHERE LocalDrivingLicenseApplicationID = @LDLAppID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);

            try
            {
                connection.Open();
                short effectedRows = (short)command.ExecuteNonQuery();

                isDeleted = (effectedRows > 0);


            }
            catch
            {

                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }



            return isDeleted;
        }

        public static DataTable GetAllLocalLicenseApplications()
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = "Select * from LocalDrivingLicenseApplications_View";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if(reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch
            {
                return null;
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static int FindUnderReviewApplication(string NationalNo, string ClassName)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT [L.D.L.AppID]
                             FROM     LocalDrivingLicenseApplications_View 
                           where ClassName = @ClassName and NationalNo = @NationalNo and Status = 'New' ;";



            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@NationalNo", NationalNo);
            command.Parameters.AddWithValue("@ClassName", ClassName);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int result))
                {
                    ID = result;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }

        public static int AddNewLocalLicense(int applicationID , int licenseClassID)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO LocalDrivingLicenseApplications
                                          ([ApplicationID] ,[LicenseClassID])
                                    VALUES
                                          (@ApplicationID ,@LicenseClassID);
		                select  Scope_Identity();";



            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@ApplicationID", applicationID);
            command.Parameters.AddWithValue("@LicenseClassID", licenseClassID);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int result))
                {
                    ID = result;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }

        public static bool FindLocalLicenseApplication(int LDLAppID, ref int applicationID,ref int licenseClassID, ref string licenseClassName,
           ref string nationalNo, ref string fullName, ref DateTime applicationDate, ref int passedTest, ref string status)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT * FROM LocalDrivingAppCard_View where LocalDrivingAppCard_View.[L.D.L.AppID] = @LDLAppID";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    applicationID = (int)reader["ApplicationID"];
                    licenseClassID = (int)reader["LicenseClassID"];
                    licenseClassName = (string)reader["ClassName"];
                    nationalNo = (string)reader["NationalNo"];
                    fullName = (string)reader["FullName"];
                    applicationDate = (DateTime)reader["ApplicationDate"];
                    passedTest = (int)reader["PassedTests"];
                    status = (string)reader["Status"];
                    
                }
                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isFound;



        }

        public static string GetLocalLicenseAppStatus(int LDLAppID)
        {
            string Status = "";

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT CASE WHEN ApplicationStatus = 1 THEN 'New' WHEN ApplicationStatus = 2 THEN 'Cancelled' WHEN ApplicationStatus = 3 THEN 'Completed' END AS 'Status'
                            FROM     Applications INNER JOIN
                  LocalDrivingLicenseApplications ON Applications.ApplicationID = LocalDrivingLicenseApplications.ApplicationID where LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LDLAppID";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null )
                {

                    Status = (string)scalar;

                }

                
            }
            catch 
            {
                Status = "Null";
            }
            finally
            {
                connection.Close();
            }

            return Status;

        }
    }
}
