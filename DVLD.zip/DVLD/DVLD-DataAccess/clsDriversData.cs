﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD_DataAccess
{
    public static class clsDriversData
    {

        public static DataTable GetAllDriversData()
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT * FROM Drivers_View ";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }


            return dt;
        }

        public static int DriverExist(int PersonID)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT DriverID FROM Drivers WHERE PersonID = @PersonID";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString() , out int result))
                {
                    ID = result;
                }

            }
            catch 
            {
                ID = -1;
            }
            finally
            {
                connection.Close();
            }


            return ID;
        }


        public static int AddNewDriver(int PersonID , int CreatedByUserID , DateTime CreatedDate)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO Drivers
                                  ([PersonID],[CreatedByUserID] ,[CreatedDate])
                            VALUES
                                  (@PersonID, @CreatedByUserID, @CreatedDate);
                      SELECT SCOPE_IDENTITY()";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            command.Parameters.AddWithValue("@CreatedDate", CreatedDate);


            try
            {
                connection.Open();
                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int Result))
                {
                    ID = Result;
                }

            }
            catch
            {
                ID = -1;
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }

    }
}
