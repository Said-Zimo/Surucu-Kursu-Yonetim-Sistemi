﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD_DataAccess
{
    public static class clsDetainLicenseData
    {

        public static bool FindDetainLicenseByLicenseID(ref int DetainID , int LicenseID, ref DateTime DetainDate, ref decimal DetainFees,
            ref int CreatedByUserID, ref bool IsReleased, ref DateTime ReleaseDate, ref int ReleasedByUserID, ref int ReleasedApplicationID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT * FROM DetainedLicenses WHERE LicenseID = @LicenseID";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@LicenseID", LicenseID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    DetainID = (int)reader["DetainID"];
                    DetainDate = (DateTime)reader["DetainDate"];
                    DetainFees = (decimal)reader["FineFees"];
                    CreatedByUserID = (int)reader["CreatedByUserID"];
                    IsReleased = (bool)reader["IsReleased"];
                    ReleaseDate = (reader["ReleaseDate"] == DBNull.Value) ? DateTime.Now : (DateTime)reader["ReleaseDate"];
                    ReleasedByUserID = (reader["ReleasedByUserID"] == DBNull.Value) ? -1 : (int)reader["ReleasedByUserID"];
                    ReleasedApplicationID = (reader["ReleasedApplicationID"] == DBNull.Value) ? -1 : (int)reader["ReleasedApplicationID"];
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }


            return isFound;
        }

        public static bool ReleaseDetainLicense(int LicenseID, DateTime DetainDate, decimal DetainFees, int CreatedByUserID, bool IsReleased , DateTime ReleaseDate , int ReleasedByUserID ,int ReleaseApplicationID)
        {
            bool isReleased = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"UPDATE DetainedLicenses
                               SET [LicenseID] = @LicenseID
                                  ,[DetainDate] = @DetainDate
                                  ,[FineFees] = @DetainFees
                                  ,[CreatedByUserID] = @CreatedByUserID
                                  ,[IsReleased] = @IsReleased
                                  ,[ReleaseDate] = @ReleaseDate
                                  ,[ReleasedByUserID] = @ReleasedByUserID
                                  ,[ReleaseApplicationID] = @ReleaseApplicationID
                             WHERE LicenseID = @LicenseID;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LicenseID", LicenseID);
            command.Parameters.AddWithValue("@DetainDate", DetainDate);
            command.Parameters.AddWithValue("@DetainFees", DetainFees);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            command.Parameters.AddWithValue("@IsReleased", IsReleased);
            command.Parameters.AddWithValue("@ReleaseDate", ReleaseDate);
            command.Parameters.AddWithValue("@ReleasedByUserID", ReleasedByUserID);
            command.Parameters.AddWithValue("@ReleaseApplicationID", ReleaseApplicationID);

            try
            {
                connection.Open();

                int effectedRows = command.ExecuteNonQuery();

                isReleased = (effectedRows > 0);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isReleased;
        }

        public static int AddNewDetain(int LicenseID , DateTime DetainDate , decimal DetainFees , int CreatedByUserID ,bool IsReleased)
        {

            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO DetainedLicenses
                                ([LicenseID]   ,[DetainDate],[FineFees] ,[CreatedByUserID] ,[IsReleased] ,[ReleaseDate] ,[ReleasedByUserID],[ReleaseApplicationID])
                          VALUES
                                (@LicenseID ,@DetainDate ,@DetainFees ,@CreatedByUserID ,@IsReleased ,NULL ,NULL,NULL);
                      SELECT SCOPE_IDENTITY()";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LicenseID", LicenseID);
            command.Parameters.AddWithValue("@DetainDate", DetainDate);
            command.Parameters.AddWithValue("@DetainFees", DetainFees);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            command.Parameters.AddWithValue("@IsReleased", IsReleased);


            try
            {
                connection.Open();
                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int Result))
                {
                    ID = Result;
                }

            }
            catch
            {
                ID = -1;
            }
            finally
            {
                connection.Close();
            }

            return ID;


        }

        public static bool isDetained(int licenseID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"select * from DetainedLicenses where LicenseID = @licenseID AND ReleaseApplicationID Is Null";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@licenseID", licenseID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                isFound = (reader.HasRows);
                

            }
            catch
            {
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static DataTable GetAllDetainLicenseList()
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT DetainedLicenses.DetainID, DetainedLicenses.LicenseID, DetainedLicenses.DetainDate, DetainedLicenses.IsReleased, DetainedLicenses.FineFees, case when DetainedLicenses.ReleaseDate is Null then 'Not Released Yet' end as ReleaseDate, People.NationalNo, People.FirstName + ' ' +
                                           People.SecondName + ' ' + ISNull(People.ThirdName , '') + ' ' +  People.LastName AS FullName, case when DetainedLicenses.ReleaseApplicationID is NULL then 'Not Released' end as ReleaseApplicationID
                         FROM     DetainedLicenses INNER JOIN
                                          Licenses ON DetainedLicenses.LicenseID = Licenses.LicenseID INNER JOIN
                                          Drivers ON Licenses.DriverID = Drivers.DriverID INNER JOIN
                                          People ON Drivers.PersonID = People.PersonID";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();

            }
            catch
            {
                dt = null;
            }
            finally
            {
                connection.Close();
            }


            return dt;
        }

    }
}
