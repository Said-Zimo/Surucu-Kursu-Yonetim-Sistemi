﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_DataAccess
{
    public static class clsUserData
    {
        
        public static bool FindUser(string UserName , ref int UserID , ref int PersonID,ref string personFullName,  ref string Password , ref bool isActive)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT Users.UserID, Users.PersonID, FullName = People.FirstName + ' ' + People.SecondName+ ' ' + People.ThirdName+ ' ' + People.LastName, Users.UserName, Users.Password, Users.IsActive
                              FROM     People INNER JOIN
                                        Users ON People.PersonID = Users.PersonID WHERE UserName = @UserName";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@UserName", UserName);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    UserID = (int)reader["UserID"];
                    PersonID = (int)reader["PersonID"];
                    personFullName = (string)reader["FullName"];
                    Password = (string)reader["Password"];
                    isActive = (bool)reader["isActive"];
                }

                reader.Close();

            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }


            return isFound;
        }

        public static bool FindUser(int UserID , ref string UserName, ref int PersonID, ref string personFullName, ref string Password, ref bool isActive)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT Users.UserID, Users.PersonID, FullName = People.FirstName + ' ' + People.SecondName+ ' ' + People.ThirdName+ ' ' + People.LastName, Users.UserName, Users.Password, Users.IsActive
                              FROM     People INNER JOIN
                                        Users ON People.PersonID = Users.PersonID WHERE UserID = @UserID";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@UserID", UserID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    UserName = (string)reader["UserName"];
                    PersonID = (int)reader["PersonID"];
                    personFullName = (string)reader["FullName"];
                    Password = (string)reader["Password"];
                    isActive = (bool)reader["isActive"];
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }


            return isFound;
        }


        public static bool UserExist(int PersonID)
        {
            bool isExist = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"select isFound = 1 from Users where PersonID = @PersonID";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.Parse(result.ToString()) == 1)
                {
                    isExist = true;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }


            return isExist;
        }

        public static DataTable GetAllUsersData()
        {

            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT Users.UserID, Users.PersonID, FullName = People.FirstName + ' ' + People.SecondName+ ' ' + People.ThirdName+ ' ' + People.LastName, Users.UserName, Users.IsActive
                              FROM     People INNER JOIN
                                        Users ON People.PersonID = Users.PersonID ";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close ();

            }
            catch 
            {
                dt = null;
            }
            finally
            {
                connection.Close();
            }


            return dt;
        }

        public static bool DeleteUser(int UserID)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"DELETE FROM Users
                                      WHERE UserID = @UserID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@UserID", UserID);

            try
            {
                connection.Open();
                short effectedRows = (short)command.ExecuteNonQuery();

                isDeleted = (effectedRows > 0);


            }
            catch 
            {

                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }



            return isDeleted;
        }

        public static int AddNewUser(int PersonID , string UserName , string Password , bool isActive)
        {

            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO Users (PersonID  ,UserName ,Password ,IsActive)
                                VALUES (@PersonID, @UserName,  @Password, @IsActive);
		                SELECT  Scope_Identity();";



            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);
            command.Parameters.AddWithValue("@UserName", UserName);
            command.Parameters.AddWithValue("@Password", Password);
            command.Parameters.AddWithValue("@IsActive", isActive);


            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int result))
                {
                    ID = result;
                }




            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }

        public static bool UpdateUser(int UserID , int PersonID, string UserName, string Password, bool isActive)
        {

            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"UPDATE Users
                             SET PersonID = @PersonID
                                ,UserName = @UserName
                                ,Password = @Password
                                ,IsActive = @IsActive
                           WHERE UserID = @UserID;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("UserID", UserID);
            command.Parameters.AddWithValue("PersonID", PersonID);
            command.Parameters.AddWithValue("@UserName", UserName);
            command.Parameters.AddWithValue("@Password", Password);
            command.Parameters.AddWithValue("@IsActive", isActive);

            try
            {
                connection.Open();

                int effectedRows = command.ExecuteNonQuery();

                isUpdated = (effectedRows > 0);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;


        }

    }
}
