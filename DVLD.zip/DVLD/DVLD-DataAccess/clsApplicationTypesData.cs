﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_DataAccess
{
    public static class clsApplicationTypesData
    {

        public static bool UpdateAppTypeDetails(int id , string title , decimal fees)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"UPDATE ApplicationTypes
                                SET ApplicationTypeTitle = @title
                                   ,ApplicationFees = @fees
                                   WHERE ApplicationTypeID = @id";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@title", title);
            command.Parameters.AddWithValue("@fees", fees);

            try
            {
                connection.Open();

                short effectedRow = (short)command.ExecuteNonQuery();

                isUpdated = (effectedRow > 0);
                
            }
            catch
            {
                isUpdated = false;
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;

        }

        public static bool FindApplicationType(int id, ref string title, ref decimal fees)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT * FROM ApplicationTypes WHERE ApplicationTypeID = @id";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@id", id);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;


                    title = (string)reader["ApplicationTypeTitle"];
                    fees = (decimal)reader["ApplicationFees"];
                }

                reader.Close();

            }
            catch 
            {
                isFound = false;
            }
            finally
            {
                connection.Close();
            }


            return isFound;
        }

        public static DataTable GetAllAppTypesData()
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = "SELECT ApplicationTypeID As ID, ApplicationTypeTitle As Title, ApplicationFees As Fees FROM   ApplicationTypes";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();

            }
            catch
            {
                return null;
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }
    }
}
