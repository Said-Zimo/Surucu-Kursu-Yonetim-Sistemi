﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_DataAccess
{
    public static class clsTestTypesData
    {

        public static DataTable GetAllTestTypesData()
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = "SELECT TestTypeID as ID, TestTypeTitle as Title, TestTypeDescription as Description, TestTypeFees as Fees FROM TestTypes";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();

            }
            catch
            {
                return null;
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool FindTestType(int id, ref string title,ref string description , ref decimal fees)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT * FROM TestTypes WHERE TestTypeID = @id";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@id", id);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    id = (int)reader["TestTypeID"];
                    title = (string)reader["TestTypeTitle"];
                    description = (string)reader["TestTypeDescription"];
                    fees = (decimal)reader["TestTypeFees"];
                }

                reader.Close();

            }
            catch
            {
                isFound = false;
            }
            finally
            {
                connection.Close();
            }


            return isFound;
        }

        public static bool UpdateTestTypeDetails(int id, string title, string description , decimal fees)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"UPDATE TestTypes
                                  SET TestTypeTitle = @title
                                     ,TestTypeDescription = @description
                                     ,TestTypeFees = @fees
                                WHERE TestTypeID = @id";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@title", title);
            command.Parameters.AddWithValue("@description",description);
            command.Parameters.AddWithValue("@fees", fees);

            try
            {
                connection.Open();

                short effectedRow = (short)command.ExecuteNonQuery();

                isUpdated = (effectedRow > 0);

            }
            catch
            {
                isUpdated = false;
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;

        }



    }
}
