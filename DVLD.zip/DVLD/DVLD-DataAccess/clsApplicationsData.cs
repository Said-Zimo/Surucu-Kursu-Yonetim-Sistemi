﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_DataAccess
{
    public static class clsApplicationsData
    {

        public static int AddNewApplication( int appPersonID, DateTime applicationDate, int applicationTypeID, byte applicationStatus,
                DateTime lastStateDate, decimal paidFees, int createdByUserID)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO Applications
                              ([ApplicantPersonID] ,[ApplicationDate] ,[ApplicationTypeID] ,[ApplicationStatus] ,[LastStatusDate]  ,[PaidFees] ,[CreatedByUserID])
                               VALUES
                            (@appPersonID ,@applicationDate ,@applicationTypeID  ,@applicationStatus ,@lastStateDate ,@paidFees,@createdByUserID);
		                SELECT  Scope_Identity();";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@appPersonID", appPersonID);
            command.Parameters.AddWithValue("@applicationDate", applicationDate);
            command.Parameters.AddWithValue("@applicationTypeID", applicationTypeID);
            command.Parameters.AddWithValue("@applicationStatus", applicationStatus);
            command.Parameters.AddWithValue("@lastStateDate", lastStateDate);
            command.Parameters.AddWithValue("@paidFees", paidFees);
            command.Parameters.AddWithValue("@createdByUserID", createdByUserID);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int result))
                {
                    ID = result;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }


        public static bool FindApplication(int AppID ,ref int appPersonID, ref DateTime applicationDate, ref int applicationTypeID, ref byte applicationStatus,
               ref DateTime lastStateDate, ref decimal paidFees, ref int createdByUserID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT * FROM Applications WHERE ApplicationID = @AppID;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@AppID", AppID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    appPersonID = (int)reader["ApplicantPersonID"];
                    applicationDate = (DateTime)reader["ApplicationDate"];
                    applicationTypeID = (int)reader["ApplicationTypeID"];
                    applicationStatus = (byte)reader["ApplicationStatus"];
                    lastStateDate = (DateTime)reader["LastStatusDate"];
                    paidFees = (decimal)reader["PaidFees"];
                    createdByUserID = (int)reader["CreatedByUserID"];

                    reader.Close();

                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool UpdateApplication(int AppID,  int appPersonID,  DateTime applicationDate,  int applicationTypeID,  byte applicationStatus,
                DateTime lastStateDate,  decimal paidFees,  int createdByUserID)
        {

            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"UPDATE Applications
                                 SET [ApplicantPersonID] = @ApplicantPersonID
                                    ,[ApplicationDate] = @ApplicationDate
                                    ,[ApplicationTypeID] = @ApplicationTypeID
                                    ,[ApplicationStatus] = @ApplicationStatus
                                    ,[LastStatusDate] = @LastStatusDate
                                    ,[PaidFees] = @PaidFees
                                    ,[CreatedByUserID] = @CreatedByUserID
                               WHERE ApplicationID = @AppID";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@AppID", AppID);
            command.Parameters.AddWithValue("ApplicantPersonID", appPersonID);
            command.Parameters.AddWithValue("@ApplicationDate", applicationDate);
            command.Parameters.AddWithValue("@ApplicationTypeID", applicationTypeID);
            command.Parameters.AddWithValue("@ApplicationStatus", applicationStatus);
            command.Parameters.AddWithValue("@LastStatusDate", lastStateDate);
            command.Parameters.AddWithValue("@PaidFees", paidFees);
            command.Parameters.AddWithValue("@CreatedByUserID", createdByUserID);


            try
            {
                connection.Open();

                int effectedRows = command.ExecuteNonQuery();

                isUpdated = (effectedRows > 0);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;
        }

        public static bool DeleteApplication(int ApplicationID)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"DELETE FROM Applications
                                      WHERE ApplicationID = @ApplicationID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ApplicationID", ApplicationID);

            try
            {
                connection.Open();
                short effectedRows = (short)command.ExecuteNonQuery();

                isDeleted = (effectedRows > 0);


            }
            catch
            {

                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }



            return isDeleted;
        }

    }
}
