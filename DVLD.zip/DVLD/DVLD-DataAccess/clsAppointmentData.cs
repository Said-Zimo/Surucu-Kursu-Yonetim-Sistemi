﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_DataAccess
{
    public static class clsAppointmentData
    {


        public static bool FindAppointmentData(int TestAppointmentID,ref int TestTypeID,ref int LDLAppID, ref DateTime AppointmentDate,ref  decimal PaidFees,ref int CreatedByUserID, ref bool isLocked)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT * FROM TestAppointments where TestAppointmentID =@TestAppointmentID ";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    TestAppointmentID = (int)reader["TestAppointmentID"];
                    TestTypeID = (int)reader["TestTypeID"];
                    LDLAppID = (int)reader["LocalDrivingLicenseApplicationID"];
                    AppointmentDate = (DateTime)reader["AppointmentDate"];
                    PaidFees = (decimal)reader["PaidFees"];
                    CreatedByUserID = (int)reader["CreatedByUserID"];
                    isLocked = (bool)reader["IsLocked"];
                }

                reader.Close();

            }
            catch 
            {
                isFound = false;
            }
            finally
            {
                connection.Close();
            }


            return isFound;
        }

        public static DataTable GetAllAppointmentDetails(int LDLAppID , int TestTypeID)
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT TestAppointments.TestAppointmentID AS AppointmentID, TestAppointments.AppointmentDate AS [Appointment Date], TestAppointments.PaidFees AS [Paid Fees], TestAppointments.IsLocked AS [Is Locked] 
                  
                         FROM     TestAppointments INNER JOIN
                                           LocalDrivingLicenseApplications ON TestAppointments.LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID
                         WHERE  (LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LDLAppID and TestTypeID = @TestTypeID);";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {

                    dt.Load(reader);

                }
                reader.Close();
            }
            catch
            {
                dt= null;
            }
            finally
            {
                connection.Close();
            }


            return dt;
        }


        public static bool isActiveAppointment(int LDLAppID, int TestTypeID)
        {
            bool isActive = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT isActive = 1

                           FROM     TestAppointments INNER JOIN
                                             LocalDrivingLicenseApplications ON 
                                             TestAppointments.LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID
                           WHERE  (LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LDLAppID and TestTypeID = @TestTypeID and IsLocked = 0)";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString() , out int result))
                {

                    isActive = (result == 1);

                }
               
            }
            catch
            {
                isActive = false;
            }
            finally
            {
                connection.Close();
            }


            return isActive;
        }

        public static bool isActiveAppointment(int AppointmentID)
        {
            bool isActive = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT isActive = 1

                                 FROM     TestAppointments INNER JOIN
                                                LocalDrivingLicenseApplications ON 
                                                TestAppointments.LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID
                              WHERE  (TestAppointmentID = @AppointmentID and IsLocked = 0)";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@AppointmentID", AppointmentID);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int result))
                {

                    isActive = (result == 1);

                }

            }
            catch
            {
                isActive = false;
            }
            finally
            {
                connection.Close();
            }


            return isActive;
        }

        public static int AddNewAppointment(int TestTypeID , int LDLAppID ,DateTime AppointmentDate ,decimal PaidFees , int CreatedByUserID , bool isLocked)
        {
            int AppointmentID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO TestAppointments
                                  ([TestTypeID] ,[LocalDrivingLicenseApplicationID] ,[AppointmentDate] ,[PaidFees],[CreatedByUserID],[IsLocked])
                            VALUES
                                  (@TestTypeID  ,@LocalDrivingLicenseApplicationID  ,@AppointmentDate ,@PaidFees ,@CreatedByUserID  ,@IsLocked);;
		                SELECT  Scope_Identity();";



            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            command.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LDLAppID);
            command.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
            command.Parameters.AddWithValue("@PaidFees", PaidFees);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            command.Parameters.AddWithValue("@IsLocked", isLocked);


            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString(), out int result))
                {
                    AppointmentID = result;
                }




            }
            catch 
            {
                AppointmentID = -1;
            }
            finally
            {
                connection.Close();
            }

            return AppointmentID;
        }


        public static bool UpdateAppointment(int TestAppointmentID ,int TestTypeID, int LDLAppID, DateTime AppointmentDate, decimal PaidFees, int CreatedByUserID, bool isLocked)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"UPDATE TestAppointments
                               SET [TestTypeID] = @TestTypeID
                                  ,[LocalDrivingLicenseApplicationID] = @LocalDrivingLicenseApplicationID
                                  ,[AppointmentDate] = @AppointmentDate
                                  ,[PaidFees] = @PaidFees
                                  ,[CreatedByUserID] = @CreatedByUserID
                                  ,[IsLocked] = @IsLocked
                             WHERE  TestAppointmentID = @TestAppointmentID;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("TestAppointmentID", TestAppointmentID);
            command.Parameters.AddWithValue("TestTypeID", TestTypeID);
            command.Parameters.AddWithValue("LocalDrivingLicenseApplicationID", LDLAppID);
            command.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
            command.Parameters.AddWithValue("@PaidFees", PaidFees);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            command.Parameters.AddWithValue("@IsLocked", isLocked);

            try
            {
                connection.Open();

                int effectedRows = command.ExecuteNonQuery();

                isUpdated = (effectedRows > 0);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;

        }

    }
}
