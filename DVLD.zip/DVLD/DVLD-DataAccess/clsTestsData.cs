﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_DataAccess
{
    public static class clsTestsData
    {
        public static short PassedTestCount(int LDLAppID)
        {
            short PassedTestsCount = 0;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT distinct Count(*)
                      FROM      Tests INNER JOIN
                                               TestAppointments ON Tests.TestAppointmentID = TestAppointments.TestAppointmentID
		  	           			 INNER JOIN LocalDrivingLicenseApplications on LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = TestAppointments.LocalDrivingLicenseApplicationID
		  	           			 INNER JOIN TestTypes on TestAppointments.TestTypeID = TestTypes.TestTypeID
                                  
                           WHERE  LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LDLAppID and  Tests.TestResult = 1 ;";



            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);


            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && short.TryParse(scalar.ToString(), out short result))
                {
                    PassedTestsCount = result;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return PassedTestsCount;
        }

        public static short FailedTestCount(int LDLAppID , int TestTypeID)
        {
            short failedTestCount = 0;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT  Count(*)
                      FROM      Tests INNER JOIN
                                               TestAppointments ON Tests.TestAppointmentID = TestAppointments.TestAppointmentID
		  	           			 INNER JOIN LocalDrivingLicenseApplications on LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = TestAppointments.LocalDrivingLicenseApplicationID
		  	           			 
                           WHERE  LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LDLAppID and  Tests.TestResult = 0 and  TestTypeID = @TestTypeID";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);



            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && short.TryParse(scalar.ToString(), out short result))
                {
                    failedTestCount = result;
                }


            }
            catch
            {
                failedTestCount = 0;
            }
            finally
            {
                connection.Close();
            }

            return failedTestCount;



        }

        public static bool SaveTestInfo(int TestAppointmentID , bool TestResult , string TestNotes ,int CreatedByUserID)
        {
            bool isSaved = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO Tests
                               ([TestAppointmentID] ,[TestResult] ,[Notes],[CreatedByUserID])
                         VALUES
                               (@TestAppointmentID  ,@TestResult ,@Notes ,@CreatedByUserID);";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            command.Parameters.AddWithValue("@TestResult", TestResult);
            
            if (string.IsNullOrWhiteSpace(TestNotes))
            {
                command.Parameters.AddWithValue("@Notes", DBNull.Value);
            }
            else
            {
                command.Parameters.AddWithValue("@Notes", TestNotes);
            }
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);

            try
            {
                connection.Open();

                int effectedRows = command.ExecuteNonQuery();

                isSaved = (effectedRows > 0);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isSaved;
        }

        public static bool FindPassedTest(int LDLAppID , int TestTypeID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT isFound = 1 
                         FROM     TestAppointments INNER JOIN
                                           LocalDrivingLicenseApplications ON TestAppointments.LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID
										   inner join Tests on Tests.TestAppointmentID = TestAppointments.TestAppointmentID
                         WHERE  (LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LDLAppID and TestTypeID = @TestTypeID and Tests.TestResult = 1);";

            SqlCommand command = new SqlCommand(Query , connection);
            command.Parameters.AddWithValue("@LDLAppID" , LDLAppID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    isFound = true;
                }


            }
            catch
            {
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;

        }

        public static int FindRetakeTestAppointment(int LDLAppID ,int TestTypeID)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT TestAppointments.TestAppointmentID, TestAppointments.TestTypeID
                                FROM     LocalDrivingLicenseApplications INNER JOIN
                                      TestAppointments ON LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = TestAppointments.LocalDrivingLicenseApplicationID
                                WHERE  (LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LDLAppID) AND (TestAppointments.TestTypeID = @TestTypeID) AND (TestAppointments.IsLocked = 0)";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString() , out int Result))
                {
                    ID = Result;
                }

                

            }
            catch 
            {
               ID = -1;
            }
            finally
            {
                connection.Close();
            }


            return ID;
        }


    }
}
