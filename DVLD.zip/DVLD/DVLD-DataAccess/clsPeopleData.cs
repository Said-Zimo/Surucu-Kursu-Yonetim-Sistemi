﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_DataAccess
{
    public static class clsPeopleData
    {

        public static DataTable GetAllPeopleData()
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string query = @"SELECT People.PersonID, People.NationalNo, People.FirstName, People.SecondName, People.ThirdName, People.LastName, People.DateOfBirth, Case  WHEN People.Gendor = 0 THEN 'Male'  WHEN People.Gendor = 1 THEN 'Female'  ELSE 'Unknow' End as Gendor, Countries.CountryName as Nationality, People.Phone, People.Email
                             FROM People INNER JOIN
                                 Countries ON People.NationalityCountryID = Countries.CountryID";

            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {

                    dt.Load(reader);
                    
                    
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

                
            return dt;
        }

        public static bool FindPeople(int PersonID , ref string nationalNo, ref string firstName, ref string secondName, ref string thirdName, ref string lastName,
               ref string gendor, ref string email, ref string address, ref string phone, ref DateTime dateOfBirth, ref int country, ref string countryName)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT People.PersonID, People.NationalNo, People.FirstName, People.SecondName, People.ThirdName, People.LastName, People.DateOfBirth, People.Gendor, People.Address, People.Phone, People.Email, People.NationalityCountryID, 
                              Countries.CountryName
                               FROM     People INNER JOIN
                                Countries ON People.NationalityCountryID = Countries.CountryID 
                                 WHERE PersonID = @PersonID;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read()) 
                {
                    isFound = true;

                    nationalNo = (string)reader["NationalNO"];
                    firstName = (string)reader["FirstName"];
                    secondName = (string)reader["SecondName"];
                    lastName = (string)reader["LastName"];
                    countryName = (string)reader["CountryName"];
                    address = (string)reader["Address"];
                    phone = (string)reader["Phone"];
                    country = (int)reader["NationalityCountryID"];
                    dateOfBirth = (DateTime)reader["DateOfBirth"];

                    if (reader["ThirdName"] != DBNull.Value)
                    {
                        thirdName = (string)reader["ThirdName"];
                    }
                    else
                    {
                        thirdName = "";
                    }

                    if (reader["Email"] != DBNull.Value)
                    {
                        email = (string)reader["Email"];
                    }
                    else
                    {
                        email = "";
                    }


                    if (reader["Gendor"].ToString() == "0")
                    {
                        gendor = "Male";
                    }
                    else
                    {
                        gendor = "Female";
                    }

                        reader.Close();

                }


            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isFound;

        }

        public static bool FindPeople(ref int personID, string NationalNo, ref string firstName, ref string secondName, ref string thirdName, ref string lastName,
               ref string gendor, ref string email, ref string address, ref string phone, ref DateTime dateOfBirth, ref int country , ref string countryName)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT People.PersonID, People.NationalNo, People.FirstName, People.SecondName, People.ThirdName, People.LastName, People.DateOfBirth, People.Gendor, People.Address, People.Phone, People.Email, People.NationalityCountryID, Countries.CountryName
                               FROM     People   INNER    JOIN
                                Countries ON People.NationalityCountryID = Countries.CountryID  WHERE NationalNo = @NationalNo;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@NationalNo", NationalNo);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    personID = (int)reader["PersonID"];
                    firstName = (string)reader["FirstName"];
                    secondName = (string)reader["SecondName"];                    
                    lastName = (string)reader["LastName"];                    
                    address = (string)reader["Address"];
                    phone = (string)reader["Phone"];
                    country = (int)reader["NationalityCountryID"];
                    dateOfBirth = (DateTime)reader["DateOfBirth"];
                    countryName = (string)reader["CountryName"];

                    if (reader["ThirdName"] != DBNull.Value)
                    {
                        thirdName = (string)reader["ThirdName"];
                    }
                    else
                    {
                        thirdName = "";
                    }

                    if (reader["Email"] != DBNull.Value)
                    {
                        email = (string)reader["Email"];
                    }
                    else
                    {
                        email = "";
                    }



                    if (reader["Gendor"].ToString() == "0")
                    {
                        gendor = "Male";
                    }
                    else
                    {
                        gendor = "Female";
                    }

                    reader.Close();

                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isFound;

        }


        public static int AddPeopleData( string NationalNo,  string firstName,  string secondName,  string thirdName,  string lastName,
                byte gendor,  string email,  string address,  string phone,  DateTime dateOfBirth,  int country)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO People (NationalNo  ,FirstName ,SecondName ,ThirdName ,LastName ,DateOfBirth ,Gendor,Address,Phone ,Email ,NationalityCountryID,ImagePath)
                                VALUES (@NationalNo, @FirstName,  @SecondName, @ThirdName,  @LastName,  @DateOfBirth,  @Gendor,  @Address,  @Phone, @Email, @CountryID , Null);
		                select  Scope_Identity();";



            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@NationalNo", NationalNo);
            command.Parameters.AddWithValue("@FirstName", firstName);
            command.Parameters.AddWithValue("@SecondName", secondName);

            if (string.IsNullOrWhiteSpace(thirdName))
            {
                command.Parameters.AddWithValue("@ThirdName", DBNull.Value);
            }
            else
            {
                command.Parameters.AddWithValue("@ThirdName", thirdName);
            }

            command.Parameters.AddWithValue("@LastName", lastName);
            command.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);
            command.Parameters.AddWithValue("@Gendor", gendor);
            command.Parameters.AddWithValue("@Address", address);
            command.Parameters.AddWithValue("@Phone", phone);
            command.Parameters.AddWithValue("@CountryID", country);

            if (string.IsNullOrWhiteSpace(email) )
            {
                command.Parameters.AddWithValue("@Email", DBNull.Value);
            }
            else
            {
                command.Parameters.AddWithValue("@Email", email);
            }
            


            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString() , out int result))
                {
                    ID = result;
                }




            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }



        public static bool UpdatePersonInfo(int PersnID ,string NationalNo, string firstName, string secondName, string thirdName, string lastName,
                byte gendor, string email, string address, string phone, DateTime dateOfBirth, int country)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"UPDATE People
                               SET NationalNo = @NationalNo
                                  ,FirstName = @FirstName
                                  ,SecondName = @SecondName
                                  ,ThirdName = @ThirdName
                                  ,LastName = @LastName
                                  ,DateOfBirth = @DateOfBirth
                                  ,Gendor = @Gendor
                                  ,Address = @Address
                                  ,Phone = @Phone
                                  ,Email = @Email
                                  ,NationalityCountryID = @CountryID
                                  ,ImagePath = Null
                            
                             WHERE PersonID = @PersonID;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("PersonID", PersnID);
            command.Parameters.AddWithValue("@NationalNo", NationalNo);
            command.Parameters.AddWithValue("@FirstName", firstName);
            command.Parameters.AddWithValue("@SecondName", secondName);

            if (string.IsNullOrWhiteSpace(thirdName))
            {
                command.Parameters.AddWithValue("@ThirdName", DBNull.Value);
            }
            else
            {
                command.Parameters.AddWithValue("@ThirdName", thirdName);
            }

            command.Parameters.AddWithValue("@LastName", lastName);
            command.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);
            command.Parameters.AddWithValue("@Gendor", gendor);
            command.Parameters.AddWithValue("@Address", address);
            command.Parameters.AddWithValue("@Phone", phone);
            command.Parameters.AddWithValue("@CountryID", country);

            if (string.IsNullOrWhiteSpace(email))
            {
                command.Parameters.AddWithValue("@Email", DBNull.Value);
            }
            else
            {
                command.Parameters.AddWithValue("@Email", email);
            }


            try
            {
                connection.Open();

                int effectedRows = command.ExecuteNonQuery();

                isUpdated = (effectedRows > 0);

            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;

        }



        public static bool DeletePerson(int PersonID)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"DELETE FROM People
                                      WHERE PersonID = @PersonID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID" , PersonID);

            try
            {
                connection.Open();
                short effectedRows = (short)command.ExecuteNonQuery();

                isDeleted = (effectedRows > 0);


            }
            catch (Exception ex) { 

                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }



            return isDeleted;


        }



    }
}
