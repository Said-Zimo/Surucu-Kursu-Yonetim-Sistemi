﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_DataAccess
{
    static internal class clsConnectionString
    {
        public static string GetConnectionString = "Server = .; DataBase = DVLD; User Id =sa;Password = 123456";
    }
}
