﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD_DataAccess
{
    public static class clsLicenseData
    {
        public static DataTable GetAllLocalLicense(int PersonID)
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT Licenses.LicenseID, Licenses.ApplicationID, LicenseClasses.ClassName, Licenses.IssueDate, Licenses.ExpirationDate, Licenses.IsActive
                               FROM     Licenses INNER JOIN
                                        LicenseClasses ON Licenses.LicenseClass = LicenseClasses.LicenseClassID INNER JOIN
                                        Drivers ON Licenses.DriverID = Drivers.DriverID WHERE PersonID = @PersonID ";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();

            }
            catch
            {
                dt = null;
            }
            finally
            {
                connection.Close();
            }


            return dt;
        }

        public static DataTable GetAllInternationalLicense(int PersonID)
        {
            DataTable dt = new DataTable();

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT InternationalLicenses.InternationalLicenseID, InternationalLicenses.ApplicationID, InternationalLicenses.IssuedUsingLocalLicenseID as LocalLicenseID, InternationalLicenses.IssueDate, InternationalLicenses.ExpirationDate, 
                               InternationalLicenses.IsActive
                               FROM     InternationalLicenses INNER JOIN
                               Drivers ON InternationalLicenses.DriverID = Drivers.DriverID where PersonID = @PersonID ";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID" , PersonID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();

            }
            catch
            {
                dt = null;
            }
            finally
            {
                connection.Close();
            }


            return dt;
        }

        public static int AddNewLicense(int ApplicationID, int DriverID, int LicenseClassID, DateTime IssueDate
               , DateTime ExpirationDate, string Notes, decimal PaidFees, bool isActive , byte IssueReason , int CreatedByUserID)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"INSERT INTO Licenses
                           ([ApplicationID] ,[DriverID] ,[LicenseClass] ,[IssueDate] ,[ExpirationDate]  ,[Notes] ,[PaidFees] ,[IsActive],[IssueReason],[CreatedByUserID])
                     VALUES
                           (@ApplicationID ,@DriverID ,@LicenseClassID ,@IssueDate ,@ExpirationDate ,@Notes ,@PaidFees ,@IsActive ,@IssueReason ,@CreatedByUserID);
                      SELECT SCOPE_IDENTITY()";     


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            command.Parameters.AddWithValue("@DriverID", DriverID);
            command.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);
            command.Parameters.AddWithValue("@IssueDate", IssueDate);
            command.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);

            if (string.IsNullOrWhiteSpace(Notes))
            {
                command.Parameters.AddWithValue("@Notes", DBNull.Value);
            }
            else
            {
                command.Parameters.AddWithValue("@Notes", Notes);
            }

            command.Parameters.AddWithValue("@PaidFees", PaidFees);
            command.Parameters.AddWithValue("@IsActive", isActive);
            command.Parameters.AddWithValue("@IssueReason", IssueReason);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);


            try
            {
                connection.Open();
                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString() , out int Result))
                {
                    ID = Result;
                }

            }
            catch
            {
                ID = -1;
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }

        public static bool FindLicense(int LicenseID,ref int ApplicationID, ref int DriverID, ref int LicenseClassID, ref DateTime IssueDate, ref DateTime ExpirationDate,
          ref string Notes, ref decimal PaidFees, ref bool isActive, ref byte IssueReason,ref string issueReasonString, ref int CreatedByUserID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT LicenseID, ApplicationID, DriverID, LicenseClass, IssueDate, ExpirationDate, Notes, PaidFees, IsActive, IssueReason ,

                              CASE 
                              WHEN IssueReason = 1 THEN 'First Time'
                              WHEN IssueReason = 2 THEN 'Renew'
                              WHEN IssueReason = 3 THEN 'Lost Replacement'
                              WHEN IssueReason = 4 THEN 'Damaged Replacement'
                              END as IssueReasonString
                              
                              , CreatedByUserID
                              FROM     Licenses WHERE LicenseID = @LicenseID";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@LicenseID", LicenseID);


            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = true;

                    ApplicationID = (int)reader["ApplicationID"];
                    DriverID = (int)reader["DriverID"];
                    LicenseClassID = (int)reader["LicenseClass"];
                    IssueDate = (DateTime)reader["IssueDate"];
                    ExpirationDate = (DateTime)reader["ExpirationDate"];
                    Notes = (reader["Notes"] != DBNull.Value) ? (string)reader["Notes"] : "No Notes";
                    PaidFees = (decimal)reader["PaidFees"];
                    isActive = (bool)reader["isActive"];
                    IssueReason = (byte)reader["IssueReason"];
                    issueReasonString = (string)reader["IssueReasonString"];
                    CreatedByUserID = (int)reader["CreatedByUserID"];
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }


            return isFound;
        }

        public static bool UpdateLicense(int LicenseID , int ApplicationID, int DriverID, int LicenseClassID, DateTime IssueDate
               , DateTime ExpirationDate, string Notes, decimal PaidFees, bool isActive, byte IssueReason, int CreatedByUserID)
        {
            bool isUpdated = false ;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"UPDATE Licenses
                                SET [ApplicationID] = @ApplicationID
                                   ,[DriverID] = @DriverID
                                   ,[LicenseClass] = @LicenseClassID
                                   ,[IssueDate] = @IssueDate
                                   ,[ExpirationDate] = @ExpirationDate
                                   ,[Notes] = @Notes
                                   ,[PaidFees] = @PaidFees
                                   ,[IsActive] = @IsActive
                                   ,[IssueReason] = @IssueReason
                                   ,[CreatedByUserID] = @CreatedByUserID
                              WHERE LicenseID = @LicenseID";


            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LicenseID", LicenseID);
            command.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            command.Parameters.AddWithValue("@DriverID", DriverID);
            command.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);
            command.Parameters.AddWithValue("@IssueDate", IssueDate);
            command.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);

            if (string.IsNullOrWhiteSpace(Notes))
            {
                command.Parameters.AddWithValue("@Notes", DBNull.Value);
            }
            else
            {
                command.Parameters.AddWithValue("@Notes", Notes);
            }
            
            command.Parameters.AddWithValue("@PaidFees", PaidFees);
            command.Parameters.AddWithValue("@IsActive", isActive);
            command.Parameters.AddWithValue("@IssueReason", IssueReason);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);


            try
            {
                connection.Open();
                int effectedRow = command.ExecuteNonQuery();

                isUpdated = (effectedRow >0);
                
            }
            catch
            {
                isUpdated = false;
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;

        }

        public static bool isLicenseIssued(int AppID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT ApplicationID from Licenses where ApplicationID = @AppID;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@AppID", AppID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    isFound = true;
                }

            }
            catch 
            {
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int FindLicenseIdByApplicationID(int AppID)
        {
            int ID = -1;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT LicenseID from Licenses where ApplicationID = @AppID;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@AppID", AppID);

            try
            {
                connection.Open();

                object scalar = command.ExecuteScalar();

                if (scalar != null && int.TryParse(scalar.ToString() , out int result))
                {
                    ID = result;

                }


            }
            catch
            {
                ID= -1;
            }
            finally
            {
                connection.Close();
            }

            return ID;
        }

        public static bool isHasActiveLicenseWithPersonIDAndLicenseClass(int PersonID , int LicenseClassID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT Licenses.LicenseID, Licenses.DriverID, Licenses.LicenseClass, Licenses.IsActive, Drivers.PersonID
                             FROM     Drivers INNER JOIN
                                  Licenses ON Drivers.DriverID = Licenses.DriverID 
				                  WHERE PersonID = @PersonID and LicenseClass = @LicenseClassID and isActive = 1;";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);
            command.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    isFound = true;
                }

            }
            catch
            {
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool isActiveLocalLicenseFromClass3(int LicenseID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsConnectionString.GetConnectionString);

            string Query = @"SELECT *
                                FROM  Licenses
                                WHERE LicenseID = @LicenseID and  (LicenseClass = 3) AND (IsActive = 1);";

            SqlCommand command = new SqlCommand(Query, connection);

            command.Parameters.AddWithValue("@LicenseID", LicenseID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    isFound = true;
                }

            }
            catch
            {
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }
    }
}
