﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ManageDriversScreen : Form
    {
        public ManageDriversScreen()
        {
            InitializeComponent();
        }

        private void _RefreshDriversData()
        {
            dgvDrivers.DataSource = clsDrivers.GetAllDriversData();
            lblCountRecords.Text = dgvDrivers.Rows.Count.ToString();

        }

        private void ManageDriversScreen_Load(object sender, EventArgs e)
        {
            _RefreshDriversData();
        }

        private void _SwitchFilter()
        {
            if (cbDriversFilter.Text == "None")
            {
                txtDriversFilter.Visible = false;
                txtDriversFilter.Text = "";
            }
            else
            {
                txtDriversFilter.Visible = true;
                txtDriversFilter.Focus();
            }
        }

        private void cbDriversFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            _SwitchFilter();
        }

        private void _ApplyFilter(string columnName)
        {
            DataTable dt = (DataTable)dgvDrivers.DataSource;

            if (cbDriversFilter.Text == "Driver ID" || cbDriversFilter.Text == "Person ID")
            {
                if (!char.IsNumber(txtDriversFilter.Text, 0) || !char.IsNumber(txtDriversFilter.Text, txtDriversFilter.Text.Length - 1))
                {
                    txtDriversFilter.Text = "";
                    MessageBox.Show("Please enter just a Numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                dt.DefaultView.RowFilter = $"{columnName} = {int.Parse(txtDriversFilter.Text)} ";
                lblCountRecords.Text = dt.DefaultView.Count.ToString();

            }
            else
            {
                dt.DefaultView.RowFilter = $"{columnName} LIKE '{txtDriversFilter.Text}%' ";
                lblCountRecords.Text = dt.DefaultView.Count.ToString();
            }

        }

        private void txtDriversFilter_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtDriversFilter.Text))
            {
                _ApplyFilter(cbDriversFilter.Text.Replace(" " , ""));
            }
            else
            {
                _RefreshDriversData();
            }
        }
    }
}
