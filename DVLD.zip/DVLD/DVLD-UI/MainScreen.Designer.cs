﻿namespace DVLD
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.msMenu = new System.Windows.Forms.MenuStrip();
            this.aplicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newDrivingLeceseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.localLicenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAddNewLocalLicenseApp = new System.Windows.Forms.ToolStripMenuItem();
            this.nationalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.internationalLicenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.replacementLostOrDamagetLicenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.releaseDetainedDrivingLicenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.replacmentLostOrDamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.localDrivingLicenseAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.internationalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.relToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageDetainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detainLicenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.releaseDetainLicenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.retakeTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageTestTypesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.peToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.driversToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountSittingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currentUserInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.singoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.msMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // msMenu
            // 
            this.msMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.msMenu.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.msMenu.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.msMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aplicToolStripMenuItem,
            this.peToolStripMenuItem,
            this.driversToolStripMenuItem,
            this.usersToolStripMenuItem,
            this.accountSittingsToolStripMenuItem});
            this.msMenu.Location = new System.Drawing.Point(0, 0);
            this.msMenu.MdiWindowListItem = this.accountSittingsToolStripMenuItem;
            this.msMenu.Name = "msMenu";
            this.msMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.msMenu.Size = new System.Drawing.Size(205, 593);
            this.msMenu.TabIndex = 0;
            // 
            // aplicToolStripMenuItem
            // 
            this.aplicToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newDrivingLeceseToolStripMenuItem,
            this.toolStripMenuItem1,
            this.replacmentLostOrDamToolStripMenuItem,
            this.toolStripMenuItem2,
            this.relToolStripMenuItem,
            this.retakeTestToolStripMenuItem,
            this.manageTestTypesToolStripMenuItem});
            this.aplicToolStripMenuItem.Image = global::DVLD.Properties.Resources.contract;
            this.aplicToolStripMenuItem.Name = "aplicToolStripMenuItem";
            this.aplicToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20);
            this.aplicToolStripMenuItem.Size = new System.Drawing.Size(198, 74);
            this.aplicToolStripMenuItem.Text = " Aplications";
            // 
            // newDrivingLeceseToolStripMenuItem
            // 
            this.newDrivingLeceseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.localLicenseToolStripMenuItem,
            this.internationalLicenseToolStripMenuItem,
            this.toolStripMenuItem3,
            this.replacementLostOrDamagetLicenseToolStripMenuItem,
            this.toolStripMenuItem4,
            this.releaseDetainedDrivingLicenseToolStripMenuItem});
            this.newDrivingLeceseToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newDrivingLeceseToolStripMenuItem.Image = global::DVLD.Properties.Resources.id;
            this.newDrivingLeceseToolStripMenuItem.Name = "newDrivingLeceseToolStripMenuItem";
            this.newDrivingLeceseToolStripMenuItem.Size = new System.Drawing.Size(306, 36);
            this.newDrivingLeceseToolStripMenuItem.Text = "Driving License Services";
            // 
            // localLicenseToolStripMenuItem
            // 
            this.localLicenseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiAddNewLocalLicenseApp,
            this.nationalToolStripMenuItem});
            this.localLicenseToolStripMenuItem.Image = global::DVLD.Properties.Resources.id_add;
            this.localLicenseToolStripMenuItem.Name = "localLicenseToolStripMenuItem";
            this.localLicenseToolStripMenuItem.Size = new System.Drawing.Size(381, 28);
            this.localLicenseToolStripMenuItem.Text = "New Driving License";
            // 
            // tsmiAddNewLocalLicenseApp
            // 
            this.tsmiAddNewLocalLicenseApp.Image = global::DVLD.Properties.Resources.location;
            this.tsmiAddNewLocalLicenseApp.Name = "tsmiAddNewLocalLicenseApp";
            this.tsmiAddNewLocalLicenseApp.Size = new System.Drawing.Size(191, 28);
            this.tsmiAddNewLocalLicenseApp.Tag = "1";
            this.tsmiAddNewLocalLicenseApp.Text = "Local";
            this.tsmiAddNewLocalLicenseApp.Click += new System.EventHandler(this.localToolStripMenuItem_Click);
            // 
            // nationalToolStripMenuItem
            // 
            this.nationalToolStripMenuItem.Image = global::DVLD.Properties.Resources.world;
            this.nationalToolStripMenuItem.Name = "nationalToolStripMenuItem";
            this.nationalToolStripMenuItem.Size = new System.Drawing.Size(191, 28);
            this.nationalToolStripMenuItem.Text = "international";
            this.nationalToolStripMenuItem.Click += new System.EventHandler(this.nationalToolStripMenuItem_Click);
            // 
            // internationalLicenseToolStripMenuItem
            // 
            this.internationalLicenseToolStripMenuItem.Image = global::DVLD.Properties.Resources.id_reload;
            this.internationalLicenseToolStripMenuItem.Name = "internationalLicenseToolStripMenuItem";
            this.internationalLicenseToolStripMenuItem.Size = new System.Drawing.Size(381, 28);
            this.internationalLicenseToolStripMenuItem.Text = "Renew Driving License";
            this.internationalLicenseToolStripMenuItem.Click += new System.EventHandler(this.internationalLicenseToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(378, 6);
            // 
            // replacementLostOrDamagetLicenseToolStripMenuItem
            // 
            this.replacementLostOrDamagetLicenseToolStripMenuItem.Image = global::DVLD.Properties.Resources.id_refresh;
            this.replacementLostOrDamagetLicenseToolStripMenuItem.Name = "replacementLostOrDamagetLicenseToolStripMenuItem";
            this.replacementLostOrDamagetLicenseToolStripMenuItem.Size = new System.Drawing.Size(381, 28);
            this.replacementLostOrDamagetLicenseToolStripMenuItem.Text = "Replacment Lost or Damaget  License";
            this.replacementLostOrDamagetLicenseToolStripMenuItem.Click += new System.EventHandler(this.replacementLostOrDamagedLicenseToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(378, 6);
            // 
            // releaseDetainedDrivingLicenseToolStripMenuItem
            // 
            this.releaseDetainedDrivingLicenseToolStripMenuItem.Image = global::DVLD.Properties.Resources.id_unlock;
            this.releaseDetainedDrivingLicenseToolStripMenuItem.Name = "releaseDetainedDrivingLicenseToolStripMenuItem";
            this.releaseDetainedDrivingLicenseToolStripMenuItem.Size = new System.Drawing.Size(381, 28);
            this.releaseDetainedDrivingLicenseToolStripMenuItem.Text = "Release Detained Driving License";
            this.releaseDetainedDrivingLicenseToolStripMenuItem.Click += new System.EventHandler(this.releaseDetainedDrivingLicenseToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(303, 6);
            // 
            // replacmentLostOrDamToolStripMenuItem
            // 
            this.replacmentLostOrDamToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.localDrivingLicenseAppToolStripMenuItem,
            this.internationalToolStripMenuItem});
            this.replacmentLostOrDamToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.replacmentLostOrDamToolStripMenuItem.Image = global::DVLD.Properties.Resources.cms;
            this.replacmentLostOrDamToolStripMenuItem.Name = "replacmentLostOrDamToolStripMenuItem";
            this.replacmentLostOrDamToolStripMenuItem.Size = new System.Drawing.Size(306, 36);
            this.replacmentLostOrDamToolStripMenuItem.Text = "Manage Applications";
            // 
            // localDrivingLicenseAppToolStripMenuItem
            // 
            this.localDrivingLicenseAppToolStripMenuItem.Image = global::DVLD.Properties.Resources.location;
            this.localDrivingLicenseAppToolStripMenuItem.Name = "localDrivingLicenseAppToolStripMenuItem";
            this.localDrivingLicenseAppToolStripMenuItem.Size = new System.Drawing.Size(292, 28);
            this.localDrivingLicenseAppToolStripMenuItem.Text = "Local License App.";
            this.localDrivingLicenseAppToolStripMenuItem.Click += new System.EventHandler(this.localDrivingLicenseAppToolStripMenuItem_Click);
            // 
            // internationalToolStripMenuItem
            // 
            this.internationalToolStripMenuItem.Image = global::DVLD.Properties.Resources.world;
            this.internationalToolStripMenuItem.Name = "internationalToolStripMenuItem";
            this.internationalToolStripMenuItem.Size = new System.Drawing.Size(292, 28);
            this.internationalToolStripMenuItem.Text = "International License App.";
            this.internationalToolStripMenuItem.Click += new System.EventHandler(this.internationalToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(303, 6);
            // 
            // relToolStripMenuItem
            // 
            this.relToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manageDetainToolStripMenuItem,
            this.detainLicenseToolStripMenuItem,
            this.releaseDetainLicenseToolStripMenuItem});
            this.relToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.relToolStripMenuItem.Image = global::DVLD.Properties.Resources.encrypt;
            this.relToolStripMenuItem.Name = "relToolStripMenuItem";
            this.relToolStripMenuItem.Size = new System.Drawing.Size(306, 36);
            this.relToolStripMenuItem.Text = "Detain License";
            // 
            // manageDetainToolStripMenuItem
            // 
            this.manageDetainToolStripMenuItem.Image = global::DVLD.Properties.Resources.cms;
            this.manageDetainToolStripMenuItem.Name = "manageDetainToolStripMenuItem";
            this.manageDetainToolStripMenuItem.Size = new System.Drawing.Size(271, 28);
            this.manageDetainToolStripMenuItem.Text = "Manage Detain License";
            this.manageDetainToolStripMenuItem.Click += new System.EventHandler(this.manageDetainToolStripMenuItem_Click);
            // 
            // detainLicenseToolStripMenuItem
            // 
            this.detainLicenseToolStripMenuItem.Image = global::DVLD.Properties.Resources._lock;
            this.detainLicenseToolStripMenuItem.Name = "detainLicenseToolStripMenuItem";
            this.detainLicenseToolStripMenuItem.Size = new System.Drawing.Size(271, 28);
            this.detainLicenseToolStripMenuItem.Text = "Detain License";
            this.detainLicenseToolStripMenuItem.Click += new System.EventHandler(this.detainLicenseToolStripMenuItem_Click);
            // 
            // releaseDetainLicenseToolStripMenuItem
            // 
            this.releaseDetainLicenseToolStripMenuItem.Image = global::DVLD.Properties.Resources.id_refresh;
            this.releaseDetainLicenseToolStripMenuItem.Name = "releaseDetainLicenseToolStripMenuItem";
            this.releaseDetainLicenseToolStripMenuItem.Size = new System.Drawing.Size(271, 28);
            this.releaseDetainLicenseToolStripMenuItem.Text = "Release Detain License";
            this.releaseDetainLicenseToolStripMenuItem.Click += new System.EventHandler(this.releaseDetainLicenseToolStripMenuItem_Click);
            // 
            // retakeTestToolStripMenuItem
            // 
            this.retakeTestToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.retakeTestToolStripMenuItem.Image = global::DVLD.Properties.Resources.Application1;
            this.retakeTestToolStripMenuItem.Name = "retakeTestToolStripMenuItem";
            this.retakeTestToolStripMenuItem.Size = new System.Drawing.Size(306, 36);
            this.retakeTestToolStripMenuItem.Text = "Manage Application Types";
            this.retakeTestToolStripMenuItem.Click += new System.EventHandler(this.retakeTestToolStripMenuItem_Click);
            // 
            // manageTestTypesToolStripMenuItem
            // 
            this.manageTestTypesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manageTestTypesToolStripMenuItem.Image = global::DVLD.Properties.Resources.php_docs;
            this.manageTestTypesToolStripMenuItem.Name = "manageTestTypesToolStripMenuItem";
            this.manageTestTypesToolStripMenuItem.Size = new System.Drawing.Size(306, 36);
            this.manageTestTypesToolStripMenuItem.Text = "Manage Test Types";
            this.manageTestTypesToolStripMenuItem.Click += new System.EventHandler(this.manageTestTypesToolStripMenuItem_Click);
            // 
            // peToolStripMenuItem
            // 
            this.peToolStripMenuItem.Image = global::DVLD.Properties.Resources.clients__1_;
            this.peToolStripMenuItem.Name = "peToolStripMenuItem";
            this.peToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20);
            this.peToolStripMenuItem.Size = new System.Drawing.Size(198, 74);
            this.peToolStripMenuItem.Text = "  People";
            this.peToolStripMenuItem.Click += new System.EventHandler(this.peToolStripMenuItem_Click);
            // 
            // driversToolStripMenuItem
            // 
            this.driversToolStripMenuItem.Image = global::DVLD.Properties.Resources.steering_wheel;
            this.driversToolStripMenuItem.Name = "driversToolStripMenuItem";
            this.driversToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20);
            this.driversToolStripMenuItem.Size = new System.Drawing.Size(198, 74);
            this.driversToolStripMenuItem.Text = " Drivers";
            this.driversToolStripMenuItem.Click += new System.EventHandler(this.driversToolStripMenuItem_Click);
            // 
            // usersToolStripMenuItem
            // 
            this.usersToolStripMenuItem.Image = global::DVLD.Properties.Resources.administrator;
            this.usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            this.usersToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20);
            this.usersToolStripMenuItem.Size = new System.Drawing.Size(198, 74);
            this.usersToolStripMenuItem.Text = " Users";
            this.usersToolStripMenuItem.Click += new System.EventHandler(this.usersToolStripMenuItem_Click);
            // 
            // accountSittingsToolStripMenuItem
            // 
            this.accountSittingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.currentUserInfoToolStripMenuItem,
            this.changePasswordToolStripMenuItem,
            this.toolStripMenuItem5,
            this.singoutToolStripMenuItem});
            this.accountSittingsToolStripMenuItem.Image = global::DVLD.Properties.Resources.webmaster;
            this.accountSittingsToolStripMenuItem.Name = "accountSittingsToolStripMenuItem";
            this.accountSittingsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20);
            this.accountSittingsToolStripMenuItem.Size = new System.Drawing.Size(198, 74);
            this.accountSittingsToolStripMenuItem.Text = "Acc. Settings";
            // 
            // currentUserInfoToolStripMenuItem
            // 
            this.currentUserInfoToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentUserInfoToolStripMenuItem.Image = global::DVLD.Properties.Resources.administrator;
            this.currentUserInfoToolStripMenuItem.Name = "currentUserInfoToolStripMenuItem";
            this.currentUserInfoToolStripMenuItem.Size = new System.Drawing.Size(240, 36);
            this.currentUserInfoToolStripMenuItem.Text = "Current User Info";
            this.currentUserInfoToolStripMenuItem.Click += new System.EventHandler(this.currentUserInfoToolStripMenuItem_Click);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changePasswordToolStripMenuItem.Image = global::DVLD.Properties.Resources.password__1_;
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(240, 36);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(237, 6);
            // 
            // singoutToolStripMenuItem
            // 
            this.singoutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.singoutToolStripMenuItem.Image = global::DVLD.Properties.Resources.administrator_delete;
            this.singoutToolStripMenuItem.Name = "singoutToolStripMenuItem";
            this.singoutToolStripMenuItem.Size = new System.Drawing.Size(240, 36);
            this.singoutToolStripMenuItem.Text = "Sign Out";
            this.singoutToolStripMenuItem.Click += new System.EventHandler(this.signOutToolStripMenuItem_Click);
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::DVLD.Properties.Resources.Untitled_design__2_;
            this.ClientSize = new System.Drawing.Size(1194, 593);
            this.Controls.Add(this.msMenu);
            this.ForeColor = System.Drawing.Color.Black;
            this.MainMenuStrip = this.msMenu;
            this.Name = "MainScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainScreen";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainScreen_FormClosing);
            this.msMenu.ResumeLayout(false);
            this.msMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip msMenu;
        private System.Windows.Forms.ToolStripMenuItem aplicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem peToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem driversToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountSittingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newDrivingLeceseToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem replacmentLostOrDamToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem relToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem retakeTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem localLicenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem internationalLicenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem replacementLostOrDamagetLicenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem releaseDetainedDrivingLicenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiAddNewLocalLicenseApp;
        private System.Windows.Forms.ToolStripMenuItem nationalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem currentUserInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem singoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem localDrivingLicenseAppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem internationalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageDetainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detainLicenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem releaseDetainLicenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageTestTypesToolStripMenuItem;
    }
}