﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ScheduleTest : Form
    {
        enum enTestType { VisionTest = 1, WrittenTest = 2, StreetTest = 3 }
        enTestType _TestType = enTestType.VisionTest;

        enum enMode { AddNew = 1, Update = 2 }
        private enMode _Mode = enMode.AddNew;

        private int _LDLAppID {  get; set; }
        private bool _isRetakeTest { get; set; }

        private clsAppointment _Appointment;
        private int _AppointmentID = -1;

        public ScheduleTest(int AppointmentID,  int LDLAppID , int TestTypeID , bool isRetakeTest)
        {
            InitializeComponent();

            if (AppointmentID != -1)
            {
                _Mode = enMode.Update;
            }
            else
            {
                _Mode = enMode.AddNew;
            }
            _AppointmentID = AppointmentID;
            _TestType = (enTestType)TestTypeID;
            _LDLAppID = LDLAppID;
            _isRetakeTest = isRetakeTest;
        }

        private void _AddRetakeTestAppointment()
        {
            clsApplications app = new clsApplications();
            app.AppPersonID = clsPeople.FindPeople(clsLocalDrivingLicense.FindLocalLicenseApplication(_LDLAppID).NationalNo).PersonID;
            app.ApplicationDate = DateTime.Now;
            app.ApplicationTypeID = 8; // RetakeTestApplicationTypeID
            app.ApplicationStatus = 3;
            app.LastStateDate = DateTime.Now;
            app.PaidFees = clsTestTypes.FindTestType((int)_TestType).TestTypeFees;
            app.CreatedByUser = clsGlobalSittings.CurrentUserInfo.UserID;

            app.Save();

        }

        private void _AddNewTestAppointment()
        {
            string modeString = (_Mode == enMode.AddNew) ? "Add" : "Update";

            if (MessageBox.Show($"Are you sure do you want to {modeString} this Appointment? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            if (_isRetakeTest && _Mode == enMode.AddNew)
            {
                _AddRetakeTestAppointment();
            }

            _Appointment.TestTypeID = (int)_TestType;
            _Appointment.LDLAppID = _LDLAppID;
            _Appointment.AppointmentDate = dtpScheduleTestDate.Value;
            _Appointment.PaidFees = clsTestTypes.FindTestType((int)_TestType).TestTypeFees;
            _Appointment.CreatedByUserID = clsGlobalSittings.CurrentUserInfo.UserID;
            _Appointment.isLocked = false;



            if (_Appointment.Save())
            {
                MessageBox.Show("Data Saved Successfully", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Data Saved Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _FindAppointment()
        {
            _Appointment = clsAppointment.FindAppointment(_AppointmentID);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            _AddNewTestAppointment();
            
        }

        private void _RetakeTestSection()
        {
            gbRetakeTes.Enabled = true;
            lblRetakeTestAppFees.Text = clsApplicationTypes.FindApplicationType(8).AppTypeFees.ToString();
            lblRetakeAppID.Text = clsTests.FindRetakeTestAppointmentID(_LDLAppID, (int)_TestType).ToString();

            decimal.TryParse(lblFees.Text, out decimal fees);
            decimal.TryParse(lblRetakeTestAppFees.Text, out decimal retakeFees);

            lblTotalFees.Text = (retakeFees + fees).ToString();
        }

        private void _LoadData()
        {
            if (_Mode == enMode.Update)
            {
                _FindAppointment();
                dtpScheduleTestDate.Value = _Appointment.AppointmentDate;
            }
            else
            {
                _Appointment = new clsAppointment();
            }

            clsLocalDrivingLicense cls = clsLocalDrivingLicense.FindLocalLicenseApplication(_LDLAppID);

            if (cls != null)
            {
                lblLDLAppID.Text = cls.LocalLicenseApplicationsID.ToString();
                lblClassName.Text = cls.LicenseClassName;
                lblName.Text = cls.FullName;
                lblTrailCount.Text = clsTests.FailedTestCount(_LDLAppID , (int)_TestType).ToString();
                lblFees.Text = clsTestTypes.FindTestType((int)_TestType).TestTypeFees.ToString();
                dtpScheduleTestDate.MinDate = DateTime.Now.AddDays(1);


                if (_isRetakeTest)
                {
                    _RetakeTestSection();
                }
                else
                {
                    gbRetakeTes.Enabled = false;
                }

            }
        }

        private void _LoatScheduleTestAppointmentData()
        {
            switch (_TestType)
            {
                case enTestType.VisionTest:
                    if (_isRetakeTest)
                    {
                        lblHeader.Text = "Vision Retake Test";
                    }
                    else
                    {
                        lblHeader.Text = "Vision Test";
                    }
                    break;
                case enTestType.WrittenTest:
                    if (_isRetakeTest)
                    {
                        lblHeader.Text = "Written Retake Test";
                    }
                    else
                    {
                        lblHeader.Text = "Written Test";
                    }
                    break;
                case enTestType.StreetTest:
                    if (_isRetakeTest)
                    {
                        lblHeader.Text = "Street Retake Test";
                    }
                    else
                    {
                        lblHeader.Text = "Street Test";
                    }
                    break;
                default:
                    lblHeader.Text = "Error 404";
                    break;
            }

            _LoadData();
        }

        private void ScheduleTest_Load(object sender, EventArgs e)
        {
            _LoatScheduleTestAppointmentData();
            
        }

        private void _CloseDialog()
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }
    }
}
