﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD
{
    public partial class TestsAppointments : Form
    {
        enum enTestAppointmentType { VisionTest = 1 , WrittenTest = 2 , StreetTest = 3}
        enTestAppointmentType _TestType = enTestAppointmentType.VisionTest;

        private int _LocalDrivingLicenseID {  get; set; }

        public TestsAppointments(int localDrivingLicenseID , short TestTypeID)
        {
            InitializeComponent();
            _LocalDrivingLicenseID = localDrivingLicenseID;
            _TestType = (enTestAppointmentType)TestTypeID;
        }

        private void _RefreshAppointmentDetails()
        {
            DataTable dt = clsAppointment.GetAllAppointmentDetails(_LocalDrivingLicenseID, (int)_TestType);

            if (dt != null)
            {
                dgvApointments.DataSource = dt;
                lblCountRecords.Text = dt.Rows.Count.ToString();
                ucLicenseApplicationInfo1.LoadApplicationInfo(_LocalDrivingLicenseID);
            }
        }

        private void TestsAppointments_Load(object sender, EventArgs e)
        {
            switch (_TestType)
            {
                case enTestAppointmentType.VisionTest:
                    lblHeader.Text = "Vision Test Appointment";
                    break;
                case enTestAppointmentType.WrittenTest:
                    lblHeader.Text = "Written Test Appointment";
                    break;
                case enTestAppointmentType.StreetTest:
                    lblHeader.Text = "Street Test Appointment";
                    break;
                default:
                    lblHeader.Text = "Error 404";
                    break;

            }
            _RefreshAppointmentDetails();
        }

        private void _CloseDialog()
        {
            if (MessageBox.Show($"Are you sure do you want to Close? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }

        private bool _ValidateActiveAppointment()
        {
            return clsAppointment.isActiveAppointment(_LocalDrivingLicenseID , (int)_TestType);
        }

        private void _ScheduleTestScreen()
        {
            short test = clsTests.FailedTestCount(_LocalDrivingLicenseID, (int)_TestType);

            ScheduleTest frm = new ScheduleTest( -1 ,_LocalDrivingLicenseID, (int)_TestType, (test > 0));
            frm.ShowDialog();
        }

        private bool _ValidatePassedTest()
        {
            return clsTests.FindPassedTest(_LocalDrivingLicenseID, (int)_TestType);
        }

        private void _AddNewAppointment()
        {
            if (_ValidateActiveAppointment())
            {
                MessageBox.Show("Person Already Have An Active Appointment For This Test, You Cannot Add New Appointment", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (_ValidatePassedTest())
            {
                MessageBox.Show("Person Already Passed This Test, You Cannot Add New Appointment", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _ScheduleTestScreen();
            

        }

        private void _UpdateScheduleTestScreen()
        {
            int IsRetakeTest = clsTests.FailedTestCount(_LocalDrivingLicenseID, (int)_TestType);

            ScheduleTest frm = new ScheduleTest(int.Parse(dgvApointments.SelectedRows[0].Cells[0].Value.ToString()),_LocalDrivingLicenseID, (int)_TestType, (IsRetakeTest > 0));
            frm.ShowDialog();
        }

        private void btnAddAppointment_Click(object sender, EventArgs e)
        {
            _AddNewAppointment();
            _RefreshAppointmentDetails();
        }

        private void miEdit_Click(object sender, EventArgs e)
        {
            _UpdateScheduleTestScreen();
            _RefreshAppointmentDetails();
        }

        private void _DisableMenuStrip()
        {
            if (clsAppointment.isActiveAppointment( int.Parse(dgvApointments.SelectedRows[0].Cells[0].Value.ToString()))) 
            {
                cmsLocalLicenseApp.Enabled = true;
                
            }
            else
            {
                cmsLocalLicenseApp.Enabled = false;
            }
            
        }

        private void _TakeTestScreen()
        {
            short test = clsTests.FailedTestCount(_LocalDrivingLicenseID, (int)_TestType);

            TakeTest frm = new TakeTest(_LocalDrivingLicenseID, int.Parse(dgvApointments.SelectedRows[0].Cells[0].Value.ToString()) ,(int)_TestType);
            frm.ShowDialog();

        }

        private void miTakeTest_Click(object sender, EventArgs e)
        {
            _TakeTestScreen();
            _RefreshAppointmentDetails();
        }

        private void dgvAppointments_RowContextMenuStripNeeded(object sender, DataGridViewRowContextMenuStripNeededEventArgs e)
        {
            _DisableMenuStrip();
        }
    }
}
