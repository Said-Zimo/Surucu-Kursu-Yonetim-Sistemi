﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class TakeTest : Form
    {

        private int _LDLAppID { get; set; }
        private int _AppointmentID { get; set; }
        enum enTestType { VisionTest = 1, WrittenTest = 2, StreetTest = 3 }
        enTestType _TestType = enTestType.VisionTest;


        public TakeTest(int LDLAppID,int AppointmentID, int TestTypeID)
        {
            InitializeComponent();
            _TestType = (enTestType)TestTypeID;
            _LDLAppID = LDLAppID;
            _AppointmentID = AppointmentID;
        }

        private void _LoadData()
        {
            clsLocalDrivingLicense cls = clsLocalDrivingLicense.FindLocalLicenseApplication(_LDLAppID);

            if (cls != null)
            {
                lblLDLAppID.Text = cls.LocalLicenseApplicationsID.ToString();
                lblClassName.Text = cls.LicenseClassName;
                lblName.Text = cls.FullName;
                lblTrailCount.Text = clsTests.FailedTestCount(_LDLAppID, (int)_TestType).ToString();
                lblTestDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                lblFees.Text = clsTestTypes.FindTestType((int)_TestType).TestTypeFees.ToString();
                
            }
        }
        

        private void TakeTest_Load(object sender, EventArgs e)
        {
            switch (_TestType)
            {
                case enTestType.VisionTest: 
                    lblHeader.Text = "Vision Test";
                    break;

                case enTestType.WrittenTest:
                    lblHeader.Text = "Written Test";
                    break;

                case enTestType.StreetTest:
                    lblHeader.Text = "Street Test";
                    break;

                default:

                    lblHeader.Text = "Error 404";
                    break;
            }

            _LoadData();
        }

        private void _CloseDialog()
        {
            this.Close();
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }

        
        private void _SaveTestInfo()
        {
            if (MessageBox.Show($"Are you sure do you want to take this test? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            clsTests test = new clsTests();

            test.TestAppointmentID = _AppointmentID;

            if (rbPass.Checked == true)
            {
                test.TestResult = true;
            }
            else
            {
                test.TestResult = false;
            }

            test.TestNotes = txtNotes.Text;
            test.CreatedByUserID = clsGlobalSittings.CurrentUserInfo.UserID;

            if(test.Save())
            {
                clsAppointment appointment = clsAppointment.FindAppointment(_AppointmentID);
                appointment.isLocked = true;

                appointment.Save();

                MessageBox.Show("Take Test Successfully", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Take Test Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            _SaveTestInfo();

        }
    }
}
