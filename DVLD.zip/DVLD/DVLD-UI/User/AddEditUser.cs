﻿using DVLD_Logic;
using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD
{
    public partial class AddEditUser : Form
    {

        private enum enMode { AddNew = 1, Update = 2 }
        enMode Mode = enMode.AddNew;

        clsUser _User;
        int _UserID = 0;
        public AddEditUser(int UserID)
        {
            InitializeComponent();

            _UserID = UserID;

            if (UserID == -1)
            {
                Mode = enMode.AddNew;
            }
            else
            {
                Mode = enMode.Update;
            }
        }

        private bool _UserExist()
        {
            return clsUser.UserExist(fpControl.PersonID);
        }

        private bool _CheckPersonInfoForUser()
        {
            if (fpControl.isFound == false)
            {
                MessageBox.Show("Not have person!" , "Person" ,MessageBoxButtons.OK , MessageBoxIcon.Error);
                return false;
            }

            if (_UserExist() && Mode != enMode.Update)
            {
                MessageBox.Show("This Person is User Actually !", "User", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }

            
            tcUser.SelectedTab = tcUser.TabPages[1];
            return true;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            _CheckPersonInfoForUser();
        }

        private void _ValidateInput(Guna2TextBox txt)
        {
            if (string.IsNullOrWhiteSpace(txt.Text))
            {
                epInputError.SetError(txt, "Should have a value!");
            }
            else
            {
                epInputError.SetError(txt, "");
            }
        }

        private void Input_Validate(object sender, CancelEventArgs e)
        {
            _ValidateInput((Guna2TextBox)sender);
        }

        private bool _ValidateConfirmPass()
        {
            bool isValid = false;

            if(txtPassword.Text != txtRePassword.Text)
            {
                isValid = false;
                epInputError.SetError(txtRePassword, "Re-Password Not Similar!");
            }
            else
            {
                isValid = true;
                epInputError.SetError(txtRePassword, "");
                
            }

            return isValid;
        }

        private void guna2TextBox3_TextChanged(object sender, EventArgs e)
        {
            _ValidateConfirmPass();
        }

        private void _FillUserInfoFromTextboxes()
        {
            _User.PersonID = fpControl.PersonID;
            _User.UserName = txtUserName.Text;
            _User.Password = txtPassword.Text;
            _User.isActive = cbActiveMode.Checked;

        }

        private bool _ValidateTextBoxes()
        {

            if(string.IsNullOrWhiteSpace(txtUserName.Text) )
            {
                epInputError.SetError( txtUserName,"Should have a value!");
                return false;
            }
            else if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                epInputError.SetError(txtPassword, "Should have a value!");
                return false;
            }
            else
            {
                return true;
            }

        }

        private bool _ValidateEveryThink()
        {
            if (!_CheckPersonInfoForUser())
            {
                return false;
            }

            if (!_ValidateTextBoxes())
            {
                MessageBox.Show("Please fill in the referenced text box! ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!_ValidateConfirmPass())
            {
                MessageBox.Show("Password cannot be blank ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }


            return true;
        }

        private void _SaveUser()
        {


            if (!_ValidateEveryThink())
            {
                return;
            }

            

            string ModeString = (Mode == enMode.AddNew) ? "Add" : "Update";

            if(MessageBox.Show($"Are you sure do want to {ModeString} this user", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            _FillUserInfoFromTextboxes();

            if (_User.Save())
            {

                if (Mode == enMode.AddNew)
                {
                    MessageBox.Show($"User Added Successfully With {_User.UserID} User ID", "Add", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lblUserID.Text = _User.UserID.ToString();
                    Mode = enMode.Update;
                    lblHeader.Text = "Update User";
                    this.Text = "Update User";
                    fpControl.DisableFilterBar();
                }
                else
                {
                    MessageBox.Show("User Updated Successfully ", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Mode = enMode.AddNew;
                }

            }
            else
            {
                MessageBox.Show("Cannot save User info ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnSaveUserInfo_Click(object sender, EventArgs e)
        {
            _SaveUser();
        }

        private void _AddNewUserScreen()
        {
            lblHeader.Text = "Add New User";
            this.Text = "Add New User";
            _User = new clsUser();

        }

        private void _FillUserInfoToTextboxes()
        {
            fpControl.DisableFilterBar();
            fpControl.FillPersonInfo(_User.PersonID);

            lblUserID.Text = _User.UserID.ToString();
            txtUserName.Text = _User.UserName.ToString();
            txtPassword.Text = _User.Password.ToString();
            txtRePassword.Text = _User.Password.ToString();
            cbActiveMode.Checked = _User.isActive;
        }


        private void _UpdateUserScreen()
        {
            lblHeader.Text = "Update User";
            this.Text = "Update User";

            _User = clsUser.FindUser(_UserID);

            if (_User != null) 
            {
                _FillUserInfoToTextboxes();
            }
            else
            {
                MessageBox.Show("User Not Found ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }


        private void LoadUserInfo()
        {
            if (Mode == enMode.AddNew)
            {
                _AddNewUserScreen();
                return;
            }

            _UpdateUserScreen();

        }

        private void AddNewUer_Load(object sender, EventArgs e)
        {
            LoadUserInfo();
        }

        private void _CloseDialog()
        {
            if (MessageBox.Show("Are you sure do want to Exit ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }
            else
            {
                this.Close();
            }
                
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

            _CloseDialog();

        }


    }
}
