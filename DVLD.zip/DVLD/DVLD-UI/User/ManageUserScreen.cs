﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ManageUserScreen : Form
    {
        public ManageUserScreen()
        {
            InitializeComponent();
        }

        private void _RefreshUsersData()
        {
            dgvUsers.DataSource = clsUser.GetAllUsers();
            lblCountRecords.Text = dgvUsers.Rows.Count.ToString();
        }

        private void ManageUserScreen_Load(object sender, EventArgs e)
        {
            _RefreshUsersData();

            cbFilterByActiveS.Visible = false;
            txtUserFilter.Visible = false;
        }

        private void _FilterByIDNumber(string ColumnName)
        {
            DataTable dt = (DataTable)dgvUsers.DataSource;

            if (!char.IsDigit(txtUserFilter.Text, txtUserFilter.Text.Length - 1))
            {
                txtUserFilter.Text = string.Empty;
                MessageBox.Show("Enter just NUMBERS!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            dt.DefaultView.RowFilter = $"{ColumnName} = {int.Parse(txtUserFilter.Text)}";
            lblCountRecords.Text = dt.DefaultView.Count.ToString();

        }

        private void _FilterByName(string ColumnName)
        {

            DataTable dt = (DataTable)dgvUsers.DataSource;

            dt.DefaultView.RowFilter = $"{ColumnName} Like '{txtUserFilter.Text}%'";
            lblCountRecords.Text = dt.DefaultView.Count.ToString();
        }

        private void _FilterByActiveState()
        {
            if (cbFilterByActiveS.Text == "All")
            {
                _RefreshUsersData();
                return;
            }

            DataTable dt = (DataTable)dgvUsers.DataSource;

            if (cbFilterByActiveS.Text == "Active")
            {
                dt.DefaultView.RowFilter = "IsActive = 1";
                
            }
            else
            {
                dt.DefaultView.RowFilter = "IsActive = 0";
                
            }
            lblCountRecords.Text = dt.DefaultView.Count.ToString();
        }

        private void _ApplyFilter(string ColumnName)
        {

            if (cbUserFilter.Text == "Person ID" || cbUserFilter.Text == "User ID")
            {

                _FilterByIDNumber(ColumnName);
                

            }
            else
            {
                _FilterByName(ColumnName);
            }

        }

        private void _FilterBy()
        {

            if (txtUserFilter.Text != "")
            {
                _ApplyFilter(cbUserFilter.Text.Replace(" ", ""));
            }
            else
            {
                _RefreshUsersData();
            }

        }

        private void _ShowFilterType()
        {

            if (cbUserFilter.Text == "None")
            {
                txtUserFilter.Visible = false;
                cbFilterByActiveS.Visible = false;
            }
            else if(cbUserFilter.Text == "Is Active")
            {
                txtUserFilter.Visible = false;
                cbFilterByActiveS.Visible = true;
            }
            else
            {
                cbFilterByActiveS.Visible = false;
                txtUserFilter.Visible = true;
                txtUserFilter.Focus();
            }

        }

        private void cbUserFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            _ShowFilterType();
        }

        private void txtUserFilter_TextChanged(object sender, EventArgs e)
        {
            _FilterBy();
        }

        private void cbFilterByActiveS_SelectedIndexChanged(object sender, EventArgs e)
        {
            _FilterByActiveState();
        }

        private void _AddNewUserScreen()
        {
            AddEditUser frm = new AddEditUser(-1);
            frm.ShowDialog();
            _RefreshUsersData();
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            _AddNewUserScreen();
        }

        private void _UpdateUserScreen()
        {
            AddEditUser frm = new AddEditUser(int.Parse(dgvUsers.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
            _RefreshUsersData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _UpdateUserScreen();
        }


        private void addNewPersonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _AddNewUserScreen();
        }

        private void _ShowUserInfo()
        {
            ShowUserDetails frm = new ShowUserDetails(int.Parse(dgvUsers.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ShowUserInfo();
        }

        private void _DeleteUser()
        {
            if (MessageBox.Show("Are you suer do you want to delete this User ", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            if (clsUser.DeleteUser(int.Parse(dgvUsers.SelectedRows[0].Cells[0].Value.ToString())))
            {
                MessageBox.Show("User Deleted Successfully " , "Delete" , MessageBoxButtons.OK , MessageBoxIcon.Information );
                _RefreshUsersData();
            }
            else
            {
                MessageBox.Show("Cannot Delete This User ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _DeleteUser();
        }

        private void _ChangePassword()
        {
            ChangeUserPasswordScreen frm = new ChangeUserPasswordScreen(int.Parse(dgvUsers.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _ChangePassword();
        }

        private void _NotImplementedYetMessage()
        {
            MessageBox.Show("This feature is not Implemented Yet!", "Not Ready", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void sendEmailToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _NotImplementedYetMessage();
        }

        private void phoneCallToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _NotImplementedYetMessage();
        }

        private void _CloseDialog()
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }
    }
}
