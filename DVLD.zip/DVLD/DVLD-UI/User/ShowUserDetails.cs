﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ShowUserDetails : Form
    {
        private int _UserID = -1;
        public ShowUserDetails(int UserID)
        {
            InitializeComponent();
            this._UserID = UserID;
        }

        private void LoadUserInfo()
        {
            if (_UserID != -1)
            {
                ucUserInformation.FindUser(_UserID);
            }
            else
            {
                MessageBox.Show("Error 404" , "Error" , MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void ucUserInfo1_Load(object sender, EventArgs e)
        {
            LoadUserInfo();
        }
    }
}
