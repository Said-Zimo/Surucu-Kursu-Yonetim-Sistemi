﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ucUserInfo : UserControl
    {
        public ucUserInfo()
        {
            InitializeComponent();
        }

        public clsUser User;

        private void _FillUserInfo()
        {
            ucPersonInformation.LoadPersonData(User.PersonID);

            lblUserID.Text = User.UserID.ToString();
            lblUserName.Text = User.UserName;

            if(User.isActive == true)
            {
                lblUserActive.Text = "Yes";
            }
            else
            {
                lblUserActive.Text = "No";
            }

        }

        public void FindUser(int UserID)
        {
            User = clsUser.FindUser(UserID);

            if (User != null)
            {

                _FillUserInfo();

            }
            else
            {
                MessageBox.Show("User Not Found" , "Error" , MessageBoxButtons.OK , MessageBoxIcon.Error);
            }
        }


    }
}
