﻿using DVLD_Logic;
using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ChangeUserPasswordScreen : Form
    {

        private int _UserID = -1;
        public ChangeUserPasswordScreen(int UserID)
        {
            InitializeComponent();
            this._UserID = UserID;
        }

        private void _LoadUserData()
        {

            ucUserInformation.FindUser(_UserID);

        }

        private void ChangePasswordScreen_Load(object sender, EventArgs e)
        {
            _LoadUserData();
        }


        private bool _CheckCurrentPass()
        {
            if (ucUserInformation.User.Password != txtCurrentPassword.Text)
            {
                epPassValidate.SetError(txtCurrentPassword, "Invalid Password!");
                return false;
            }
            else
            {
                epPassValidate.SetError(txtCurrentPassword, "");
                return true;
            }
        }

        private void Check_CurrentPass(object sender, CancelEventArgs e)
        {
            _CheckCurrentPass();
        }

        private bool _CheckNewPassEqualOldPass()
        {
            bool isValid = false;

            if (txtNewPassword.Text == txtCurrentPassword.Text)
            {
                isValid = false;
                epPassValidate.SetError(txtNewPassword, "it is Same password!");
            }
            else
            {
                isValid = true;
                epPassValidate.SetError(txtNewPassword, "");

            }

            return isValid;
        }

        private bool _CheckPasswordValidate()
        {

            bool isValid = false;

            if (txtNewPassword.Text != txtRePassword.Text && !string.IsNullOrWhiteSpace(txtNewPassword.Text))
            {
                isValid = false;
                epPassValidate.SetError(txtRePassword, "Re-Password Not Similar!");
            }
            else
            {
                isValid = true;
                epPassValidate.SetError(txtRePassword, "");

            }

            return isValid;
        }

        private void txtRePassword_Validating(object sender, CancelEventArgs e)
        {
            _CheckPasswordValidate();
        }
        
        private void txtNewPassword_Validating(object sender, CancelEventArgs e)
        {
            _CheckNewPassEqualOldPass();
        }

        private bool _CheckEmptyTextBoxes()
        {
            Guna2TextBox[] txt = {txtCurrentPassword, txtNewPassword , txtRePassword} ;

            foreach (Guna2TextBox txtbx in txt)
            {
                if (string.IsNullOrWhiteSpace(txtbx.Text))
                {
                    epPassValidate.SetError(txtbx, "Should have a value!");
                    return false;

                }
            }

            return true;
        }

        private bool _ValidateEveryInput()
        {
            if (!_CheckEmptyTextBoxes())
            {
                MessageBox.Show("Should have a value!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!_CheckCurrentPass())
            {
                MessageBox.Show("Current Password is not true" , "Error" , MessageBoxButtons.OK , MessageBoxIcon.Error);
                return false;
            }

            if (!_CheckNewPassEqualOldPass())
            {
                MessageBox.Show("Try to type new deferent Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!_CheckPasswordValidate())
            {
                MessageBox.Show("Re-Password most", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void _SaveNewPassword()
        {
            if (!_ValidateEveryInput())
            {
                return;
            }

            if (MessageBox.Show("Are you suer do you want to change Password" , "Are You Sure" , MessageBoxButtons.YesNo , MessageBoxIcon.Question) == DialogResult.No)
            {
                return;
            }

            ucUserInformation.User.Password = txtNewPassword.Text.Trim();

            if (ucUserInformation.User.Save())
            {
                MessageBox.Show("Password Change Successfully", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Password Change failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            ucUserInformation.FindUser(ucUserInformation.User.UserID);
        }

        private void btnSaveUserInfo_Click(object sender, EventArgs e)
        {
            _SaveNewPassword();
        }

        private void _CloseDialog()
        {
            this.Close();
        }
        
        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }


    }
}
