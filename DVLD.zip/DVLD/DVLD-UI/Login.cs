﻿using DVLD_Logic;
using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;



namespace DVLD
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();
        }

        private int _Key = 5;

        private void _Failed()
        {
            MessageBox.Show("Failed UserName Or Password", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtUserName.Text = "";
            txtPassword.Text = "";

            txtUserName.Focus();

            txtUserName.BorderThickness = 1;
            txtPassword.BorderThickness = 1;

            txtUserName.BorderColor = Color.DarkRed;
            txtPassword.BorderColor = Color.DarkRed;
        }

        private void _CloseMainForm()
        {
            this.Close();
        }

        public void _SignOut()
        {
            if (!clsGlobalSittings.isLogined)
            {
                this.Show();
                
            }
        }

        private void _Login()
        {
            clsUser user = clsUser.FindUser(txtUserName.Text);

            if (user != null && user.UserName == txtUserName.Text && user.Password == txtPassword.Text) 
            {
                if (user.isActive)
                {
                    
                    this.Hide();
                    clsGlobalSittings.CurrentUserInfo = user;
                    clsGlobalSittings.isLogined = true;
                    MainScreen mainScreen = new MainScreen();
                    mainScreen.onClose += _CloseMainForm;
                    mainScreen.onSignOut += _SignOut;
                    mainScreen.Show();
                }
                else
                {
                    MessageBox.Show("User not active please contact your ADMIN!", "Not Active", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                _Failed();
            }
        }
            
        private void btnLogin_Click(object sender, EventArgs e)
        {
            _Login();
        }

        private string _EncryptPass(string Pass , int Key)
        {
            string encrypt = "";

            foreach (char c in Pass)
            {

                encrypt += (char)(c + Key);
            }

            return encrypt;
        }

        private string _DecryptPass(string Pass, int Key)
        {
            string encrypt = "";

            foreach (char c in Pass)
            {

                encrypt += (char)(c - Key);
            }

            return encrypt;
        }

        private void _SaveLoginInfoToSettings()
        {

            if (cbRemeberLoginInfo.Checked)
            {
                Properties.Settings.Default.UserName = txtUserName.Text;
                Properties.Settings.Default.Password = _EncryptPass(txtPassword.Text,_Key);

            }
            else
            {
                Properties.Settings.Default.UserName = null;
                Properties.Settings.Default.Password = null;
            }

            Properties.Settings.Default.Save();
        }

        private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            _SaveLoginInfoToSettings();
        }

        private void _LoadUserNameAndPass()
        {
            
            txtUserName.Text = Properties.Settings.Default.UserName;
            txtPassword.Text = _DecryptPass(Properties.Settings.Default.Password , _Key);
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            
            _LoadUserNameAndPass();
            _SaveLoginInfoToSettings();
        }
    }
}
