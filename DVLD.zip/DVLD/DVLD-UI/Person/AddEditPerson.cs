﻿using DVLD_Logic;
using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD
{
    public partial class AddEditPerson : Form
    {
        private enum _Mode { AddNew = 1, Update = 2 }
        private _Mode Mode = _Mode.AddNew;

        public delegate void PersonDataBack(int personID);

        public event PersonDataBack PersonData;

        private int _PersonID { get; set; }
        private clsPeople _Person;

        public AddEditPerson(int personID)
        {
            InitializeComponent();
            _PersonID = personID;

            if (personID == -1)
            {
                Mode = _Mode.AddNew;
                
            }
            else
            {
                Mode = _Mode.Update;
                
            }
        }

        private void _FillCountriesInCB()
        {
            DataTable dt = clsCountries.GetAllCountries();

            foreach (DataRow row in dt.Rows)
            {
                cbCountries.Items.Add(row["CountryName"]);
            }
            cbCountries.SelectedIndex = cbCountries.FindString("Syria");
        }

        private void _FillPersonInfo(clsPeople person)
        {

            lblPersonID.Text = person.PersonID.ToString() ;
            txtNationalNo.Text = person.NationalNo.ToString();
            txtFirstN.Text = person.FirstName.ToString() ;
            txtSecondN.Text = person.SecondName.ToString() ;
            txtThirdN.Text = person.ThirdName.ToString();
            txtLastN.Text = person.LastName.ToString();
            txtEmail.Text = person.Email.ToString() ;
            txtAddress.Text = person.Address.ToString() ;
            txtPhone.Text = person.Phone.ToString() ;
            cbCountries.SelectedIndex = cbCountries.FindString(person.CountryName);
            dtpDateOfBirth.Value = person.DateOfBirth;

            if(person.Gendor == "Male") 
            {
                rbMale.Checked = true ;
            }
            else
            {
                rbFemale.Checked = true ;
            }
        }

        private bool _ValidateTxtBoxes()
        {

            Guna2TextBox[] txt = { txtNationalNo, txtFirstN, txtSecondN, txtLastN, txtAddress, txtPhone };

            foreach (Guna2TextBox txtBox in txt)
            {
                if (string.IsNullOrWhiteSpace(txtBox.Text))
                {
                    _InputValidate(txtBox);
                    MessageBox.Show("Please fill in the referenced text box! ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return true;
                }
            }

            if (_ValidateExistNationalID())
            {
                
                MessageBox.Show("This National No was Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return true;
            }

            return false;
        }

        private void _FillPersonInfoFromTextBoxes()
        {

            int CountryID = clsCountries.Find(cbCountries.SelectedItem.ToString()).CountryID;

            _Person.NationalNo = txtNationalNo.Text.Trim();
            _Person.FirstName = txtFirstN.Text.Trim();
            _Person.SecondName = txtSecondN.Text.Trim();
            _Person.ThirdName = txtThirdN.Text.Trim();
            _Person.LastName = txtLastN.Text.Trim();
            _Person.Email = txtEmail.Text.Trim();
            _Person.Phone = txtPhone.Text.Trim();
            _Person.Address = txtAddress.Text.Trim();
            _Person.DateOfBirth = dtpDateOfBirth.Value;
            _Person.CountryID = CountryID;

            if (rbMale.Checked)
            {
                _Person.Gendor = rbMale.Text;
            }
            else
            {
                _Person.Gendor = rbFemale.Text;
            }
        }

        private void _SavePersonInfo()
        {

            if (_ValidateTxtBoxes())
            {
                return;
            }

            _FillPersonInfoFromTextBoxes();

            string modeString = (Mode == _Mode.AddNew) ? "Add" : "Update";

            if (MessageBox.Show($"Are you sure do you want to {modeString} this Person? " , "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            if (_Person.Save())
            {
                if (Mode == _Mode.AddNew) {
                    MessageBox.Show("Person Added Successfully With ID: " + _Person.PersonID.ToString(), "Added", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lblHeader.Text = "Update Person";
                    lblPersonID.Text = _Person.PersonID.ToString();
                    Mode = _Mode.Update;
                   

                }
                else
                {
                    MessageBox.Show("Person Updated Successfully ", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Mode = _Mode.AddNew;
                }


            }
            else
            {

                

                if (Mode == _Mode.AddNew)
                {
                    MessageBox.Show($"Person {modeString} Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }

        }

        private void _AddNewModeScreen()
        {

            lblHeader.Text = "Add New Person";
            _Person = new clsPeople();
            dtpDateOfBirth.MaxDate = DateTime.Now.AddYears(-18) ;
        }

        private void _UpdatePersonScreen()
        {

            lblHeader.Text = "Update Person";

            _Person = clsPeople.FindPeople(_PersonID);

            if (_Person != null)
            {
                _FillPersonInfo(_Person);
                
            }
            else
            {
                MessageBox.Show("Person Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void _LoadData()
        {

            _FillCountriesInCB(); 

            if (Mode == _Mode.AddNew)
            {
                _AddNewModeScreen();
                return;
            }

            _UpdatePersonScreen();


        }

        private void AddEditPerson_Load(object sender, EventArgs e)
        {
            _LoadData();
            _SwitchDefaultPhoto();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
             
            _SavePersonInfo();
            
        }

        private void _InputValidate(Guna2TextBox txt)
        {
            
            if(string.IsNullOrEmpty(txt.Text) || string.IsNullOrWhiteSpace(txt.Text))
            {
                txt.Text = "";
                epInputValidate.SetError(txt , "Should have a value!");
            }
            else
            {
                epInputValidate.SetError(txt, "");
            }


        }

        private void Input_Validate(object sender, CancelEventArgs e)
        {
            _InputValidate((Guna2TextBox)sender);
        }

        private void _CloseDialog()
        {
            if (MessageBox.Show("Are you sure do you want to CLOSE this dialog? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }
            else
            {
                if (_Person.PersonID != -1)
                {
                    PersonData?.Invoke(_Person.PersonID);
                }
                
                this.Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }

        private bool _ValidateExistNationalID()
        {

            clsPeople person = clsPeople.FindPeople(txtNationalNo.Text);

            if (person != null && _Person.NationalNo.ToLower() != txtNationalNo.Text.ToLower()) 
            {
                
                epInputValidate.SetError(txtNationalNo, "This National No Is Exist!");
                return true;
            }
            else
            {
                epInputValidate.SetError(txtNationalNo, "");
            }
            return false;
        }

        private void _SwitchDefaultPhoto()
        {
            if (rbMale.Checked)
            {
                pbImage.Image = Properties.Resources.student_a;
            }
            else
            {
                pbImage.Image = Properties.Resources.student_b;
            }
        }

        private void rbMale_CheckedChanged(object sender, EventArgs e)
        {
            _SwitchDefaultPhoto();
        }

        private void Exist_Validate(object sender, CancelEventArgs e)
        {
            _ValidateExistNationalID();
        }

        private void _EmailFormatValidate()
        {
            if ( string.IsNullOrWhiteSpace( txtEmail.Text))
            {
                return;

            } 
            
            if (!txtEmail.Text.ToLower().Contains("@gmail.com") && !txtEmail.Text.ToLower().Contains("@hotmail.com"))
            {
                epInputValidate.SetError(txtEmail, "Not Valid Format");
                txtEmail.Focus();
            }
            else
            {
                epInputValidate.SetError(txtEmail, "");
            }
        }

        private void EmailInput_Validate(object sender, CancelEventArgs e)
        {
            _EmailFormatValidate();
        }

        private void AddEditPerson_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_Person.PersonID != -1)
            {
                PersonData?.Invoke(_Person.PersonID);
            }
        }

    }
}
