﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ucPersonInfo : UserControl
    {
        public ucPersonInfo()
        {
            InitializeComponent();
            
        }

        private int _PersonID = -1;

        public int PersonID { get { return _PersonID; } }

        private clsPeople _Person { get; set; }
        public clsPeople Person { get { return _Person; } }

        public bool LoadPersonData(int PersonID)
        {
            clsPeople Person = clsPeople.FindPeople(PersonID);

            if (Person != null)
            {
                
                this._PersonID = Person.PersonID;
                this._Person = Person;
                lblPersonID.Text = Person.PersonID.ToString();
                lblNationalNo.Text = Person.NationalNo.ToString();
                lblName.Text = Person.FullName;
                lblGendor.Text = Person.Gendor.ToString();
                lblEmail.Text = Person.Email.ToString();
                lblPhone.Text = Person.Phone.ToString();
                lblCountry.Text = Person.CountryName.ToString();
                lblDateOfBirth.Text = Person.DateOfBirth.ToString("dd/MM/yyyy");
                lblAddress.Text = Person.Address.ToString();

                if(Person.Gendor == "Male")
                {
                    pbImage.Image = Properties.Resources.student_a;
                }
                else
                {
                    pbImage.Image = Properties.Resources.student_b;
                }

                return true;
            }
            else
            {
                MessageBox.Show("Person Not Found ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public bool LoadPersonData(string NationalNo)
        {
            clsPeople Person = clsPeople.FindPeople(NationalNo);

            if (Person != null)
            {
                this._PersonID = Person.PersonID;
                this._Person = Person;
                lblPersonID.Text = Person.PersonID.ToString();
                lblNationalNo.Text = Person.NationalNo.ToString();
                lblName.Text = Person.FullName;
                lblGendor.Text = Person.Gendor.ToString();
                lblEmail.Text = Person.Email.ToString();
                lblPhone.Text = Person.Phone.ToString();
                lblCountry.Text = Person.CountryName.ToString();
                lblDateOfBirth.Text = Person.DateOfBirth.ToString("dd/MM/yyyy");
                lblAddress.Text = Person.Address.ToString();

                if (Person.Gendor == "Male")
                {
                    pbImage.Image = Properties.Resources.student_a;
                }
                else
                {
                    pbImage.Image = Properties.Resources.student_b;
                }

                return true;
            }
            else
            {
                MessageBox.Show("Person Not Found ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void _ShowEditPersonScreen()
        {
            AddEditPerson frm = new AddEditPerson(_PersonID);
            frm.ShowDialog();
        }

        private void btnEditPerson_Click(object sender, EventArgs e)
        {
            
            _ShowEditPersonScreen();   
        }


    }
}
