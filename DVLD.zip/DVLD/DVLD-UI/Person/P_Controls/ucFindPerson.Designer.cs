﻿namespace DVLD
{
    partial class ucFindPerson
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFind = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbSelect = new Guna.UI2.WinForms.Guna2ComboBox();
            this.lblFindBy = new System.Windows.Forms.Label();
            this.btnAddPerson = new Guna.UI2.WinForms.Guna2PictureBox();
            this.btnFind = new Guna.UI2.WinForms.Guna2PictureBox();
            this.gbFilter = new System.Windows.Forms.GroupBox();
            this.ucPersonInformation = new DVLD.ucPersonInfo();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddPerson)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFind)).BeginInit();
            this.gbFilter.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtFind
            // 
            this.txtFind.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFind.DefaultText = "";
            this.txtFind.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtFind.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtFind.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFind.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFind.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFind.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtFind.ForeColor = System.Drawing.Color.Black;
            this.txtFind.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFind.Location = new System.Drawing.Point(251, 23);
            this.txtFind.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFind.MaxLength = 50;
            this.txtFind.Name = "txtFind";
            this.txtFind.PlaceholderText = "";
            this.txtFind.SelectedText = "";
            this.txtFind.Size = new System.Drawing.Size(140, 48);
            this.txtFind.TabIndex = 0;
            // 
            // cbSelect
            // 
            this.cbSelect.BackColor = System.Drawing.Color.Transparent;
            this.cbSelect.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSelect.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbSelect.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbSelect.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbSelect.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbSelect.ItemHeight = 30;
            this.cbSelect.Items.AddRange(new object[] {
            "Person ID",
            "National No"});
            this.cbSelect.Location = new System.Drawing.Point(100, 23);
            this.cbSelect.Name = "cbSelect";
            this.cbSelect.Size = new System.Drawing.Size(140, 36);
            this.cbSelect.StartIndex = 0;
            this.cbSelect.TabIndex = 46;
            // 
            // lblFindBy
            // 
            this.lblFindBy.AutoSize = true;
            this.lblFindBy.Location = new System.Drawing.Point(26, 33);
            this.lblFindBy.Name = "lblFindBy";
            this.lblFindBy.Size = new System.Drawing.Size(62, 17);
            this.lblFindBy.TabIndex = 25;
            this.lblFindBy.Text = "Find By :";
            // 
            // btnAddPerson
            // 
            this.btnAddPerson.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddPerson.Image = global::DVLD.Properties.Resources.add__2_;
            this.btnAddPerson.ImageRotate = 0F;
            this.btnAddPerson.Location = new System.Drawing.Point(450, 23);
            this.btnAddPerson.Name = "btnAddPerson";
            this.btnAddPerson.Padding = new System.Windows.Forms.Padding(7);
            this.btnAddPerson.Size = new System.Drawing.Size(40, 39);
            this.btnAddPerson.TabIndex = 76;
            this.btnAddPerson.TabStop = false;
            this.btnAddPerson.Click += new System.EventHandler(this.pbAddPerson_Click);
            // 
            // btnFind
            // 
            this.btnFind.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFind.Image = global::DVLD.Properties.Resources.zoom;
            this.btnFind.ImageRotate = 0F;
            this.btnFind.Location = new System.Drawing.Point(407, 23);
            this.btnFind.Name = "btnFind";
            this.btnFind.Padding = new System.Windows.Forms.Padding(4);
            this.btnFind.Size = new System.Drawing.Size(40, 39);
            this.btnFind.TabIndex = 48;
            this.btnFind.TabStop = false;
            this.btnFind.Click += new System.EventHandler(this.guna2PictureBox1_Click);
            // 
            // gbFilter
            // 
            this.gbFilter.Controls.Add(this.btnAddPerson);
            this.gbFilter.Controls.Add(this.btnFind);
            this.gbFilter.Controls.Add(this.txtFind);
            this.gbFilter.Controls.Add(this.cbSelect);
            this.gbFilter.Controls.Add(this.lblFindBy);
            this.gbFilter.Location = new System.Drawing.Point(58, 14);
            this.gbFilter.Name = "gbFilter";
            this.gbFilter.Size = new System.Drawing.Size(674, 87);
            this.gbFilter.TabIndex = 77;
            this.gbFilter.TabStop = false;
            // 
            // ucPersonInformation
            // 
            this.ucPersonInformation.Location = new System.Drawing.Point(18, 67);
            this.ucPersonInformation.Name = "ucPersonInformation";
            this.ucPersonInformation.Size = new System.Drawing.Size(760, 425);
            this.ucPersonInformation.TabIndex = 78;
            // 
            // ucFindPerson
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbFilter);
            this.Controls.Add(this.ucPersonInformation);
            this.Name = "ucFindPerson";
            this.Size = new System.Drawing.Size(797, 509);
            ((System.ComponentModel.ISupportInitialize)(this.btnAddPerson)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFind)).EndInit();
            this.gbFilter.ResumeLayout(false);
            this.gbFilter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtFind;
        private Guna.UI2.WinForms.Guna2ComboBox cbSelect;
        private System.Windows.Forms.Label lblFindBy;
        private Guna.UI2.WinForms.Guna2PictureBox btnFind;
        private Guna.UI2.WinForms.Guna2PictureBox btnAddPerson;
        private System.Windows.Forms.GroupBox gbFilter;
        private ucPersonInfo ucPersonInformation;
    }
}
