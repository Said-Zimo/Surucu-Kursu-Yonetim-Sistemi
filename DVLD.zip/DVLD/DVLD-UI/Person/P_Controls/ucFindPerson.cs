﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ucFindPerson : UserControl
    {
        public ucFindPerson()
        {
            InitializeComponent();
        }

        public bool isFound {get; set;}
        private int _PersonID { get; set;} 
        public int PersonID { get {return _PersonID; } }

        private clsPeople _Person { get; set;}
        public clsPeople Person { get { return _Person; } }

        public void FillPersonInfo(int personID)
        {

            if (ucPersonInformation.LoadPersonData(personID))
            {
                _Person = ucPersonInformation.Person;
                _PersonID = personID;
                isFound = true;
            }
            
        }
        
        private void _FindByPersonID()
        {
            if (!char.IsDigit(txtFind.Text, txtFind.Text.Length - 1) || !char.IsDigit(txtFind.Text, 0))
            {
                txtFind.Text = "";
                MessageBox.Show("Enter Just NUMBERS!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ucPersonInformation.LoadPersonData(int.Parse(txtFind.Text.ToString().Trim())))
            {
                _Person = ucPersonInformation.Person;
                _PersonID = ucPersonInformation.PersonID;
                isFound = true;
            }
            else
            {
                isFound = false;
            }
        }

        private void _FindByNationalNo()
        {

            if (ucPersonInformation.LoadPersonData(txtFind.Text))
            {
                _Person = ucPersonInformation.Person;
                _PersonID = ucPersonInformation.PersonID;
                isFound = true;
            }
            else
            {
                isFound = false;
            }

        }

        private void _FindPersonOnBtnClick()
        {
            
            if(txtFind.Text == "" || txtFind.Text == " ")
            {
                MessageBox.Show("Text Box Is Empty" , "Error" , MessageBoxButtons.OK , MessageBoxIcon.Error);
                txtFind.Focus();
                return;
            }

            if (cbSelect.Text == "Person ID")
            {
                _FindByPersonID();

            }
            else
            {
                _FindByNationalNo();
            }

        }

        public void DisableFilterBar()
        {
            gbFilter.Enabled = false;

        }

        public void EnableFilterBar()
        {

            gbFilter.Enabled = true;
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
            _FindPersonOnBtnClick();
        }

        private void _AddNewPerson()
        {
            AddEditPerson frm = new AddEditPerson(-1);

            frm.PersonData += FillPersonInfo;

            frm.ShowDialog();
        }

        private void pbAddPerson_Click(object sender, EventArgs e)
        {
            _AddNewPerson();
        }

        private void _UpdatePeron()
        {
            AddEditPerson addEditPerson = new AddEditPerson(PersonID);
            addEditPerson.ShowDialog();
            
        }

        private void btnEditPerson_Click(object sender, EventArgs e)
        {
            _UpdatePeron();
        }



    }
}
