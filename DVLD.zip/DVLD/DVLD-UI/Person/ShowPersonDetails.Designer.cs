﻿namespace DVLD
{
    partial class ShowPersonDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PersonInfo = new DVLD.ucPersonInfo();
            this.SuspendLayout();
            // 
            // PersonInfo
            // 
            this.PersonInfo.Location = new System.Drawing.Point(51, 32);
            this.PersonInfo.Name = "PersonInfo";
            this.PersonInfo.Size = new System.Drawing.Size(760, 425);
            this.PersonInfo.TabIndex = 0;
            // 
            // ShowPersonDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 488);
            this.Controls.Add(this.PersonInfo);
            this.Name = "ShowPersonDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ShowPersonDetails";
            this.Load += new System.EventHandler(this.ShowPersonDetails_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private ucPersonInfo PersonInfo;
    }
}