﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ManagePeopleScreen : Form
    {
        public ManagePeopleScreen()
        {
            InitializeComponent();
        }

        private void _RefreshDataTable()
        {

            

            dgvPeople.DataSource = clsPeople.GetAllData();

            lblRecordsCount.Text = dgvPeople.Rows.Count.ToString() ;
            
        }

        private void _ApplyFilter(string ColumnName)
        {
            
            DataTable dt = (DataTable)dgvPeople.DataSource;

            if (cbFilter.Text == "Person ID" ) 
            {

                if (!char.IsDigit(txtFilter.Text , txtFilter.Text.Length - 1) || !char.IsDigit(txtFilter.Text, 0))
                {
                    txtFilter.Text = "";
                    MessageBox.Show("Enter just NUMBERS!" , "Error" , MessageBoxButtons.OK , MessageBoxIcon.Warning);
                    return;
                }

                dt.DefaultView.RowFilter = $"{ColumnName} = {int.Parse(txtFilter.Text)} ";

            }
            else
            {
                dt.DefaultView.RowFilter = $"{ColumnName} Like '{txtFilter.Text}%' ";
                
            }

            lblRecordsCount.Text = dt.DefaultView.Count.ToString();
        }

        private void _FilterData()
        {
            if(txtFilter.Text != "") 
            {
               _ApplyFilter(cbFilter.Text.ToString().Replace(" " ,""));
            }
            else
            {
                _RefreshDataTable();
            }
          
            
        }

        

        private void ManagePeople_Load(object sender, EventArgs e)
        {

            _RefreshDataTable();


        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            _FilterData();
        }

        private void _ShowFilterTextBox()
        {
            if(cbFilter.Text == "None")
            {
                txtFilter.Visible = false;
            }
            else
            {
                txtFilter.Visible = true;
                txtFilter.Focus();
            }
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            _ShowFilterTextBox();
        }

        private void _ShowAddNewPersonScreen()
        {
            AddEditPerson frm = new AddEditPerson(-1);
            frm.ShowDialog();
            _RefreshDataTable();
        }

        private void btnAddPeople_Click(object sender, EventArgs e)
        {
            _ShowAddNewPersonScreen();
        }


        private void addNewPersonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ShowAddNewPersonScreen();
        }

        private void _ShowPersonDetails()
        {
            ShowPersonDetails person = new ShowPersonDetails(int.Parse(dgvPeople.SelectedRows[0].Cells[0].Value.ToString()));
            person.ShowDialog();
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ShowPersonDetails();
        }

        private void _ShowUpdatePersonScreen()
        {
            AddEditPerson frm = new AddEditPerson(int.Parse(dgvPeople.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ShowUpdatePersonScreen();
        }

        private void _DeletePerson()
        {
            
            if(MessageBox.Show("Are you sure do you want to DELETE this Person? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            int personID = int.Parse(dgvPeople.SelectedRows[0].Cells[0].Value.ToString());

            if (clsPeople.DeletePerson(personID))
            {
                MessageBox.Show($"Person With ID: {personID} Deleted Successfully" , "Delete" , MessageBoxButtons.OK , MessageBoxIcon.Information);
                _RefreshDataTable();
            }
            else
            {
                MessageBox.Show($"Cannot Delete This Person With ID: {personID}", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
           
        }

        private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _DeletePerson();
        }

        private void _NotImplementedYetMessage()
        {
            MessageBox.Show("This feature is not Implemented Yet!" , "Not Ready" , MessageBoxButtons.OK , MessageBoxIcon.Information);
        }

        private void sendEmailToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _NotImplementedYetMessage();
        }

        private void phoneCallToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _NotImplementedYetMessage();
        }
    }
}
