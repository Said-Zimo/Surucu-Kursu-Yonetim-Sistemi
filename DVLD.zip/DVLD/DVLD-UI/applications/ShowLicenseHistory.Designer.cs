﻿namespace DVLD
{
    partial class ShowLicenseHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucLicenseHistory1 = new DVLD.ucLicenseHistory();
            this.ucPersonInfo1 = new DVLD.ucPersonInfo();
            this.lblHeader = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ucLicenseHistory1
            // 
            this.ucLicenseHistory1.Location = new System.Drawing.Point(14, 444);
            this.ucLicenseHistory1.Name = "ucLicenseHistory1";
            this.ucLicenseHistory1.Size = new System.Drawing.Size(960, 365);
            this.ucLicenseHistory1.TabIndex = 1;
            // 
            // ucPersonInfo1
            // 
            this.ucPersonInfo1.Location = new System.Drawing.Point(114, 33);
            this.ucPersonInfo1.Name = "ucPersonInfo1";
            this.ucPersonInfo1.Size = new System.Drawing.Size(760, 425);
            this.ucPersonInfo1.TabIndex = 0;
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(333, 9);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(256, 45);
            this.lblHeader.TabIndex = 23;
            this.lblHeader.Text = "License History";
            // 
            // ShowLicenseHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 817);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.ucLicenseHistory1);
            this.Controls.Add(this.ucPersonInfo1);
            this.Name = "ShowLicenseHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ShowLicenseHistory";
            this.Load += new System.EventHandler(this.ShowLicenseHistory_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ucPersonInfo ucPersonInfo1;
        private ucLicenseHistory ucLicenseHistory1;
        private System.Windows.Forms.Label lblHeader;
    }
}