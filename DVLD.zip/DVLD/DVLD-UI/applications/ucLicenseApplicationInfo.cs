﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ucLicenseApplicationInfo : UserControl
    {

        public clsApplications Application;
        public clsLocalDrivingLicense LocalDrivingApplication;
        public ucLicenseApplicationInfo()
        {
            InitializeComponent();
            Application = new clsApplications();
            LocalDrivingApplication = new clsLocalDrivingLicense();
        }

        private int _PersonID {  get; set; }

        public void LoadApplicationInfo(int LDLAppID)
        {
             LocalDrivingApplication = clsLocalDrivingLicense.FindLocalLicenseApplication(LDLAppID);


            if (LocalDrivingApplication != null)
            {

                 Application = clsApplications.FindApplication(LocalDrivingApplication.ApplicationID);

                if (Application != null)
                {
                    lblDLAppID.Text = LocalDrivingApplication.LocalLicenseApplicationsID.ToString();
                    lblClassName.Text = LocalDrivingApplication.LicenseClassName;
                    lblPasedTest.Text = LocalDrivingApplication.PassedTest.ToString();

                    // Basic AppInfo
                    lblAppID.Text = Application.ApplicationID.ToString();
                    lblStatus.Text = LocalDrivingApplication.Status;
                    lblType.Text = clsApplicationTypes.FindApplicationType(Application.ApplicationTypeID).AppTypeTitle;
                    lblFees.Text = Application.PaidFees.ToString();
                    lblFullName.Text = LocalDrivingApplication.FullName;
                    lblDate.Text = Application.ApplicationDate.ToString("dd/MM/yyyy");
                    lblLastStatusDate.Text = Application.LastStateDate.ToString("dd/MM/yyyy");
                    lblCreastedByUser.Text = clsUser.FindUser(Application.CreatedByUser).UserName;
                    
                    _PersonID = Application.AppPersonID;
                }

                
            }
        }

        private void _ShowPersonInfo()
        {
            ShowPersonDetails frm = new ShowPersonDetails(_PersonID);
            frm.ShowDialog();
        }

        private void btnPersonInfo_Click(object sender, EventArgs e)
        {
            _ShowPersonInfo();
        }


    }
}
