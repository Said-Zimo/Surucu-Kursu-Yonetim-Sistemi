﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD
{
    public partial class RenewLicenseApplication : Form
    {
        clsApplications _NewApplication;
        clsLicense _NewLicense;
        public RenewLicenseApplication()
        {
            InitializeComponent();
            _NewApplication = new clsApplications();
            _NewLicense = new clsLicense();
        }

        private bool _ValidateLocalLicenseInfo(bool isFound)
        {

            if (isFound)
            {
                
                if (ucFindLicense1.LicenseInfo.ExpirationDate > DateTime.Now)
                {
                    MessageBox.Show("Selected License Is Not Yet Expired, It Well Expire on: " + ucFindLicense1.LicenseInfo.ExpirationDate.ToString("dd/MM/yyyy"), "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (!ucFindLicense1.LicenseInfo.IsActive)
                {
                    MessageBox.Show("Selected License Is Not Active", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }


            }
            return true;
        }

        private void ucFindLicense1_OnFoundLicense(bool obj)
        {
            if(_ValidateLocalLicenseInfo(obj))
            {
                btnRenew.Enabled = true;
            }
            else
            {
                btnRenew.Enabled = false;
            }
        }

        private int _AddRenewApplication()
        {

            
            _NewApplication.AppPersonID = ucFindLicense1.Person.PersonID;
            _NewApplication.ApplicationDate = DateTime.Now;
            _NewApplication.ApplicationTypeID = 2; // New International License AppTypeID;
            _NewApplication.ApplicationStatus = 3; // Completed;
            _NewApplication.LastStateDate = DateTime.Now;
            _NewApplication.PaidFees = clsApplicationTypes.FindApplicationType(2).AppTypeFees;
            _NewApplication.CreatedByUser = clsGlobalSittings.CurrentUserInfo.UserID;

            if (_NewApplication.Save())
            {
                return _NewApplication.ApplicationID;
            }
            else
            {
                return -1;
            }

        }

        private void _inActiveOldLicense()
        {
            ucFindLicense1.LicenseInfo.IsActive = false;
            ucFindLicense1.LicenseInfo.Save();
        }

        private void _FillApplicationInfo()
        {

            lblRenewAppID.Text = _NewApplication.ApplicationID.ToString();
            lblNewLicenseID.Text = _NewLicense.ApplicationID.ToString();
            lblAppDate.Text = _NewApplication.ApplicationDate.ToString("dd/MM/yyyy");
            lblIssueDate.Text = _NewLicense.IssuedDate.ToString("dd/MM/yyyy");
            lblLicenseFees.Text = _NewLicense.PaidFees.ToString();
            lblTotalFees.Text = (_NewApplication.PaidFees + _NewLicense.PaidFees).ToString();
            lblExpirationDate.Text = _NewLicense.ExpirationDate.ToString("dd/MM/yyyy");
            lblOldLicenseID.Text = ucFindLicense1.LicenseInfo.LicenseID.ToString();

        }

        private void _LoadData()
        {
            lblAppFees.Text = clsApplicationTypes.FindApplicationType(2).AppTypeFees.ToString();
            lblCreatedByUser.Text = clsGlobalSittings.CurrentUserInfo.UserName;
        }

        private void _RenewLicense()
        {
            if (MessageBox.Show("Are You Sure Do You Want To Renew This License", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }


            _NewLicense.ApplicationID = _AddRenewApplication();
            _NewLicense.DriverID = ucFindLicense1.LicenseInfo.DriverID;
            _NewLicense.LicenseClassID = ucFindLicense1.LicenseInfo.LicenseClassID;
            _NewLicense.IssuedDate = DateTime.Now;
            _NewLicense.ExpirationDate = DateTime.Now.AddYears(clsLicenseClasses.Find(ucFindLicense1.LicenseInfo.LicenseClassID).DefaultValidityLength);
            _NewLicense.Notes = txtNotes.Text;
            _NewLicense.PaidFees = clsLicenseClasses.Find(ucFindLicense1.LicenseInfo.LicenseClassID).ClassFees;
            _NewLicense.IssueReason = 2; // Renew ID
            _NewLicense.IsActive = true;
            _NewLicense.CreatedByUserID = clsGlobalSittings.CurrentUserInfo.UserID;


            if (_NewLicense.Save())
            {
                MessageBox.Show("Renew License Successfully With ID: " + _NewLicense.LicenseID, "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ucFindLicense1.DisableFilterBar();
                btnRenew.Enabled = false;
                btnLicenseInfo.Enabled = true;
                btnLicenseHistory.Enabled = true;
                _inActiveOldLicense();
                _FillApplicationInfo();

            }
            else
            {
                MessageBox.Show("Renew License Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRenew_Click(object sender, EventArgs e)
        {
            _RenewLicense();
        }

        private void RenewLicenseApplication_Load(object sender, EventArgs e)
        {
            _LoadData();
        }

        private void _ShowNewLicenseInfo()
        {
            ShowLocalLicenseInfo frm = new ShowLocalLicenseInfo(_NewLicense.LicenseID);
            frm.ShowDialog();
        }

        private void btnLicenseInfo_Click(object sender, EventArgs e)
        {
            _ShowNewLicenseInfo();
        }

        private void _CloseDialog()
        {
            this.Close();
        }

        private void _ShowLicenseHistory()
        {

            ShowLicenseHistory frm = new ShowLicenseHistory(_NewApplication.AppPersonID);
            frm.ShowDialog();
        }

        private void btnLicenseHistory_Click(object sender, EventArgs e)
        {
            _ShowLicenseHistory();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }
    }
}
