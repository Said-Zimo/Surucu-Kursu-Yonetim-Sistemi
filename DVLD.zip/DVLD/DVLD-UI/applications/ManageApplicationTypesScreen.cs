﻿using DVLD_Logic;
using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ManageApplicationTypesScreen : Form
    {
        public ManageApplicationTypesScreen()
        {
            InitializeComponent();
        }

        private void _RefreshApplicationTypes()
        {
            DataTable dt =  clsApplicationTypes.GetAllAppTypes();

            if (dt != null)
            {
                dgvApplicationTypes.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Application Types Data Error", "Error" , MessageBoxButtons.OK , MessageBoxIcon.Error);
            }

            lblRecordsCount.Text = dt.Rows.Count.ToString();
            
        }

        private void ManageApplicationTypesScreen_Load(object sender, EventArgs e)
        {
            _RefreshApplicationTypes();
        }

        private void _UpdateAppType() 
        { 
            UpdateApplicationTypes frm = new UpdateApplicationTypes(int.Parse(dgvApplicationTypes.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
            _RefreshApplicationTypes();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _UpdateAppType();
        }
    }
}
