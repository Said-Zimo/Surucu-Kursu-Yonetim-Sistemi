﻿namespace DVLD
{
    partial class ShowInternationalLicenseInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucInternationalLicenseInfo1 = new DVLD.ucInternationalLicenseInfo();
            this.lblHeader = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ucInternationalLicenseInfo1
            // 
            this.ucInternationalLicenseInfo1.Location = new System.Drawing.Point(12, 77);
            this.ucInternationalLicenseInfo1.Name = "ucInternationalLicenseInfo1";
            this.ucInternationalLicenseInfo1.Size = new System.Drawing.Size(850, 382);
            this.ucInternationalLicenseInfo1.TabIndex = 0;
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(169, 29);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(415, 45);
            this.lblHeader.TabIndex = 24;
            this.lblHeader.Text = "International License Info";
            // 
            // ShowInternationalLicenseInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 471);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.ucInternationalLicenseInfo1);
            this.Name = "ShowInternationalLicenseInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ShowInternationalLicenseID";
            this.Load += new System.EventHandler(this.ShowInternationalLicenseID_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ucInternationalLicenseInfo ucInternationalLicenseInfo1;
        private System.Windows.Forms.Label lblHeader;
    }
}