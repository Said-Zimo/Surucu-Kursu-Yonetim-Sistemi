﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ManageInternationalApplications : Form
    {
        public ManageInternationalApplications()
        {
            InitializeComponent();
        }

        private void _ApplyFilter(string columnName)
        {
            DataTable dt = (DataTable)dgvInternationalApplications.DataSource;

            
            if (!char.IsNumber(txtFilter.Text, 0) || !char.IsNumber(txtFilter.Text, txtFilter.Text.Length - 1) || string.IsNullOrWhiteSpace(txtFilter.Text))
            {
                txtFilter.Text = "";
                MessageBox.Show("Please enter just a Numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            dt.DefaultView.RowFilter = $"{columnName} = {int.Parse(txtFilter.Text)} ";
            lblCountRecords.Text = dt.DefaultView.Count.ToString();
            
        }

        private void _RefreshApplications()
        {
            dgvInternationalApplications.DataSource = clsInternationalLicense.GetAllInternationalLicenses();
            lblCountRecords.Text = dgvInternationalApplications.Rows.Count.ToString();
            
        }

        private void ManageInternationalApplications_Load(object sender, EventArgs e)
        {
            _RefreshApplications();
        }

        private void _SwitchFilter()
        {
            if (cbFilter.Text == "None")
            {
                txtFilter.Visible = false;
                txtFilter.Text = "";
            }
            else
            {
                txtFilter.Visible = true;
                txtFilter.Focus();
            }
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            _SwitchFilter();
        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtFilter.Text))
            {
                _ApplyFilter(cbFilter.Text.Replace(" ", ""));
            }
            else
            {
                _RefreshApplications();
            }
        }

        private void _IssueNewInternationalLicense()
        {
            IssueNewInternationalLicense frm = new IssueNewInternationalLicense();
            frm.ShowDialog();
        }

        private void btnAddInternationalApp_Click(object sender, EventArgs e)
        {
            _IssueNewInternationalLicense();
        }

        private void _ShowPersonDetails()
        {
            ShowPersonDetails frm = new ShowPersonDetails(clsApplications.FindApplication(int.Parse(dgvInternationalApplications.SelectedRows[0].Cells["ApplicationID"].Value.ToString())).AppPersonID);
            frm.ShowDialog();
        }

        private void miShowPersonDetails_Click(object sender, EventArgs e)
        {
            _ShowPersonDetails();
        }

        private void _ShowLicenseDetails()
        {
            ShowInternationalLicenseInfo frm = new ShowInternationalLicenseInfo(int.Parse(dgvInternationalApplications.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
        }

        private void miSowLicense_Click(object sender, EventArgs e)
        {
            _ShowLicenseDetails();
        }

        private void _ShowLicenseHistoryDetails()
        {
            ShowLicenseHistory frm = new ShowLicenseHistory(clsApplications.FindApplication(int.Parse(dgvInternationalApplications.SelectedRows[0].Cells["ApplicationID"].Value.ToString())).AppPersonID);
            frm.ShowDialog();
        }

        private void showPersonLicenseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ShowLicenseHistoryDetails();
        }
    }
}
