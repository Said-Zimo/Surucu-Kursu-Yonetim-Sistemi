﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class IssueNewInternationalLicense : Form
    {
        public IssueNewInternationalLicense()
        {
            InitializeComponent();
            _Application = new clsApplications();
            _InternationalLicense = new clsInternationalLicense();
        }

        private clsApplications _Application;
        private clsInternationalLicense _InternationalLicense;

        private bool _ValidateLocalLicense(bool isFound)
        {
            
            if (isFound)
            {
                if(!clsLicense.isActiveLocalLicenseFromClass3(ucFindLicense1.LicenseInfo.LicenseID))
                {
                    MessageBox.Show("This Person Not Have Active License Form Class 3!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                

                if (ucFindLicense1.LicenseInfo.ExpirationDate <= DateTime.Now)
                {
                    MessageBox.Show("Expiration Date Has Expired ", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                

                int ID = clsInternationalLicense.isExistActiveInternationalLicense(ucFindLicense1.LicenseInfo.LicenseID);

                if (ID != -1)
                {
                    MessageBox.Show("Person Already Has An Active International License With ID: " + ID, "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                
            }
            return true;
        }

        private int _AddNewInternationalApplication()
        {

            _Application.AppPersonID = ucFindLicense1.Person.PersonID;
            _Application.ApplicationDate = DateTime.Now;
            _Application.ApplicationTypeID = 6; // New International License AppTypeID;
            _Application.ApplicationStatus = 3; // Completed;
            _Application.LastStateDate = DateTime.Now;
            _Application.PaidFees = clsApplicationTypes.FindApplicationType(6).AppTypeFees;
            _Application.CreatedByUser = clsGlobalSittings.CurrentUserInfo.UserID;

            if (_Application.Save())
            {
                return _Application.ApplicationID;
            }
            else
            {
                return -1;
            }

        }

        private void _IssueInternationalLicense()
        {
            if (MessageBox.Show("Are You Sure Do You Want To Add This International License", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            _InternationalLicense.ApplicationID = _AddNewInternationalApplication();
            _InternationalLicense.DriverID = ucFindLicense1.LicenseInfo.DriverID;
            _InternationalLicense.LocalLicenseID = ucFindLicense1.LicenseInfo.LicenseID;
            _InternationalLicense.IssueDate = DateTime.Now;
            _InternationalLicense.ExpirationDate = DateTime.Now.AddYears(1);
            _InternationalLicense.IsActive = true;
            _InternationalLicense.CreatedByUserID = clsGlobalSittings.CurrentUserInfo.UserID;

            if (_InternationalLicense.Save())
            {
                MessageBox.Show("International License Issued Successfully With ID: " + _InternationalLicense.InternationalLicenseID, "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ucFindLicense1.DisableFilterBar();
                btnIssue.Enabled = false;
                btnLicenseInfo.Enabled = true;
                btnLicenseHistory.Enabled = true;
                _FillApplicationInfo();
                
            }
            else
            {
                MessageBox.Show("International License Issued Failed" , "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            _IssueInternationalLicense();
        }

        private void ucFindLicense1_OnFoundLicense(bool obj)
        {
            if (_ValidateLocalLicense(obj))
            {
                btnIssue.Enabled = true;
                
            }
            else
            {
                btnIssue.Enabled = false;
                
            }
        }

        private void _FillApplicationInfo()
        {

            lblInternationalAppID.Text = _Application.ApplicationID.ToString();
            lblAppDate.Text = _Application.ApplicationDate.ToString("dd/MM/yyyy");
            lblInternationalLicenseID.Text = _InternationalLicense.InternationalLicenseID.ToString();
            lblIssueDate.Text = _InternationalLicense.IssueDate.ToString("dd/MM/yyyy");
            lblExpirationDate.Text = _InternationalLicense.ExpirationDate.ToString("dd/MM/yyyy");
            lblLocalLicenseID.Text = ucFindLicense1.LicenseInfo.LicenseID.ToString();
            lblFees.Text = _Application.PaidFees.ToString();
            
        }

        private void _LoadData()
        {
            lblFees.Text = clsApplicationTypes.FindApplicationType(2).AppTypeFees.ToString();
            lblCreatedByUser.Text = clsGlobalSittings.CurrentUserInfo.UserName;
        }

        private void IssueNewInternationalLicense_Load(object sender, EventArgs e)
        {
            _LoadData();
        }

        private void _ShowInternationalLicenseInfo()
        {
            ShowInternationalLicenseInfo frm = new ShowInternationalLicenseInfo(_InternationalLicense.InternationalLicenseID);
            frm.ShowDialog();
        }

        private void btnLicenseInfo_Click(object sender, EventArgs e)
        {
            _ShowInternationalLicenseInfo();
        }

        private void _CloseDialog()
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }

        private void _ShowLicenseHistory()
        {

            ShowLicenseHistory frm = new ShowLicenseHistory(ucFindLicense1.Person.PersonID);
            frm.ShowDialog();
        }

        private void btnLicenseHistory_Click(object sender, EventArgs e)
        {
            _ShowLicenseHistory();
        }
    }
}
