﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ucInternationalLicenseInfo : UserControl
    {
        public ucInternationalLicenseInfo()
        {
            InitializeComponent();
            LicensesInfo = new clsInternationalLicense();
            Person = new clsPeople();
        }


        public clsInternationalLicense LicensesInfo;
        public clsPeople Person;

        public bool LoadInternationalLicenseInfo(int InternationalLicenseID)
        {
            LicensesInfo = clsInternationalLicense.FindInternationalLicense(InternationalLicenseID);

            if (LicensesInfo != null)
            {
                Person = clsPeople.FindPeople(clsApplications.FindApplication(LicensesInfo.ApplicationID).AppPersonID);

                if (Person != null)
                {

                    lblName.Text = Person.FullName;
                    lblInternationalLicenseID.Text = LicensesInfo.InternationalLicenseID.ToString();
                    lblLocalLicenseID.Text = LicensesInfo.LocalLicenseID.ToString();
                    lblNationalNo.Text = Person.NationalNo.ToString();
                    lblGendor.Text = Person.Gendor;
                    lblIssueDate.Text = LicensesInfo.IssueDate.ToString("dd/MM/yyyy");
                    lblAppID.Text = LicensesInfo.ApplicationID.ToString();
                    lblIsActive.Text = (LicensesInfo.IsActive) ? "Yes" : "No";
                    lblDateOfBirth.Text = Person.DateOfBirth.ToString("dd/MM/yyyy");
                    lblDriverID.Text = LicensesInfo.DriverID.ToString();
                    lblExpirationDate.Text = LicensesInfo.ExpirationDate.ToString("dd/MM/yyyy");

                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                MessageBox.Show("License Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}
