﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ucLicenseHistory : UserControl
    {
        public ucLicenseHistory()
        {
            InitializeComponent();
        }

        public void LoadLicense(int PersonID)
        {
            dgvLocalLicenses.DataSource = clsLicense.GetAllLocalLicense(PersonID);
            lblLocalCountRecords.Text = dgvLocalLicenses.RowCount.ToString();

            dgvInternationalLicenses.DataSource = clsLicense.GetAllInternationalLicense(PersonID);
            lblinternationalCountRecords.Text = dgvInternationalLicenses.RowCount.ToString();
        }

        private void _ShowLicense()
        {
            ShowLocalLicenseInfo frm = new ShowLocalLicenseInfo(int.Parse(dgvLocalLicenses.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ShowLicense();
        }

        private void _ShowInternationalLicense()
        {
            ShowInternationalLicenseInfo frm = new ShowInternationalLicenseInfo(int.Parse(dgvInternationalLicenses.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _ShowInternationalLicense();
        }
    }
}
