﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ManageLocalDrivingLicenseApplications : Form
    {
        public ManageLocalDrivingLicenseApplications()
        {
            InitializeComponent();
        }

        enum enTests {Startup = 0, VisionTest = 1 , WrittenTest = 2 , StreetTest = 3 }
        private enTests _Test = enTests.Startup;

        private void _RefreshApplications()
        {
            dgvLocalApplications.DataSource = clsLocalDrivingLicense.GetAllLocalLicenseApplications();
            lblCountRecords.Text = dgvLocalApplications.Rows.Count.ToString();
        }

        private void LocalDrivingLicenseApplications_Load(object sender, EventArgs e)
        {
            _RefreshApplications();
        }

        private void _SwitchFilter()
        {
            if(cbLocalAppFilter.Text == "None")
            {
                txtLocalLicenseAppFilter.Visible = false;
                txtLocalLicenseAppFilter.Text = "";
            }
            else
            {
                txtLocalLicenseAppFilter.Visible = true;
                txtLocalLicenseAppFilter.Focus();
            }
        }

        private void cbLocalAppFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            _SwitchFilter();
        }

        private void _ApplyFilter(string columnName)
        {
            DataTable dt = (DataTable)dgvLocalApplications.DataSource;

            if (cbLocalAppFilter.Text == "L. D. L. AppID")
            {
                if (!char.IsNumber(txtLocalLicenseAppFilter.Text ,0) || !char.IsNumber(txtLocalLicenseAppFilter.Text, txtLocalLicenseAppFilter.Text.Length -1))
                {
                    txtLocalLicenseAppFilter.Text = "";
                    MessageBox.Show("Please enter just a Numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                dt.DefaultView.RowFilter = $"{columnName} = {int.Parse(txtLocalLicenseAppFilter.Text)} ";
                lblCountRecords.Text = dt.DefaultView.Count.ToString();
            }
            else 
            {
                dt.DefaultView.RowFilter = $"{columnName} LIKE '{txtLocalLicenseAppFilter.Text}%' ";
                lblCountRecords.Text = dt.DefaultView.Count.ToString();
            }
            
        }


        private void txtLocalAppFilter_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtLocalLicenseAppFilter.Text))
            {
                _ApplyFilter(cbLocalAppFilter.Text.Replace(" " ,""));
            }
            else
            {
                _RefreshApplications();
            }
            
        }

        private void _AddNewLocalLicenseApplication()
        {
            NewLocalDrivingLicenseApp app = new NewLocalDrivingLicenseApp(int.Parse(btnAddLocalLicenseApp.Tag.ToString()));
            app.ShowDialog();
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            _AddNewLocalLicenseApplication();
            _RefreshApplications();
        }

        private void _ValidateLicenseIssue()
        {

            if (clsLicense.isLicenseIssued(clsLocalDrivingLicense.FindLocalLicenseApplication(int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString())).ApplicationID))
            {
                cmsLocalLicenseApp.Items["miSowLicense"].Enabled = true;
            }
            else
            {
                cmsLocalLicenseApp.Items["miSowLicense"].Enabled = false;
            }
        }

        private void _ValidateScheduleTests()
        {
            
            _Test = (enTests)clsTests.PassedTestCount(int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString()));

            switch (_Test)
            {
                case enTests.Startup:
                    cmsScheduletest.Items["tsmVisionTest"].Enabled = true;
                    break;
                case enTests.VisionTest:
                    cmsScheduletest.Items["tsmVisionTest"].Enabled = false;
                    cmsScheduletest.Items["tsmWrittenTest"].Enabled = true;
                    break;
                case enTests.WrittenTest:
                    cmsScheduletest.Items["tsmVisionTest"].Enabled = false;
                    cmsScheduletest.Items["tsmWrittenTest"].Enabled = false;
                    cmsScheduletest.Items["tsmStreetTest"].Enabled = true;
                    break;
                case enTests.StreetTest:
                    cmsLocalLicenseApp.Items["miSechduleTest"].Enabled = false;
                    cmsLocalLicenseApp.Items["miIssueLicenseFirstTime"].Enabled = true;

                    break;
                default:
                    cmsLocalLicenseApp.Items["miSechduleTest"].Enabled = false;
                    break;
            }

            

        }

        private void _SetApplicationMenuStrip()
        {
            string AppStatus = clsLocalDrivingLicense.GetLocalLicenseAppStatus(int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString()));

            switch (AppStatus)
            {
                case "New":
                    cmsLocalLicenseApp.Items["miEditApp"].Enabled = true;
                    cmsLocalLicenseApp.Items["miDelete"].Enabled = true;
                    cmsLocalLicenseApp.Items["miCancel"].Enabled = true;
                    cmsLocalLicenseApp.Items["miSechduleTest"].Enabled = true;
                    cmsLocalLicenseApp.Items["miIssueLicenseFirstTime"].Enabled = false;
                    cmsLocalLicenseApp.Items["miSowLicense"].Enabled = false;
                    _ValidateScheduleTests();
                    _ValidateLicenseIssue();
                    break;
                case "Cancelled":
                    cmsLocalLicenseApp.Items["miEditApp"].Enabled = false;
                    cmsLocalLicenseApp.Items["miDelete"].Enabled = false;
                    cmsLocalLicenseApp.Items["miCancel"].Enabled = false;
                    cmsLocalLicenseApp.Items["miSechduleTest"].Enabled = false;
                    cmsLocalLicenseApp.Items["miIssueLicenseFirstTime"].Enabled = false;
                    cmsLocalLicenseApp.Items["miSowLicense"].Enabled = false;
                    break;
                case "Completed":
                    cmsLocalLicenseApp.Items["miEditApp"].Enabled = false;
                    cmsLocalLicenseApp.Items["miDelete"].Enabled = false;
                    cmsLocalLicenseApp.Items["miCancel"].Enabled = false;
                    cmsLocalLicenseApp.Items["miSechduleTest"].Enabled = false;
                    cmsLocalLicenseApp.Items["miIssueLicenseFirstTime"].Enabled = false;
                    cmsLocalLicenseApp.Items["miSowLicense"].Enabled = true;
                    break;
            }
            
        }

        private void dgvLocalApplications_RowContextMenuStripNeeded(object sender, DataGridViewRowContextMenuStripNeededEventArgs e)
        {
            _SetApplicationMenuStrip();

        }

        private void _TestAppointmentScreen(enTests TestMode)
        {
            TestsAppointments frm = new TestsAppointments( int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString()) ,(short)TestMode);
            frm.ShowDialog();
            _RefreshApplications(); 
        }

        private void tsmVisionTest_Click(object sender, EventArgs e)
        {
            _TestAppointmentScreen(enTests.VisionTest);
        }

        private void tsmWrittenTest_Click(object sender, EventArgs e)
        {
            _TestAppointmentScreen(enTests.WrittenTest);
        }

        private void tsmStreetTest_Click(object sender, EventArgs e)
        {
            _TestAppointmentScreen(enTests.StreetTest);
        }

        private void _DeleteApplication()
        {
            if (MessageBox.Show($"Are you sure do you want to Delete this Application? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            if (clsLocalDrivingLicense.DeleteLocalLicenseApplication(int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString())))
            {
                MessageBox.Show($"Application Deleted Successfully", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show($"Application Deleted Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }


        }

        private void _CancelApplication()
        {
            if (MessageBox.Show($"Are you sure do you want to Cancel this Application? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            clsApplications applications = clsApplications.FindApplication(clsLocalDrivingLicense.FindLocalLicenseApplication(int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString())).ApplicationID);

            applications.ApplicationStatus = 2;

            if (applications.Save())
            {
                MessageBox.Show($"Application Cancelled Successfully", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show($"Application Cancelled Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            

        }

        private void miDelete_Click(object sender, EventArgs e)
        {
            _DeleteApplication();
            
        }

        private void miCancel_Click(object sender, EventArgs e)
        {
            _CancelApplication();
            _RefreshApplications();
        }

        private void _showApplicationDetails()
        {
            ShowApplicationInfo frm = new ShowApplicationInfo(int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
        }

        private void miShowDetalis_Click(object sender, EventArgs e)
        {
            _showApplicationDetails();
        }

        private void miEditApp_Click(object sender, EventArgs e)
        {

        }

        private void _IssueLicenseForFirstTimeScreen()
        {
            IssueDriverLicenseFirstTime frm = new IssueDriverLicenseFirstTime(int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
        }

        private void miIssueLicenseFirstTime_Click(object sender, EventArgs e)
        {
            _IssueLicenseForFirstTimeScreen();
            _RefreshApplications();
        }

        private void _ShowLicenseInfo()
        {
            int ID = clsLicense.FindLicenseIdByApplicationID(clsLocalDrivingLicense.FindLocalLicenseApplication(int.Parse(dgvLocalApplications.SelectedRows[0].Cells[0].Value.ToString())).ApplicationID);

            ShowLocalLicenseInfo frm = new ShowLocalLicenseInfo(ID);
            frm.ShowDialog();
        }

        private void miSowLicense_Click(object sender, EventArgs e)
        {
            _ShowLicenseInfo();
        }

        private void _ShowLicenseHistoryScreen()
        {
            ShowLicenseHistory frm = new ShowLicenseHistory(clsPeople.FindPeople(dgvLocalApplications.SelectedRows[0].Cells["NationalNo"].Value.ToString()).PersonID);
            frm.ShowDialog();
        }

        private void showPersonLicenseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ShowLicenseHistoryScreen();
        }
    }
}
