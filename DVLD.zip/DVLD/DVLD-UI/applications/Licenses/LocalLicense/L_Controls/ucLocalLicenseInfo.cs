﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ucLocalLicenseInfo : UserControl
    {
        public ucLocalLicenseInfo()
        {
            InitializeComponent();
            LicensesInfo = new clsLicense();
            Person = new clsPeople();
        }

        
        public clsLicense LicensesInfo;
        public clsPeople Person;

        public bool LoadLicenseInfo(int LicenseID)
        {
             LicensesInfo = clsLicense.FindLicense(LicenseID);

            if (LicensesInfo != null)
            {
                Person = clsPeople.FindPeople(clsApplications.FindApplication(LicensesInfo.ApplicationID).AppPersonID);

                if (Person != null)
                {
                    lblClass.Text = clsLicenseClasses.Find(LicensesInfo.LicenseClassID).LicenseClassTitle;
                    lblName.Text = Person.FullName;
                    lblLicenseID.Text = LicensesInfo.LicenseID.ToString();
                    lblNationalNo.Text = Person.NationalNo.ToString();
                    lblGendor.Text = Person.Gendor;
                    lblIssueDate.Text = LicensesInfo.IssuedDate.ToString("dd/MM/yyyy");
                    lblIssueReason.Text = LicensesInfo.IssueReasonString;
                    lblNotes.Text = LicensesInfo.Notes;
                    lblIsActive.Text = (LicensesInfo.IsActive) ? "Yes" : "No";
                    lblDateOfBirth.Text = Person.DateOfBirth.ToString("dd/MM/yyyy");
                    lblDriverID.Text = LicensesInfo.DriverID.ToString();
                    lblExprirationDate.Text = LicensesInfo.ExpirationDate.ToString("dd/MM/yyyy");
                    lblisDetained.Text = (clsDetainLicense.isDetained(LicenseID)) ? "Yes" : "No";

                    return true;
                }
                else
                {
                    return false;
                }
                
            }
            else
            {
                MessageBox.Show("License Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        
    }
}
