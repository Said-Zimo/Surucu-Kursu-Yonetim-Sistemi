﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ucFindLocalLicense : UserControl
    {

        public event Action<bool> OnFoundLicense;
        protected virtual void isFounded(bool isFound)
        {
            Action<bool> handler = OnFoundLicense;
            if (handler != null)
            {
                handler(isFound);
            }
        }

        public ucFindLocalLicense()
        {
            InitializeComponent();
            LicenseInfo = new clsLicense();
            Person = new clsPeople();
        }

        public clsLicense LicenseInfo;
        public clsPeople Person;

        private void _FindLicense()
        {
            if (!string.IsNullOrWhiteSpace(txtFind.Text))
            {

                if ((!char.IsDigit(txtFind.Text, txtFind.Text.Length - 1) || !char.IsDigit(txtFind.Text, 0)))
                {
                    txtFind.Text = "";
                    MessageBox.Show("Enter Just NUMBERS!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (ucDriverLicenseInfo1.LoadLicenseInfo(int.Parse(txtFind.Text)))
                {
                    LicenseInfo = ucDriverLicenseInfo1.LicensesInfo;
                    Person = ucDriverLicenseInfo1.Person;
                    if (OnFoundLicense != null)
                    {
                        isFounded(true);
                    }
                }
                
                
            }
            else
            {
                txtFind.Text = "";
            }
        }

        public void DisableFilterBar()
        {
            gbFilter.Enabled = false;

        }

        public void EnableFilterBar()
        {

            gbFilter.Enabled = true;
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            _FindLicense();
        }
    }
}
