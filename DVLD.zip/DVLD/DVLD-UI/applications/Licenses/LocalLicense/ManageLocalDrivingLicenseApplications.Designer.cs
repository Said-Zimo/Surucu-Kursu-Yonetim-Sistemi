﻿namespace DVLD
{
    partial class ManageLocalDrivingLicenseApplications
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvLocalApplications = new Guna.UI2.WinForms.Guna2DataGridView();
            this.cmsLocalLicenseApp = new Guna.UI2.WinForms.Guna2ContextMenuStrip();
            this.miShowDetalis = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.miEditApp = new System.Windows.Forms.ToolStripMenuItem();
            this.miDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.miCancel = new System.Windows.Forms.ToolStripMenuItem();
            this.phoneCallToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.miSechduleTest = new System.Windows.Forms.ToolStripMenuItem();
            this.cmsScheduletest = new Guna.UI2.WinForms.Guna2ContextMenuStrip();
            this.tsmVisionTest = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmWrittenTest = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmStreetTest = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.miIssueLicenseFirstTime = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.miSowLicense = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.showPersonLicenseHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCountRecords = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbLocalAppFilter = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtLocalLicenseAppFilter = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblHeader = new System.Windows.Forms.Label();
            this.btnAddLocalLicenseApp = new Guna.UI2.WinForms.Guna2PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalApplications)).BeginInit();
            this.cmsLocalLicenseApp.SuspendLayout();
            this.cmsScheduletest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddLocalLicenseApp)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvLocalApplications
            // 
            this.dgvLocalApplications.AllowUserToAddRows = false;
            this.dgvLocalApplications.AllowUserToDeleteRows = false;
            this.dgvLocalApplications.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLocalApplications.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvLocalApplications.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLocalApplications.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvLocalApplications.ColumnHeadersHeight = 27;
            this.dgvLocalApplications.ContextMenuStrip = this.cmsLocalLicenseApp;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvLocalApplications.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvLocalApplications.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvLocalApplications.Location = new System.Drawing.Point(28, 202);
            this.dgvLocalApplications.MultiSelect = false;
            this.dgvLocalApplications.Name = "dgvLocalApplications";
            this.dgvLocalApplications.ReadOnly = true;
            this.dgvLocalApplications.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLocalApplications.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvLocalApplications.RowHeadersVisible = false;
            this.dgvLocalApplications.RowHeadersWidth = 51;
            this.dgvLocalApplications.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvLocalApplications.RowTemplate.Height = 26;
            this.dgvLocalApplications.Size = new System.Drawing.Size(1335, 456);
            this.dgvLocalApplications.TabIndex = 13;
            this.dgvLocalApplications.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvLocalApplications.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvLocalApplications.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvLocalApplications.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvLocalApplications.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvLocalApplications.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvLocalApplications.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvLocalApplications.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvLocalApplications.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvLocalApplications.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvLocalApplications.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvLocalApplications.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvLocalApplications.ThemeStyle.HeaderStyle.Height = 27;
            this.dgvLocalApplications.ThemeStyle.ReadOnly = true;
            this.dgvLocalApplications.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvLocalApplications.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvLocalApplications.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvLocalApplications.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvLocalApplications.ThemeStyle.RowsStyle.Height = 26;
            this.dgvLocalApplications.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvLocalApplications.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvLocalApplications.RowContextMenuStripNeeded += new System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventHandler(this.dgvLocalApplications_RowContextMenuStripNeeded);
            // 
            // cmsLocalLicenseApp
            // 
            this.cmsLocalLicenseApp.ImageScalingSize = new System.Drawing.Size(27, 27);
            this.cmsLocalLicenseApp.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miShowDetalis,
            this.toolStripMenuItem2,
            this.miEditApp,
            this.miDelete,
            this.toolStripMenuItem3,
            this.miCancel,
            this.phoneCallToolStripMenuItem,
            this.miSechduleTest,
            this.toolStripMenuItem5,
            this.miIssueLicenseFirstTime,
            this.toolStripMenuItem1,
            this.miSowLicense,
            this.toolStripMenuItem4,
            this.showPersonLicenseHistoryToolStripMenuItem});
            this.cmsLocalLicenseApp.Name = "cmsPerson";
            this.cmsLocalLicenseApp.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.cmsLocalLicenseApp.RenderStyle.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.cmsLocalLicenseApp.RenderStyle.BorderColor = System.Drawing.Color.Gainsboro;
            this.cmsLocalLicenseApp.RenderStyle.ColorTable = null;
            this.cmsLocalLicenseApp.RenderStyle.RoundedEdges = true;
            this.cmsLocalLicenseApp.RenderStyle.SelectionArrowColor = System.Drawing.Color.White;
            this.cmsLocalLicenseApp.RenderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.cmsLocalLicenseApp.RenderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.cmsLocalLicenseApp.RenderStyle.SeparatorColor = System.Drawing.Color.Gainsboro;
            this.cmsLocalLicenseApp.RenderStyle.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.cmsLocalLicenseApp.Size = new System.Drawing.Size(276, 312);
            // 
            // miShowDetalis
            // 
            this.miShowDetalis.Image = global::DVLD.Properties.Resources.Application;
            this.miShowDetalis.Name = "miShowDetalis";
            this.miShowDetalis.Size = new System.Drawing.Size(275, 34);
            this.miShowDetalis.Text = "Show Application Details";
            this.miShowDetalis.Click += new System.EventHandler(this.miShowDetalis_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(272, 6);
            // 
            // miEditApp
            // 
            this.miEditApp.Image = global::DVLD.Properties.Resources.edit;
            this.miEditApp.Name = "miEditApp";
            this.miEditApp.Size = new System.Drawing.Size(275, 34);
            this.miEditApp.Text = "Edit Application";
            this.miEditApp.Click += new System.EventHandler(this.miEditApp_Click);
            // 
            // miDelete
            // 
            this.miDelete.Image = global::DVLD.Properties.Resources.delete;
            this.miDelete.Name = "miDelete";
            this.miDelete.Size = new System.Drawing.Size(275, 34);
            this.miDelete.Text = "Delete Application";
            this.miDelete.Click += new System.EventHandler(this.miDelete_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(272, 6);
            // 
            // miCancel
            // 
            this.miCancel.Image = global::DVLD.Properties.Resources.cross__1_;
            this.miCancel.Name = "miCancel";
            this.miCancel.Size = new System.Drawing.Size(275, 34);
            this.miCancel.Text = "Cancel Application";
            this.miCancel.Click += new System.EventHandler(this.miCancel_Click);
            // 
            // phoneCallToolStripMenuItem
            // 
            this.phoneCallToolStripMenuItem.Name = "phoneCallToolStripMenuItem";
            this.phoneCallToolStripMenuItem.Size = new System.Drawing.Size(272, 6);
            // 
            // miSechduleTest
            // 
            this.miSechduleTest.DropDown = this.cmsScheduletest;
            this.miSechduleTest.Image = global::DVLD.Properties.Resources.contract__1_;
            this.miSechduleTest.Name = "miSechduleTest";
            this.miSechduleTest.Size = new System.Drawing.Size(275, 34);
            this.miSechduleTest.Text = "Schedule Tests";
            // 
            // cmsScheduletest
            // 
            this.cmsScheduletest.ImageScalingSize = new System.Drawing.Size(27, 27);
            this.cmsScheduletest.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmVisionTest,
            this.tsmWrittenTest,
            this.tsmStreetTest});
            this.cmsScheduletest.Name = "cmsPerson";
            this.cmsScheduletest.OwnerItem = this.miSechduleTest;
            this.cmsScheduletest.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.cmsScheduletest.RenderStyle.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.cmsScheduletest.RenderStyle.BorderColor = System.Drawing.Color.Gainsboro;
            this.cmsScheduletest.RenderStyle.ColorTable = null;
            this.cmsScheduletest.RenderStyle.RoundedEdges = true;
            this.cmsScheduletest.RenderStyle.SelectionArrowColor = System.Drawing.Color.White;
            this.cmsScheduletest.RenderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.cmsScheduletest.RenderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.cmsScheduletest.RenderStyle.SeparatorColor = System.Drawing.Color.Gainsboro;
            this.cmsScheduletest.RenderStyle.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.cmsScheduletest.Size = new System.Drawing.Size(169, 106);
            // 
            // tsmVisionTest
            // 
            this.tsmVisionTest.Enabled = false;
            this.tsmVisionTest.Image = global::DVLD.Properties.Resources.ophthalmology;
            this.tsmVisionTest.Name = "tsmVisionTest";
            this.tsmVisionTest.Size = new System.Drawing.Size(168, 34);
            this.tsmVisionTest.Text = "Vision Test";
            this.tsmVisionTest.Click += new System.EventHandler(this.tsmVisionTest_Click);
            // 
            // tsmWrittenTest
            // 
            this.tsmWrittenTest.Enabled = false;
            this.tsmWrittenTest.Image = global::DVLD.Properties.Resources.prescription;
            this.tsmWrittenTest.Name = "tsmWrittenTest";
            this.tsmWrittenTest.Size = new System.Drawing.Size(168, 34);
            this.tsmWrittenTest.Text = "Written Test";
            this.tsmWrittenTest.Click += new System.EventHandler(this.tsmWrittenTest_Click);
            // 
            // tsmStreetTest
            // 
            this.tsmStreetTest.Enabled = false;
            this.tsmStreetTest.Image = global::DVLD.Properties.Resources.plan_3_c__1_;
            this.tsmStreetTest.Name = "tsmStreetTest";
            this.tsmStreetTest.Size = new System.Drawing.Size(168, 34);
            this.tsmStreetTest.Text = "Street Test";
            this.tsmStreetTest.Click += new System.EventHandler(this.tsmStreetTest_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(272, 6);
            // 
            // miIssueLicenseFirstTime
            // 
            this.miIssueLicenseFirstTime.Enabled = false;
            this.miIssueLicenseFirstTime.Image = global::DVLD.Properties.Resources.id_add;
            this.miIssueLicenseFirstTime.Name = "miIssueLicenseFirstTime";
            this.miIssueLicenseFirstTime.Size = new System.Drawing.Size(275, 34);
            this.miIssueLicenseFirstTime.Text = "Issue License First Time";
            this.miIssueLicenseFirstTime.Click += new System.EventHandler(this.miIssueLicenseFirstTime_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(272, 6);
            // 
            // miSowLicense
            // 
            this.miSowLicense.Enabled = false;
            this.miSowLicense.Image = global::DVLD.Properties.Resources.id;
            this.miSowLicense.Name = "miSowLicense";
            this.miSowLicense.Size = new System.Drawing.Size(275, 34);
            this.miSowLicense.Text = "Show License";
            this.miSowLicense.Click += new System.EventHandler(this.miSowLicense_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(272, 6);
            // 
            // showPersonLicenseHistoryToolStripMenuItem
            // 
            this.showPersonLicenseHistoryToolStripMenuItem.Image = global::DVLD.Properties.Resources.driver;
            this.showPersonLicenseHistoryToolStripMenuItem.Name = "showPersonLicenseHistoryToolStripMenuItem";
            this.showPersonLicenseHistoryToolStripMenuItem.Size = new System.Drawing.Size(275, 34);
            this.showPersonLicenseHistoryToolStripMenuItem.Text = "Show Person License History";
            this.showPersonLicenseHistoryToolStripMenuItem.Click += new System.EventHandler(this.showPersonLicenseHistoryToolStripMenuItem_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 693);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 23);
            this.label3.TabIndex = 15;
            this.label3.Text = "#Records :";
            // 
            // lblCountRecords
            // 
            this.lblCountRecords.AutoSize = true;
            this.lblCountRecords.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountRecords.Location = new System.Drawing.Point(123, 693);
            this.lblCountRecords.Name = "lblCountRecords";
            this.lblCountRecords.Size = new System.Drawing.Size(17, 23);
            this.lblCountRecords.TabIndex = 14;
            this.lblCountRecords.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 23);
            this.label1.TabIndex = 18;
            this.label1.Text = "Filter By :";
            // 
            // cbLocalAppFilter
            // 
            this.cbLocalAppFilter.BackColor = System.Drawing.Color.Transparent;
            this.cbLocalAppFilter.BorderRadius = 5;
            this.cbLocalAppFilter.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbLocalAppFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLocalAppFilter.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbLocalAppFilter.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbLocalAppFilter.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.cbLocalAppFilter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbLocalAppFilter.ItemHeight = 30;
            this.cbLocalAppFilter.Items.AddRange(new object[] {
            "None",
            "L. D. L. AppID",
            "National No",
            "Full Name",
            "Status"});
            this.cbLocalAppFilter.Location = new System.Drawing.Point(117, 140);
            this.cbLocalAppFilter.Name = "cbLocalAppFilter";
            this.cbLocalAppFilter.Size = new System.Drawing.Size(174, 36);
            this.cbLocalAppFilter.StartIndex = 0;
            this.cbLocalAppFilter.TabIndex = 17;
            this.cbLocalAppFilter.SelectedIndexChanged += new System.EventHandler(this.cbLocalAppFilter_SelectedIndexChanged);
            // 
            // txtLocalLicenseAppFilter
            // 
            this.txtLocalLicenseAppFilter.BorderRadius = 5;
            this.txtLocalLicenseAppFilter.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLocalLicenseAppFilter.DefaultText = "";
            this.txtLocalLicenseAppFilter.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtLocalLicenseAppFilter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtLocalLicenseAppFilter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtLocalLicenseAppFilter.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtLocalLicenseAppFilter.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtLocalLicenseAppFilter.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLocalLicenseAppFilter.ForeColor = System.Drawing.Color.Black;
            this.txtLocalLicenseAppFilter.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtLocalLicenseAppFilter.Location = new System.Drawing.Point(307, 140);
            this.txtLocalLicenseAppFilter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLocalLicenseAppFilter.Name = "txtLocalLicenseAppFilter";
            this.txtLocalLicenseAppFilter.PlaceholderText = "";
            this.txtLocalLicenseAppFilter.SelectedText = "";
            this.txtLocalLicenseAppFilter.Size = new System.Drawing.Size(174, 45);
            this.txtLocalLicenseAppFilter.TabIndex = 20;
            this.txtLocalLicenseAppFilter.Visible = false;
            this.txtLocalLicenseAppFilter.TextChanged += new System.EventHandler(this.txtLocalAppFilter_TextChanged);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(308, 51);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(680, 45);
            this.lblHeader.TabIndex = 22;
            this.lblHeader.Text = "Manage Local Driving License Applications";
            // 
            // btnAddLocalLicenseApp
            // 
            this.btnAddLocalLicenseApp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddLocalLicenseApp.Image = global::DVLD.Properties.Resources.contract_add;
            this.btnAddLocalLicenseApp.ImageRotate = 0F;
            this.btnAddLocalLicenseApp.Location = new System.Drawing.Point(1271, 102);
            this.btnAddLocalLicenseApp.Name = "btnAddLocalLicenseApp";
            this.btnAddLocalLicenseApp.Padding = new System.Windows.Forms.Padding(11);
            this.btnAddLocalLicenseApp.Size = new System.Drawing.Size(92, 94);
            this.btnAddLocalLicenseApp.TabIndex = 19;
            this.btnAddLocalLicenseApp.TabStop = false;
            this.btnAddLocalLicenseApp.Tag = "1";
            this.btnAddLocalLicenseApp.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // ManageLocalDrivingLicenseApplications
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1387, 753);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.txtLocalLicenseAppFilter);
            this.Controls.Add(this.btnAddLocalLicenseApp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbLocalAppFilter);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblCountRecords);
            this.Controls.Add(this.dgvLocalApplications);
            this.Name = "ManageLocalDrivingLicenseApplications";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LocalDrivingLicenseApplications";
            this.Load += new System.EventHandler(this.LocalDrivingLicenseApplications_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalApplications)).EndInit();
            this.cmsLocalLicenseApp.ResumeLayout(false);
            this.cmsScheduletest.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAddLocalLicenseApp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DataGridView dgvLocalApplications;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCountRecords;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox cbLocalAppFilter;
        private Guna.UI2.WinForms.Guna2PictureBox btnAddLocalLicenseApp;
        private Guna.UI2.WinForms.Guna2TextBox txtLocalLicenseAppFilter;
        private Guna.UI2.WinForms.Guna2ContextMenuStrip cmsLocalLicenseApp;
        private System.Windows.Forms.ToolStripMenuItem miShowDetalis;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem miEditApp;
        private System.Windows.Forms.ToolStripMenuItem miDelete;
        private System.Windows.Forms.ToolStripSeparator phoneCallToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miIssueLicenseFirstTime;
        private System.Windows.Forms.ToolStripMenuItem miSowLicense;
        private System.Windows.Forms.ToolStripMenuItem miCancel;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem miSechduleTest;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem showPersonLicenseHistoryToolStripMenuItem;
        private Guna.UI2.WinForms.Guna2ContextMenuStrip cmsScheduletest;
        private System.Windows.Forms.ToolStripMenuItem tsmVisionTest;
        private System.Windows.Forms.ToolStripMenuItem tsmWrittenTest;
        private System.Windows.Forms.ToolStripMenuItem tsmStreetTest;
        private System.Windows.Forms.Label lblHeader;
    }
}