﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class IssueDriverLicenseFirstTime : Form
    {
        private int _PersonID {  get; set; }
        private int _LDLAppID { get; set; }

        public IssueDriverLicenseFirstTime(int LDLAppID)
        {
            InitializeComponent();
            _LDLAppID = LDLAppID;
        }

        private void _Load()
        {
            clsLocalDrivingLicense LocalLicense = clsLocalDrivingLicense.FindLocalLicenseApplication(_LDLAppID);

            if (LocalLicense != null)
            {
                _PersonID = clsPeople.FindPeople(LocalLicense.NationalNo).PersonID;
            }

            ucLicenseApplicationInfo1.LoadApplicationInfo(_LDLAppID);

        }

        private void IssueDriverLicenseFirstTime_Load(object sender, EventArgs e)
        {
            _Load();
        }

        private void _CloseDialog()
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }

        private void _AddNewLicense( int DriverID)
        {
            clsLicense newLicense = new clsLicense();

            newLicense.ApplicationID = ucLicenseApplicationInfo1.Application.ApplicationID;
            newLicense.DriverID = DriverID;
            newLicense.LicenseClassID = ucLicenseApplicationInfo1.LocalDrivingApplication.LicenseClassID;
            newLicense.IssuedDate = DateTime.Now;
            newLicense.ExpirationDate = DateTime.Now.AddYears(clsLicenseClasses.Find(ucLicenseApplicationInfo1.LocalDrivingApplication.LicenseClassID).DefaultValidityLength);
            newLicense.Notes = txtNotes.Text;
            newLicense.PaidFees = clsLicenseClasses.Find(ucLicenseApplicationInfo1.LocalDrivingApplication.LicenseClassName).ClassFees;
            newLicense.IsActive = true;
            newLicense.IssueReason = 1;
            newLicense.CreatedByUserID = clsGlobalSittings.CurrentUserInfo.UserID;
        

            if (newLicense.Save())
            {
                MessageBox.Show("License Added Successfully With ID: " + newLicense.LicenseID, "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clsApplications UpdateApplicationStatus = clsApplications.FindApplication(ucLicenseApplicationInfo1.Application.ApplicationID);
                UpdateApplicationStatus.LastStateDate = DateTime.Now;
                UpdateApplicationStatus.ApplicationStatus = 3;// "Completed"
                UpdateApplicationStatus.Save();
            }
            else
            {
                MessageBox.Show("License Added Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _IssueDriverLicenseForFirstTime()
        {
            int DriverID = clsDrivers.DriverExist(_PersonID);
            

            if (DriverID  == -1)
            {
                clsDrivers newDriver = new clsDrivers();
                newDriver.PersonID = _PersonID;
                newDriver.CreatedByUserID = clsGlobalSittings.CurrentUserInfo.UserID;
                newDriver.CreatedDate = DateTime.Now;

                newDriver.Save();
                DriverID = newDriver.DriverID;
            }
            
            _AddNewLicense(DriverID);
            
            this.Close();
                
        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            _IssueDriverLicenseForFirstTime();
        }
    }
}
