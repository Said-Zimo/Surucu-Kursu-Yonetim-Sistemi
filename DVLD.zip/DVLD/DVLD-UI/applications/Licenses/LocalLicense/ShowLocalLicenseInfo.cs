﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ShowLocalLicenseInfo : Form
    {
        private int _LicenseID {  get; set; }
        public ShowLocalLicenseInfo(int LicenseID)
        {
            InitializeComponent();
            _LicenseID = LicenseID;
        }

        private void _LoadLicenseInfo()
        {
            ucDriverLicenseInfo1.LoadLicenseInfo(_LicenseID);
        }

        private void ShowLicenseInfo_Load(object sender, EventArgs e)
        {
            _LoadLicenseInfo();
        }
    }
}
