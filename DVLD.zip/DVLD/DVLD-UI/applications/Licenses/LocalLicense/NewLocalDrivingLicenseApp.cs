﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class NewLocalDrivingLicenseApp : Form
    {
        private int _ApplicationTypeID {  get; set; }
        public NewLocalDrivingLicenseApp(int applicationTypeID)
        {
            InitializeComponent();
            _ApplicationTypeID = applicationTypeID;
        }


        private bool _ValidateUser()
        {
            if (!ucFindPerson1.isFound)
            {
                MessageBox.Show("Search Or Add New Person Before Adding New Application", "Person Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (_ValidateUser())
            {
                tcNewLocalLicense.SelectedTab = tcNewLocalLicense.TabPages[1];
            }
        }

        private void _Load()
        {
            
            clsApplicationTypes app = clsApplicationTypes.FindApplicationType(_ApplicationTypeID);
            if (app != null)
            {
                lblFees.Text = app.AppTypeFees.ToString();
            }
            else
            {
                lblFees.Text = "Error";
            }

            DataTable dt = clsLicenseClasses.GetAllLicenseClasses();

            foreach (DataRow dr in dt.Rows)
            {
                  cbClasses.Items.Add(dr["ClassName"]);
            }

            cbClasses.SelectedIndex = cbClasses.FindString("Class 3 - Ordinary driving license");

            lblDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            lblCreatedByUser.Text = clsGlobalSittings.CurrentUserInfo.UserName;

        }

        private bool _ValidateUnderReviewApplication()
        {
            int id =  clsLocalDrivingLicense.FindUnderReviewApplication(ucFindPerson1.Person.NationalNo, cbClasses.Text);

            if (id != -1)
            {
                MessageBox.Show($"Choose Another License Class, The Selected Person Already Have an Active Application For The Selected Class With ID ={id}", "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false ;
            }
            
            return true;
        }


        private void NewLocalDrivingLicenseApp_Load(object sender, EventArgs e)
        {
            _Load();
        }

        private int _AddNewApplication()
        {
            clsApplications app = new clsApplications();
            app.AppPersonID = ucFindPerson1.PersonID;
            app.ApplicationDate = DateTime.Now;
            app.ApplicationTypeID = _ApplicationTypeID;
            app.ApplicationStatus = 1;
            app.LastStateDate = DateTime.Now;
            app.PaidFees = clsApplicationTypes.FindApplicationType(_ApplicationTypeID).AppTypeFees;
            app.CreatedByUser = clsGlobalSittings.CurrentUserInfo.UserID;

            int ID = -1;
            if (app.Save())
            {
               ID = app.ApplicationID;
            }

            return ID;
            
            
        }

        private void _AddLocalDrivingLicense(int ApplicationID)
        {
            clsLocalDrivingLicense app = new clsLocalDrivingLicense();
            app.ApplicationID = ApplicationID;
            app.LicenseClassID = clsLicenseClasses.Find(cbClasses.Text).LicenseClassID;

            if(app.Save())
            {
                MessageBox.Show($"Local Driving License Application Added Successfully with ID:{app.LocalLicenseApplicationsID}", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblDLAppID.Text = app.LocalLicenseApplicationsID.ToString();
            }
            else
            {
                MessageBox.Show("Local Driving License Application Added Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _FillApplicationDetails() 
        {

            _AddLocalDrivingLicense(_AddNewApplication());
            
        }

        private bool _ValidateIssuedLicenseSameClassType()
        {

            if (clsLicense.isHasActiveLicenseWithPersonIDAndLicenseClass(ucFindPerson1.PersonID, clsLicenseClasses.Find(cbClasses.Text).LicenseClassID))
            {
                MessageBox.Show("Choose Another License Class, The Selected Person Already Have an Active License For The Selected Class", "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void _SaveNewLocalLicenseApplication()
        {
            if (!_ValidateUser())
            {
                
                return;
            }

            if (!_ValidateUnderReviewApplication())
            {
                return;
            }

            if (!_ValidateIssuedLicenseSameClassType())
            {
                return;
            }

            if (MessageBox.Show($"Are you sure do you want to add new Application? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            _FillApplicationDetails();


        }

        private void btnSaveUserInfo_Click(object sender, EventArgs e)
        {
            _SaveNewLocalLicenseApplication();
        }

        
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show($"Are you sure do you want to Close? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                this.Close();
            }
        }


    }
}
