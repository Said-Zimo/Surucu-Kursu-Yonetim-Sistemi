﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class UpdateApplicationTypes : Form
    {

        private int _AppTypeID {  get; set; }
        private clsApplicationTypes _AppType { get; set; }

        public UpdateApplicationTypes(int appTypeID)
        {
            InitializeComponent();
            _AppTypeID = appTypeID;
        }

        private bool _ValidateTextBoxes()
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                epAppTypes.SetError(txtTitle, "Should have a value!");
                return false;
            }
            else if (string.IsNullOrWhiteSpace(txtFees.Text))
            {
                epAppTypes.SetError(txtTitle, "Should have a value!");
                return false;
            } 
            else if (!char.IsNumber(txtFees.Text, 0) || !char.IsNumber(txtFees.Text , txtFees.Text.Length - 1))
            {
                epAppTypes.SetError(txtFees, "Just enter number");
                return false;
            }
            else
            {
                return true;
            }
        }

        private void _FillDataFromTextBoxes()
        {
            _AppType.AppTypeTitle = txtTitle.Text.Trim();
            _AppType.AppTypeFees = Convert.ToDecimal(txtFees.Text.Trim());
        }

        private void _SaveAppTypeInfo()
        {
            if (!_ValidateTextBoxes())
            {

                MessageBox.Show("Please Back To The Referred Text Box", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (MessageBox.Show($"Are you sure do you want to Update this Application Type? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            _FillDataFromTextBoxes();

            if (_AppType.Save())
            {
                MessageBox.Show("Updated Successfully", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Updated Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            _SaveAppTypeInfo();
            
        }

        private void _FillDataToTextBoxes()
        {
            lblAppTypeID.Text = _AppType.AppTypeID.ToString();
            txtTitle.Text = _AppType.AppTypeTitle;
            txtFees.Text = _AppType.AppTypeFees.ToString();
        }


        private void _LoadAppTypeInfo()
        {
            _AppType = clsApplicationTypes.FindApplicationType(_AppTypeID);

            if (_AppType != null)
            {
                _FillDataToTextBoxes();
            }
            else
            {
                MessageBox.Show("Application Type Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateApplicationTypes_Load(object sender, EventArgs e)
        {
            _LoadAppTypeInfo();
        }

        private void _Close()
        {
            
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _Close();
        }
    }
}
