﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ReleaseDetainedLicense : Form
    {
        clsDetainLicense _ReleaseDetainedLicense;
        clsApplications _NewApplication;
        public ReleaseDetainedLicense()
        {
            InitializeComponent();
            _ReleaseDetainedLicense = new clsDetainLicense();
            _NewApplication = new clsApplications();
        }

        private bool _ValidateLocalLicense(bool isFound)
        {

            if (isFound)
            {
                if (!clsDetainLicense.isDetained(ucFindLicense1.LicenseInfo.LicenseID))
                {
                    MessageBox.Show("This License Is Not Detained", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

            }
            return true;
        }

        private void _LoadDetainInfo()
        {
            _ReleaseDetainedLicense = clsDetainLicense.FindDetainLicenseByLicenseID(ucFindLicense1.LicenseInfo.LicenseID);
            if (_ReleaseDetainedLicense != null)
            {
                lblDetainID.Text = _ReleaseDetainedLicense.DetainID.ToString();
                lblDetainDate.Text = _ReleaseDetainedLicense.DetainDate.ToString("dd/MM/yyyy");
                lblAppFees.Text = clsApplicationTypes.FindApplicationType(5).AppTypeFees.ToString();
                lblDetainFees.Text = _ReleaseDetainedLicense.DetainFees.ToString();
                lblLicenseID.Text = _ReleaseDetainedLicense.LicenseID.ToString();
                lblCreatedByUser.Text = clsUser.FindUser(_ReleaseDetainedLicense.CreatedByUser).UserName;
                lblTotalFees.Text = (_ReleaseDetainedLicense.DetainFees + Convert.ToDecimal(lblAppFees.Text)).ToString();
                lblAppID.Text = _ReleaseDetainedLicense.ReleasedApplicationID.ToString();
            }
        }

        private void ucFindLicense1_OnFoundLicense(bool obj)
        {
            if (_ValidateLocalLicense(obj))
            {
                btnRelease.Enabled = true;
                _LoadDetainInfo();
            }
            else
            {
                btnRelease.Enabled = false;

            }
        }

        private void _FillReleaseApplicationInfoTotLabels()
        {
            lblDetainID.Text = _ReleaseDetainedLicense.DetainID.ToString();
            lblDetainDate.Text = _ReleaseDetainedLicense.DetainDate.ToString("dd/MM/yyyy");
            lblCreatedByUser.Text = clsGlobalSittings.CurrentUserInfo.UserName;

        }

        private void _ActiveLicense()
        {
            ucFindLicense1.LicenseInfo.IsActive = true;
            ucFindLicense1.LicenseInfo.Save();
        }

        private int _AddReleaseDetainedLicenseApplication()
        {

            _NewApplication.AppPersonID = ucFindLicense1.Person.PersonID;
            _NewApplication.ApplicationDate = DateTime.Now;
            _NewApplication.ApplicationTypeID = 5; // Release Detained License AppTypeID;
            _NewApplication.ApplicationStatus = 3; // Completed;
            _NewApplication.LastStateDate = DateTime.Now;
            _NewApplication.PaidFees = clsApplicationTypes.FindApplicationType(5).AppTypeFees;
            _NewApplication.CreatedByUser = clsGlobalSittings.CurrentUserInfo.UserID;

            if (_NewApplication.Save())
            {
                return _NewApplication.ApplicationID;
            }
            else
            {
                return -1;
            }

        }

        private void _Release()
        {
            
            if (MessageBox.Show("Are You Sure Do You Want To Release This License", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            _ActiveLicense();

            _ReleaseDetainedLicense.IsReleased = true;
            _ReleaseDetainedLicense.ReleaseDate = DateTime.Now;
            _ReleaseDetainedLicense.ReleasedByUserID = clsGlobalSittings.CurrentUserInfo.UserID;
            _ReleaseDetainedLicense.ReleasedApplicationID = _AddReleaseDetainedLicenseApplication();


            if (_ReleaseDetainedLicense.Save())
            {
                MessageBox.Show("License Released Successfully With ID: " + _ReleaseDetainedLicense.DetainID, "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ucFindLicense1.DisableFilterBar();
                btnRelease.Enabled = false;
                btnLicenseInfo.Enabled = true;
                btnLicenseHistory.Enabled = true;
                lblAppID.Text = _NewApplication.ApplicationID.ToString();
                lblLicenseID.Text = ucFindLicense1.LicenseInfo.LicenseID.ToString();

            }
            else
            {
                MessageBox.Show("License Released Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
            _Release();
        }

        private void ReleaseDetainedLicense_Load(object sender, EventArgs e)
        {
            _FillReleaseApplicationInfoTotLabels();
        }

        private void _CloseDialog()
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }

        private void _ShowLicenseInfo()
        {
            ShowLocalLicenseInfo frm = new ShowLocalLicenseInfo(ucFindLicense1.LicenseInfo.LicenseID);
            frm.ShowDialog();
        }

        private void btnLicenseInfo_Click(object sender, EventArgs e)
        {
            _ShowLicenseInfo();
        }

        private void _ShowLicenseHistory()
        {

            ShowLicenseHistory frm = new ShowLicenseHistory(ucFindLicense1.Person.PersonID);
            frm.ShowDialog();
        }

        private void btnLicenseHistory_Click(object sender, EventArgs e)
        {
            _ShowLicenseHistory();
        }
    }
}
