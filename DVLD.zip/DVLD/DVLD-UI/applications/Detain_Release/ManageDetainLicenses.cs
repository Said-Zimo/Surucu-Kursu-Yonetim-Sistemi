﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ManageDetainLicenses : Form
    {
        public ManageDetainLicenses()
        {
            InitializeComponent();
        }

        private void _RefreshDetainList()
        {
            dgvDetainLicenseApplications.DataSource = clsDetainLicense.GetAllDetainLicenseList();
            lblCountRecords.Text = dgvDetainLicenseApplications.RowCount.ToString();
        }

        private void _SwitchFilter()
        {
            if (cbFilter.Text == "None")
            {
                txtFilter.Visible = false;
                txtFilter.Text = "";
            }
            else
            {
                txtFilter.Visible = true;
                txtFilter.Focus();
            }
        }

        private void ManageDetainLicenses_Load(object sender, EventArgs e)
        {
            _RefreshDetainList();
        }

        private void _ApplyFilter(string columnName)
        {
            DataTable dt = (DataTable)dgvDetainLicenseApplications.DataSource;


            if (cbFilter.Text == "Detain ID" || cbFilter.Text == "Release Application ID")
            {
                if (!char.IsNumber(txtFilter.Text, 0) || !char.IsNumber(txtFilter.Text, txtFilter.Text.Length - 1))
                {
                    txtFilter.Text = "";
                    MessageBox.Show("Please enter just a Numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                dt.DefaultView.RowFilter = $"{columnName} = {int.Parse(txtFilter.Text)} ";
                lblCountRecords.Text = dt.DefaultView.Count.ToString();
            }
            else
            {
                dt.DefaultView.RowFilter = $"{columnName} LIKE '{txtFilter.Text}%' ";
                lblCountRecords.Text = dt.DefaultView.Count.ToString();
            }

        }

        

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtFilter.Text))
            {
                _ApplyFilter(cbFilter.Text.Replace(" ", ""));
            }
            else
            {
                _RefreshDetainList();
            }
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            _SwitchFilter();
        }

        private void _DetainLicenseScreen()
        {
            DetainLicense frm = new DetainLicense();
            frm.ShowDialog();
        }

        private void btnDetainLicense_Click(object sender, EventArgs e)
        {
            _DetainLicenseScreen();
            _RefreshDetainList();
        }

        private void _ReleaseDetainedLicenseScreen()
        {
            ReleaseDetainedLicense frm = new ReleaseDetainedLicense();
            frm.ShowDialog();
        }

        private void btnReleaseLicense_Click(object sender, EventArgs e)
        {
            _ReleaseDetainedLicenseScreen();
            _RefreshDetainList();
        }
    }
}
