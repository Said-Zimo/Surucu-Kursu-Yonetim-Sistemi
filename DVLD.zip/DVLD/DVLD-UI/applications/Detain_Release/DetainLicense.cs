﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace DVLD
{
    public partial class DetainLicense : Form
    {

        clsDetainLicense _DetainLicense;
        public DetainLicense()
        {
            InitializeComponent();
            _DetainLicense = new clsDetainLicense();
        }

        private bool _ValidateLocalLicense(bool isFound)
        {

            if (isFound)
            {
                if (clsDetainLicense.isDetained(ucFindLicense1.LicenseInfo.LicenseID))
                {
                    MessageBox.Show("This License Already Detained", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

            }
            return true;
        }


        private void _FillDetainInfo()
        {
            lblDetainID.Text = _DetainLicense.DetainID.ToString();
            lblDetainDate.Text = _DetainLicense.DetainDate.ToString("dd/MM/yyyy");
            lblLicenseID.Text = ucFindLicense1.LicenseInfo.LicenseID.ToString();
            lblCreatedByUser.Text = clsGlobalSittings.CurrentUserInfo.UserName;

        }

        private void _inActiveLicense()
        {
            ucFindLicense1.LicenseInfo.IsActive = false;
            ucFindLicense1.LicenseInfo.Save();
        }

        private void _Detain()
        {
            if (nudFees.Value == 0)
            {
                MessageBox.Show("Fees Cannot Be 0", "Missing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (MessageBox.Show("Are You Sure Do You Want To Detain This License", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            _inActiveLicense();


            _DetainLicense.LicenseID = ucFindLicense1.LicenseInfo.LicenseID;
            _DetainLicense.DetainDate = DateTime.Now;
            _DetainLicense.DetainFees = nudFees.Value;
            _DetainLicense.CreatedByUser = clsGlobalSittings.CurrentUserInfo.UserID;



            if (_DetainLicense.Save())
            {
                MessageBox.Show("License Detained Successfully With ID: " + _DetainLicense.DetainID, "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ucFindLicense1.DisableFilterBar();
                btnDetain.Enabled = false;
                btnLicenseInfo.Enabled = true;
                btnLicenseHistory.Enabled = true;
                _FillDetainInfo();

            }
            else
            {
                MessageBox.Show("License Detained Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnDetain_Click(object sender, EventArgs e)
        {
            _Detain();
        }

        private void ucFindLicense1_OnFoundLicense(bool obj)
        {
            if (_ValidateLocalLicense(obj))
            {
                btnDetain.Enabled = true;

            }
            else
            {
                btnDetain.Enabled = false;

            }
        }

        private void _CloseDialog()
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }

        private void _ShowLicenseInfo()
        {
            ShowLocalLicenseInfo frm = new ShowLocalLicenseInfo(ucFindLicense1.LicenseInfo.LicenseID);
            frm.ShowDialog();
        }

        private void btnLicenseInfo_Click(object sender, EventArgs e)
        {
            _ShowLicenseInfo();
        }

        private void _ShowLicenseHistory()
        {

            ShowLicenseHistory frm = new ShowLicenseHistory(ucFindLicense1.Person.PersonID);
            frm.ShowDialog();
        }

        private void btnLicenseHistory_Click(object sender, EventArgs e)
        {
            _ShowLicenseHistory();
        }
    }
}
