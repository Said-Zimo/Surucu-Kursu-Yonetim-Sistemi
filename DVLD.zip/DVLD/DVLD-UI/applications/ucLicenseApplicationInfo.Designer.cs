﻿namespace DVLD
{
    partial class ucLicenseApplicationInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblLastStatusDate = new System.Windows.Forms.Label();
            this.lblDLAppID = new System.Windows.Forms.Label();
            this.lblCreastedByUser = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblFees = new System.Windows.Forms.Label();
            this.lblAppID = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblAppliedForLicense = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblPasedTest = new System.Windows.Forms.Label();
            this.lblClassName = new System.Windows.Forms.Label();
            this.gbBasicInfo = new System.Windows.Forms.GroupBox();
            this.btnPersonInfo = new Guna.UI2.WinForms.Guna2Button();
            this.btnLicenseInfo = new Guna.UI2.WinForms.Guna2Button();
            this.gbDrivingLicenseApp = new System.Windows.Forms.GroupBox();
            this.gbBasicInfo.SuspendLayout();
            this.gbDrivingLicenseApp.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(480, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 25);
            this.label1.TabIndex = 87;
            this.label1.Text = "Last Status Date :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 25);
            this.label2.TabIndex = 86;
            this.label2.Text = "D. L. ApplicationID :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(480, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 25);
            this.label3.TabIndex = 85;
            this.label3.Text = "Created By :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(480, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 25);
            this.label4.TabIndex = 84;
            this.label4.Text = "Date :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 25);
            this.label5.TabIndex = 83;
            this.label5.Text = "Applicant :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 25);
            this.label6.TabIndex = 82;
            this.label6.Text = "Type :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 25);
            this.label7.TabIndex = 81;
            this.label7.Text = "Fees :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 25);
            this.label8.TabIndex = 80;
            this.label8.Text = "ID :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 71);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 25);
            this.label9.TabIndex = 79;
            this.label9.Text = "Status :";
            // 
            // lblLastStatusDate
            // 
            this.lblLastStatusDate.AutoSize = true;
            this.lblLastStatusDate.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastStatusDate.Location = new System.Drawing.Point(636, 73);
            this.lblLastStatusDate.Name = "lblLastStatusDate";
            this.lblLastStatusDate.Size = new System.Drawing.Size(40, 23);
            this.lblLastStatusDate.TabIndex = 78;
            this.lblLastStatusDate.Text = "###";
            // 
            // lblDLAppID
            // 
            this.lblDLAppID.AutoSize = true;
            this.lblDLAppID.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDLAppID.Location = new System.Drawing.Point(191, 41);
            this.lblDLAppID.Name = "lblDLAppID";
            this.lblDLAppID.Size = new System.Drawing.Size(40, 23);
            this.lblDLAppID.TabIndex = 77;
            this.lblDLAppID.Text = "###";
            // 
            // lblCreastedByUser
            // 
            this.lblCreastedByUser.AutoSize = true;
            this.lblCreastedByUser.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreastedByUser.Location = new System.Drawing.Point(597, 107);
            this.lblCreastedByUser.Name = "lblCreastedByUser";
            this.lblCreastedByUser.Size = new System.Drawing.Size(40, 23);
            this.lblCreastedByUser.TabIndex = 76;
            this.lblCreastedByUser.Text = "###";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(542, 39);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(40, 23);
            this.lblDate.TabIndex = 75;
            this.lblDate.Text = "###";
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFullName.Location = new System.Drawing.Point(124, 177);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(40, 23);
            this.lblFullName.TabIndex = 74;
            this.lblFullName.Text = "###";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblType.Location = new System.Drawing.Point(83, 142);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(40, 23);
            this.lblType.TabIndex = 73;
            this.lblType.Text = "###";
            // 
            // lblFees
            // 
            this.lblFees.AutoSize = true;
            this.lblFees.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFees.Location = new System.Drawing.Point(79, 107);
            this.lblFees.Name = "lblFees";
            this.lblFees.Size = new System.Drawing.Size(40, 23);
            this.lblFees.TabIndex = 72;
            this.lblFees.Text = "###";
            // 
            // lblAppID
            // 
            this.lblAppID.AutoSize = true;
            this.lblAppID.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppID.Location = new System.Drawing.Point(61, 38);
            this.lblAppID.Name = "lblAppID";
            this.lblAppID.Size = new System.Drawing.Size(40, 23);
            this.lblAppID.TabIndex = 71;
            this.lblAppID.Text = "###";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(95, 72);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(40, 23);
            this.lblStatus.TabIndex = 70;
            this.lblStatus.Text = "###";
            // 
            // lblAppliedForLicense
            // 
            this.lblAppliedForLicense.AutoSize = true;
            this.lblAppliedForLicense.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppliedForLicense.Location = new System.Drawing.Point(305, 41);
            this.lblAppliedForLicense.Name = "lblAppliedForLicense";
            this.lblAppliedForLicense.Size = new System.Drawing.Size(182, 25);
            this.lblAppliedForLicense.TabIndex = 88;
            this.lblAppliedForLicense.Text = "Applied For License:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(305, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 25);
            this.label11.TabIndex = 89;
            this.label11.Text = "Passed Test:";
            // 
            // lblPasedTest
            // 
            this.lblPasedTest.AutoSize = true;
            this.lblPasedTest.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasedTest.Location = new System.Drawing.Point(416, 83);
            this.lblPasedTest.Name = "lblPasedTest";
            this.lblPasedTest.Size = new System.Drawing.Size(40, 23);
            this.lblPasedTest.TabIndex = 90;
            this.lblPasedTest.Text = "###";
            // 
            // lblClassName
            // 
            this.lblClassName.AutoSize = true;
            this.lblClassName.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClassName.Location = new System.Drawing.Point(481, 42);
            this.lblClassName.Name = "lblClassName";
            this.lblClassName.Size = new System.Drawing.Size(40, 23);
            this.lblClassName.TabIndex = 94;
            this.lblClassName.Text = "###";
            // 
            // gbBasicInfo
            // 
            this.gbBasicInfo.Controls.Add(this.label1);
            this.gbBasicInfo.Controls.Add(this.label3);
            this.gbBasicInfo.Controls.Add(this.btnPersonInfo);
            this.gbBasicInfo.Controls.Add(this.label4);
            this.gbBasicInfo.Controls.Add(this.btnLicenseInfo);
            this.gbBasicInfo.Controls.Add(this.label5);
            this.gbBasicInfo.Controls.Add(this.label6);
            this.gbBasicInfo.Controls.Add(this.label7);
            this.gbBasicInfo.Controls.Add(this.label8);
            this.gbBasicInfo.Controls.Add(this.label9);
            this.gbBasicInfo.Controls.Add(this.lblLastStatusDate);
            this.gbBasicInfo.Controls.Add(this.lblCreastedByUser);
            this.gbBasicInfo.Controls.Add(this.lblDate);
            this.gbBasicInfo.Controls.Add(this.lblFullName);
            this.gbBasicInfo.Controls.Add(this.lblType);
            this.gbBasicInfo.Controls.Add(this.lblFees);
            this.gbBasicInfo.Controls.Add(this.lblAppID);
            this.gbBasicInfo.Controls.Add(this.lblStatus);
            this.gbBasicInfo.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbBasicInfo.Location = new System.Drawing.Point(28, 183);
            this.gbBasicInfo.Name = "gbBasicInfo";
            this.gbBasicInfo.Size = new System.Drawing.Size(802, 219);
            this.gbBasicInfo.TabIndex = 95;
            this.gbBasicInfo.TabStop = false;
            this.gbBasicInfo.Text = "Basic Application Info";
            // 
            // btnPersonInfo
            // 
            this.btnPersonInfo.BorderRadius = 5;
            this.btnPersonInfo.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnPersonInfo.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnPersonInfo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnPersonInfo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnPersonInfo.FillColor = System.Drawing.Color.Black;
            this.btnPersonInfo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnPersonInfo.ForeColor = System.Drawing.Color.White;
            this.btnPersonInfo.Image = global::DVLD.Properties.Resources.user__1_;
            this.btnPersonInfo.Location = new System.Drawing.Point(640, 170);
            this.btnPersonInfo.Name = "btnPersonInfo";
            this.btnPersonInfo.Size = new System.Drawing.Size(154, 43);
            this.btnPersonInfo.TabIndex = 92;
            this.btnPersonInfo.Text = "Show Person Info";
            this.btnPersonInfo.Click += new System.EventHandler(this.btnPersonInfo_Click);
            // 
            // btnLicenseInfo
            // 
            this.btnLicenseInfo.BorderRadius = 5;
            this.btnLicenseInfo.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnLicenseInfo.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnLicenseInfo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLicenseInfo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnLicenseInfo.FillColor = System.Drawing.Color.Black;
            this.btnLicenseInfo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnLicenseInfo.ForeColor = System.Drawing.Color.White;
            this.btnLicenseInfo.Image = global::DVLD.Properties.Resources.id;
            this.btnLicenseInfo.Location = new System.Drawing.Point(465, 170);
            this.btnLicenseInfo.Name = "btnLicenseInfo";
            this.btnLicenseInfo.Size = new System.Drawing.Size(154, 43);
            this.btnLicenseInfo.TabIndex = 91;
            this.btnLicenseInfo.Text = "Show License Info";
            // 
            // gbDrivingLicenseApp
            // 
            this.gbDrivingLicenseApp.Controls.Add(this.lblClassName);
            this.gbDrivingLicenseApp.Controls.Add(this.lblPasedTest);
            this.gbDrivingLicenseApp.Controls.Add(this.label11);
            this.gbDrivingLicenseApp.Controls.Add(this.lblAppliedForLicense);
            this.gbDrivingLicenseApp.Controls.Add(this.label2);
            this.gbDrivingLicenseApp.Controls.Add(this.lblDLAppID);
            this.gbDrivingLicenseApp.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDrivingLicenseApp.Location = new System.Drawing.Point(28, 48);
            this.gbDrivingLicenseApp.Name = "gbDrivingLicenseApp";
            this.gbDrivingLicenseApp.Size = new System.Drawing.Size(802, 126);
            this.gbDrivingLicenseApp.TabIndex = 96;
            this.gbDrivingLicenseApp.TabStop = false;
            this.gbDrivingLicenseApp.Text = "Driving License Info";
            // 
            // ucLicenseApplicationInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbDrivingLicenseApp);
            this.Controls.Add(this.gbBasicInfo);
            this.Name = "ucLicenseApplicationInfo";
            this.Size = new System.Drawing.Size(863, 436);
            this.gbBasicInfo.ResumeLayout(false);
            this.gbBasicInfo.PerformLayout();
            this.gbDrivingLicenseApp.ResumeLayout(false);
            this.gbDrivingLicenseApp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblLastStatusDate;
        private System.Windows.Forms.Label lblDLAppID;
        private System.Windows.Forms.Label lblCreastedByUser;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblFees;
        private System.Windows.Forms.Label lblAppID;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblAppliedForLicense;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblPasedTest;
        private Guna.UI2.WinForms.Guna2Button btnLicenseInfo;
        private Guna.UI2.WinForms.Guna2Button btnPersonInfo;
        private System.Windows.Forms.Label lblClassName;
        private System.Windows.Forms.GroupBox gbBasicInfo;
        private System.Windows.Forms.GroupBox gbDrivingLicenseApp;
    }
}
