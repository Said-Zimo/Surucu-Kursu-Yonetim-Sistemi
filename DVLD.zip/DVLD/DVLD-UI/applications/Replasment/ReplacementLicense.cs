﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ReplacementLicense : Form
    {

        clsApplications _NewApplication;
        clsLicense _NewLicense;
        enum enReplacementMode { LostID = 3 , DamagedID = 4 }
        private enReplacementMode _Mode = enReplacementMode.DamagedID;

        public ReplacementLicense()
        {
            InitializeComponent();
            _NewApplication = new clsApplications();
            _NewLicense = new clsLicense();
        }

        private bool _ValidateLocalLicenseInfo(bool isFound)
        {

            if (isFound)
            {

                if (!ucFindLicense1.LicenseInfo.IsActive)
                {
                    MessageBox.Show("Selected License Is Not Active", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (ucFindLicense1.LicenseInfo.ExpirationDate <= DateTime.Now)
                {
                    MessageBox.Show("Expiration Date Has Expired, Go To Renew The License First", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }


            }
            return true;
        }

        private int _AddRenewApplication()
        {

            _NewApplication.AppPersonID = ucFindLicense1.Person.PersonID;
            _NewApplication.ApplicationDate = DateTime.Now;
            _NewApplication.ApplicationTypeID = (int)_Mode; // New International License AppTypeID;
            _NewApplication.ApplicationStatus = 3; // Completed;
            _NewApplication.LastStateDate = DateTime.Now;
            _NewApplication.PaidFees = clsApplicationTypes.FindApplicationType((int)_Mode).AppTypeFees;
            _NewApplication.CreatedByUser = clsGlobalSittings.CurrentUserInfo.UserID;

            if (_NewApplication.Save())
            {
                return _NewApplication.ApplicationID;
            }
            else
            {
                return -1;
            }

        }

        private void _inActiveOldLicense()
        {
            ucFindLicense1.LicenseInfo.IsActive = false;
            ucFindLicense1.LicenseInfo.Save();
        }

        private void _FillApplicationInfo()
        {

            lblReplacementAppID.Text = _NewApplication.ApplicationID.ToString();
            lblReplacedLicenseID.Text = _NewLicense.ApplicationID.ToString();
            lblAppDate.Text = _NewApplication.ApplicationDate.ToString("dd/MM/yyyy");
            lblOldLicenseID.Text = ucFindLicense1.LicenseInfo.LicenseID.ToString();

        }

        private void _ReplacementLicense()
        {
            if (MessageBox.Show("Are You Sure Do You Want To Replacement This License", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }


            _NewLicense.ApplicationID = _AddRenewApplication();
            _NewLicense.DriverID = ucFindLicense1.LicenseInfo.DriverID;
            _NewLicense.LicenseClassID = ucFindLicense1.LicenseInfo.LicenseClassID;
            _NewLicense.IssuedDate = DateTime.Now;
            _NewLicense.ExpirationDate = DateTime.Now.AddYears(clsLicenseClasses.Find(ucFindLicense1.LicenseInfo.LicenseClassID).DefaultValidityLength);
            _NewLicense.Notes = "";
            _NewLicense.PaidFees = clsLicenseClasses.Find(ucFindLicense1.LicenseInfo.LicenseClassID).ClassFees;
            _NewLicense.IssueReason = (byte)_Mode; // Damaged ID Or Lost ID
            _NewLicense.IsActive = true;
            _NewLicense.CreatedByUserID = clsGlobalSittings.CurrentUserInfo.UserID;


            if (_NewLicense.Save())
            {
                MessageBox.Show("Replacement License Successfully With ID: " + _NewLicense.LicenseID, "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ucFindLicense1.DisableFilterBar();
                btnIssueReplacement.Enabled = false;
                btnLicenseInfo.Enabled = true;
                btnLicenseHistory.Enabled = true;
                _inActiveOldLicense();
                _FillApplicationInfo();

            }
            else
            {
                MessageBox.Show("Renew License Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ucFindLicense1_OnFoundLicense(bool obj)
        {
            if (_ValidateLocalLicenseInfo(obj))
            {
                btnIssueReplacement.Enabled = true;
            }
            else
            {
                btnIssueReplacement.Enabled = false;
            }
        }

        private void rbDamaged_CheckedChanged(object sender, EventArgs e)
        {
            _Mode = enReplacementMode.DamagedID;
            lblAppFees.Text = lblAppFees.Text = clsApplicationTypes.FindApplicationType((int)_Mode).AppTypeFees.ToString();
            lblHeader.Text = "Replacement For Damaged License";
        }

        private void rbLost_CheckedChanged(object sender, EventArgs e)
        {
            _Mode = enReplacementMode.LostID;
            lblAppFees.Text = lblAppFees.Text = clsApplicationTypes.FindApplicationType((int)_Mode).AppTypeFees.ToString();
            lblHeader.Text = "Replacement For Lost License";
        }

        private void btnIssueReplacement_Click(object sender, EventArgs e)
        {
            _ReplacementLicense();
        }

        
        private void _ShowNewLicenseInfo()
        {
            ShowLocalLicenseInfo frm = new ShowLocalLicenseInfo(_NewLicense.LicenseID);
            frm.ShowDialog();
        }

        private void btnLicenseInfo_Click(object sender, EventArgs e)
        {
            _ShowNewLicenseInfo();
        }

        private void _CloseDialog()
        {
            this.Close();
        }

        private void _ShowLicenseHistory()
        {

            ShowLicenseHistory frm = new ShowLicenseHistory(_NewApplication.AppPersonID);
            frm.ShowDialog();
        }

        private void btnLicenseHistory_Click(object sender, EventArgs e)
        {
            _ShowLicenseHistory();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _CloseDialog();
        }

        private void _LoadData()
        {
            lblAppFees.Text = clsApplicationTypes.FindApplicationType(2).AppTypeFees.ToString();
            lblCreatedByUser.Text = clsGlobalSittings.CurrentUserInfo.UserName;
        }

        private void ReplacementLicense_Load(object sender, EventArgs e)
        {
            _LoadData();
        }
    }
}
