﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class UpdateTestTypes : Form
    {
        public UpdateTestTypes(int testTypeID)
        {
            InitializeComponent();
            _TestTypeID  = testTypeID;
        }

        private int _TestTypeID {  get; set; }
        private clsTestTypes _TestType;

        private bool _ValidateTextBoxes()
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                epTestTypes.SetError(txtTitle, "Should have a value!");
                return false;
            }
            else if (string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                epTestTypes.SetError(txtDescription, "Should have a value!");
                return false;
            }
            else if (string.IsNullOrWhiteSpace(txtFees.Text))
            {
                epTestTypes.SetError(txtTitle, "Should have a value!");
                return false;
            }
            else if (!char.IsNumber(txtFees.Text, 0) || !char.IsNumber(txtFees.Text, txtFees.Text.Length - 1))
            {
                epTestTypes.SetError(txtFees, "Just enter number");
                return false;
            }
            else
            {
                return true;
            }
        }

        private void _FillDataFromTextBoxes()
        {
            
            _TestType.TestTypeTitle = txtTitle.Text.Trim();
            _TestType.TestDescription = txtDescription.Text.Trim();
            _TestType.TestTypeFees = Convert.ToDecimal(txtFees.Text.Trim());
        }

        private void _SaveTestTypeInfo()
        {
            if (!_ValidateTextBoxes())
            {

                MessageBox.Show("Please Back To The Referred Text Box", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (MessageBox.Show($"Are you sure do you want to Update this Test Type? ", "Are You Sure", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            _FillDataFromTextBoxes();

            if (_TestType.Save())
            {
                MessageBox.Show("Updated Successfully", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Updated Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            _SaveTestTypeInfo();
        }


        private void _Close()
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _Close();
        }

        private void _FillDataToTextBoxes()
        {
            lblTestTypeID.Text = _TestType.TestTypeID.ToString();
            txtTitle.Text = _TestType.TestTypeTitle;
            txtDescription.Text = _TestType.TestDescription;
            txtFees.Text = _TestType.TestTypeFees.ToString();
        }

        private void _LoadTestTypeInfo()
        {
            _TestType = clsTestTypes.FindTestType(_TestTypeID);

            if (_TestType != null)
            {
                _FillDataToTextBoxes();
            }
            else
            {
                MessageBox.Show("Test Type Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void UpdateTestTypes_Load(object sender, EventArgs e)
        {
            _LoadTestTypeInfo();
        }
    }
}
