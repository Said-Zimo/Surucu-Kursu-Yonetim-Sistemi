﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ShowApplicationInfo : Form
    {
        private int _LDLAppID {  get; set; }
        public ShowApplicationInfo(int LDLAppID)
        {
            InitializeComponent();
            _LDLAppID = LDLAppID;
        }

        private void _Load()
        {
            ucLicenseApplicationInfo1.LoadApplicationInfo(_LDLAppID);
        }

        private void ucLicenseApplicationInfo1_Load(object sender, EventArgs e)
        {
            _Load();
        }
    }
}
