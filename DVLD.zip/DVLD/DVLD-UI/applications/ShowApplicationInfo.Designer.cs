﻿namespace DVLD
{
    partial class ShowApplicationInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucLicenseApplicationInfo1 = new DVLD.ucLicenseApplicationInfo();
            this.SuspendLayout();
            // 
            // ucLicenseApplicationInfo1
            // 
            this.ucLicenseApplicationInfo1.Location = new System.Drawing.Point(0, 0);
            this.ucLicenseApplicationInfo1.Name = "ucLicenseApplicationInfo1";
            this.ucLicenseApplicationInfo1.Size = new System.Drawing.Size(858, 493);
            this.ucLicenseApplicationInfo1.TabIndex = 0;
            this.ucLicenseApplicationInfo1.Load += new System.EventHandler(this.ucLicenseApplicationInfo1_Load);
            // 
            // ShowApplicationInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 462);
            this.Controls.Add(this.ucLicenseApplicationInfo1);
            this.Name = "ShowApplicationInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ShowApplicationInfo";
            this.ResumeLayout(false);

        }

        #endregion

        private ucLicenseApplicationInfo ucLicenseApplicationInfo1;
    }
}