﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ShowLicenseHistory : Form
    {
        private int _PersonID { get; set; }
        public ShowLicenseHistory(int PersonID)
        {
            InitializeComponent();
            _PersonID = PersonID;
        }

        private void _LoadLicenses()
        {
            ucPersonInfo1.LoadPersonData(_PersonID);
            ucLicenseHistory1.LoadLicense(_PersonID);
        }

        private void ShowLicenseHistory_Load(object sender, EventArgs e)
        {
            _LoadLicenses();
        }
    }
}
