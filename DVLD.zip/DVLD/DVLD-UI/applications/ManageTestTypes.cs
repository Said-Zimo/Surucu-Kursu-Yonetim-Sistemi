﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD
{
    public partial class ManageTestTypes : Form
    {
        public ManageTestTypes()
        {
            InitializeComponent();
        }

        private void _RefreshTestTypes()
        {
            DataTable dt = clsTestTypes.GetAllTestTypes();

            if (dt != null)
            {
                dgvTestTypes.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Test Types Data Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            lblRecordsCount.Text = dt.Rows.Count.ToString();

        }

        private void ManageTestTypes_Load(object sender, EventArgs e)
        {
            _RefreshTestTypes();
        }

        private void _UpdateTestTypeDetails()
        {
            UpdateTestTypes frm = new UpdateTestTypes(int.Parse(dgvTestTypes.SelectedRows[0].Cells[0].Value.ToString()));
            frm.ShowDialog();
            _RefreshTestTypes();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _UpdateTestTypeDetails();
        }
    }
}
