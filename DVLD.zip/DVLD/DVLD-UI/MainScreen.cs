﻿using DVLD_Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace DVLD
{
    public partial class MainScreen : Form
    {
        public delegate void CloseApplication();
        public event CloseApplication onClose;
        public event CloseApplication onSignOut;

        public MainScreen()
        {
            InitializeComponent();
        }

        private void MainScreen_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (clsGlobalSittings.isLogined)
            {
                onClose?.Invoke();
            }  
        }

        public void _PeopleScreen()
        {
            ManagePeopleScreen managePeopleScreen = new ManagePeopleScreen();
            managePeopleScreen.ShowDialog();
        }

        private void peToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _PeopleScreen();
        }

        private void _SignOut()
        {
            
            clsGlobalSittings.isLogined = false;
            onSignOut?.Invoke();
            this.Close();
        }

        private void signOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _SignOut();
        }


        private void currentUserInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowUserDetails frm = new ShowUserDetails(clsGlobalSittings.CurrentUserInfo.UserID);
            frm.ShowDialog();
        }

        
        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeUserPasswordScreen frm = new ChangeUserPasswordScreen(clsGlobalSittings.CurrentUserInfo.UserID);
            frm.ShowDialog();
        }

        
        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageUserScreen frm = new ManageUserScreen();
            frm.ShowDialog();
        }


        private void retakeTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageApplicationTypesScreen frm = new ManageApplicationTypesScreen();
            frm.ShowDialog();
        }

       
        private void manageTestTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageTestTypes frm = new ManageTestTypes();
            frm.ShowDialog();
        }

        
        private void localToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewLocalDrivingLicenseApp app = new NewLocalDrivingLicenseApp(int.Parse(tsmiAddNewLocalLicenseApp.Tag.ToString()));
            app.ShowDialog();
        }

        

        private void localDrivingLicenseAppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageLocalDrivingLicenseApplications app = new ManageLocalDrivingLicenseApplications();
            app.ShowDialog();
        }

        
        private void driversToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageDriversScreen frm = new ManageDriversScreen();
            frm.ShowDialog();
        }


        private void nationalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IssueNewInternationalLicense frm = new IssueNewInternationalLicense();
            frm.ShowDialog();
        }

        
        private void internationalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageInternationalApplications frm = new ManageInternationalApplications();
            frm.ShowDialog();
        }


        private void internationalLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RenewLicenseApplication frm = new RenewLicenseApplication();
            frm.ShowDialog();
        }

        
        private void replacementLostOrDamagedLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReplacementLicense frm = new ReplacementLicense();
            frm.ShowDialog();
        }

        private void manageDetainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageDetainLicenses frm = new ManageDetainLicenses();
            frm.ShowDialog();
        }

        
        private void detainLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DetainLicense frm = new DetainLicense();
            frm.ShowDialog();
        }

        private void _ReleaseDetainedLicenseScreen()
        {
            ReleaseDetainedLicense frm = new ReleaseDetainedLicense();
            frm.ShowDialog();
        }

        private void releaseDetainLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ReleaseDetainedLicenseScreen();
        }

        private void releaseDetainedDrivingLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ReleaseDetainedLicenseScreen();
        }
    }
}
